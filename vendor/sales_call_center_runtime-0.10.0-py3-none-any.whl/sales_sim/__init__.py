"""Readable building blocks for the 15.776 sales-agent project.

Students use two names from here: `tool` (in tools.py) and, to read it, the loop
`run_agent` (a copy is agent.py). Everything else runs underneath.
"""

__version__ = "0.10.0"

from .agent import run_agent
from .environment import SalesEnvironment
from .harness import Toolbox, World, tool
from .interfaces import CustomerSimulator, ToolClient
from .models import CustomerReply, CustomerTurn, Scenario, Settlement
from .tools import LocalToolClient

__all__ = [
    "CustomerReply",
    "CustomerSimulator",
    "CustomerTurn",
    "LocalToolClient",
    "SalesEnvironment",
    "Scenario",
    "Settlement",
    "Toolbox",
    "ToolClient",
    "World",
    "run_agent",
    "tool",
]
