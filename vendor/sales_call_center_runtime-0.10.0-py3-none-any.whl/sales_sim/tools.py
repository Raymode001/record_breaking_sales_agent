"""The seller's public tool interface.

Schemas are written out so students can read and change the interface directly.
Argument validation belongs here; business rules belong in SalesEnvironment.
Only expected ToolErrors are shown to the agent. Programming, simulator, and
API failures propagate to the caller instead of looking like customer behavior.
"""

import json
from copy import deepcopy
from typing import TYPE_CHECKING, Any

from .errors import ToolError

if TYPE_CHECKING:
    from .environment import SalesEnvironment


TOOL_DEFINITIONS: list[dict[str, Any]] = [
    {
        "type": "function",
        "name": "get_status",
        "description": "Read the campaign's current day, remaining time, and progress.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {},
            "required": [],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "list_customers",
        "description": "List public customers, contact eligibility, and last decisions.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {},
            "required": [],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "read_customer",
        "description": (
            "Read compact account state: contact eligibility, profile reference, latest "
            "message/note, pending callbacks, quotes, and orders. Use search_customer_history "
            "and read_record for sources, or read_customer_history for the complete history."
        ),
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {"customer_id": {"type": "string"}},
            "required": ["customer_id"],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "read_customer_history",
        "description": "Read an account's full current conversation, notes, callbacks, profile, and record index. No history is truncated.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {"customer_id": {"type": "string"}},
            "required": ["customer_id"],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "get_catalog",
        "description": "Read the products (features, integrations, list price and service cost in integer cents) and today's pricing policy, with source references. Legal price ranges are not precomputed: the policy states the rule.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {},
            "required": [],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "search_customer_history",
        "description": (
            "Search one customer's dated CRM records and agent notes. An empty "
            "query browses all records. Search matches words in IDs and content; "
            "exact IDs and matches to all words rank first, followed by partial matches. "
            "Set kind to all, profile, sale, refund, "
            "cancellation, interaction, quote, callback, or note. Read full records "
            "with read_record before relying on an excerpt."
        ),
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "customer_id": {"type": "string"},
                "query": {"type": "string"},
                "kind": {"type": "string"},
            },
            "required": ["customer_id", "query", "kind"],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "read_record",
        "description": "Read a complete CRM record by its returned canonical ID (crm:... or run:...). Includes date, authorship, and source references. Unambiguous legacy IDs also work.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {"record_id": {"type": "string"}},
            "required": ["record_id"],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "list_documents",
        "description": (
            "List the ID and title of every company document available today. "
            "Read a document's full text with read_document."
        ),
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {},
            "required": [],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "read_document",
        "description": "Read a product or policy document by its ID.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {"document_id": {"type": "string"}},
            "required": ["document_id"],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "talk_to_customer",
        "description": (
            "Send a message and receive the customer's reply. This consumes contact "
            "time. Use present_quote to make a formal offer that can become an order."
        ),
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "customer_id": {"type": "string"},
                "message": {"type": "string"},
            },
            "required": ["customer_id", "message"],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "save_note",
        "description": (
            "Save a note for one customer, with IDs of supporting records. "
            "Use an empty source_ids list when there are no source references. "
            "Notes are the seller's interpretation, not authoritative quotes or orders."
        ),
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "customer_id": {"type": "string"},
                "text": {"type": "string"},
                "source_ids": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["customer_id", "text", "source_ids"],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "create_quote",
        "description": (
            "Create a quote under the current pricing rules. Price is an integer "
            "number of US cents per month: 5500 means $55.00. Creating a quote "
            "does not send it or reserve its price. First presentation checks current "
            "prices and starts validity. The price must be legal under today's pricing "
            "policy (see get_catalog)."
        ),
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "customer_id": {"type": "string"},
                "product_id": {"type": "string"},
                "monthly_price_cents": {"type": "integer"},
            },
            "required": ["customer_id", "product_id", "monthly_price_cents"],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "present_quote",
        "description": (
            "Present a quote using its returned canonical ID with a message and receive the customer's "
            "decision. This consumes contact time. Only a confirmed acceptance "
            "creates an order. Issued, unexpired offers retain their terms; an unseen "
            "draft must meet current prices when first presented."
        ),
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "quote_id": {"type": "string"},
                "message": {"type": "string"},
            },
            "required": ["quote_id", "message"],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "schedule_callback",
        "description": (
            "Record a callback for today or a later campaign day (integers from 1). "
            "The next contact on that day completes the appointment, not its substantive "
            "purpose. Postponing an already-due callback preserves it as missed."
        ),
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "customer_id": {"type": "string"},
                "day": {"type": "integer"},
                "reason": {"type": "string"},
            },
            "required": ["customer_id", "day", "reason"],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "advance_day",
        "description": "End the current campaign day and advance the simulation.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {},
            "required": [],
            "additionalProperties": False,
        },
    },
]


def _error(code: str, message: str) -> dict[str, Any]:
    return {"ok": False, "error": {"code": code, "message": message}}


def _validate_receipt(result: Any) -> None:
    if not isinstance(result, dict) or type(result.get("ok")) is not bool:
        raise ValueError("Invalid checkpoint tool receipt.")
    if result["ok"]:
        if set(result) != {"ok", "data"}:
            raise ValueError("Successful tool receipts require data.")
    else:
        if set(result) != {"ok", "error"}:
            raise ValueError("Failed tool receipts require an error.")
        error = result["error"]
        if not isinstance(error, dict) or set(error) != {"code", "message"}:
            raise ValueError("Invalid tool error receipt.")
        if not all(isinstance(value, str) for value in error.values()):
            raise ValueError("Tool error code and message must be strings.")


def _trace_input(value: Any) -> Any:
    """Keep malformed local calls from making the public trace unexportable."""
    try:
        json.dumps(value, allow_nan=False)
    except (TypeError, ValueError):
        return {"invalid_json_type": type(value).__name__}
    return deepcopy(value)


def _validate_arguments(arguments: Any, parameters: dict[str, Any]) -> None:
    """Check the small set of JSON types used by these explicit tool schemas."""
    if not isinstance(arguments, dict):
        raise ToolError("invalid_arguments", "Arguments must be a JSON object.")

    properties = parameters["properties"]
    missing = set(properties) - set(arguments)
    if missing:
        raise ToolError(
            "invalid_arguments", f"Missing arguments: {', '.join(sorted(missing))}."
        )
    unknown = set(arguments) - set(properties)
    if unknown:
        raise ToolError("invalid_arguments", "Arguments contain unrecognized fields.")

    for field, schema in properties.items():
        value = arguments[field]
        expected_type = schema["type"]
        if expected_type == "string":
            valid = isinstance(value, str)
        elif expected_type == "integer":
            # Python's bool is a subclass of int, but it is not a price or day.
            valid = isinstance(value, int) and not isinstance(value, bool)
        elif expected_type == "array":
            valid = isinstance(value, list) and all(
                isinstance(item, str) for item in value
            )
        else:
            raise RuntimeError(f"Unsupported tool schema type: {expected_type}")
        if not valid:
            label = "array of strings" if expected_type == "array" else expected_type
            raise ToolError("invalid_arguments", f"'{field}' must be a {label}.")


class LocalToolClient:
    """Run the public tools against a local environment.

    A request ID identifies one tool invocation, not a customer or a conversation.
    Replaying it returns a copy of the original result without another contact,
    quote, note, or day transition. RunSession checkpoints this cache together
    with environment state so the same protection holds after restarting.
    """

    def __init__(self, environment: "SalesEnvironment"):
        self._environment = environment
        self._handlers = {
            "get_status": environment.get_status,
            "list_customers": environment.list_customers,
            "read_customer": environment.read_customer,
            "read_customer_history": environment.read_customer_history,
            "get_catalog": environment.get_catalog,
            "search_customer_history": environment.search_customer_history,
            "read_record": environment.read_record,
            "list_documents": environment.list_documents,
            "read_document": environment.read_document,
            "talk_to_customer": environment.talk_to_customer,
            "save_note": environment.save_note,
            "create_quote": environment.create_quote,
            "present_quote": environment.present_quote,
            "schedule_callback": environment.schedule_callback,
            "advance_day": environment.advance_day,
        }
        self._definitions = deepcopy(TOOL_DEFINITIONS)
        self._parameters = {
            tool["name"]: tool["parameters"] for tool in self._definitions
        }
        self._completed: dict[str, tuple[str, dict[str, Any]]] = {}
        self.trace: list[dict[str, Any]] = []

    def definitions(self) -> list[dict[str, Any]]:
        return deepcopy(self._definitions)

    def has_completed(self, request_id: str) -> bool:
        """Used by deterministic scripts when resuming completed actions."""
        return request_id in self._completed

    def export_state(self) -> dict[str, Any]:
        return deepcopy(
            {
                "schema_version": 1,
                "completed": {
                    key: {"signature": signature, "result": result}
                    for key, (signature, result) in self._completed.items()
                },
                "trace": self.trace,
            }
        )

    def restore_state(self, state: dict[str, Any]) -> None:
        """Restore receipts without executing any tool or customer interaction."""
        if not isinstance(state, dict) or set(state) != {
            "schema_version",
            "completed",
            "trace",
        }:
            raise ValueError("Invalid tool checkpoint fields.")
        if type(state["schema_version"]) is not int or state["schema_version"] != 1:
            raise ValueError("Unsupported tool checkpoint version.")
        if not isinstance(state["completed"], dict) or not isinstance(
            state["trace"], list
        ):
            raise TypeError("Invalid checkpoint receipts or trace.")
        json.dumps(state, allow_nan=False)
        trace_receipts = {}
        for item in state["trace"]:
            if not isinstance(item, dict) or set(item) != {
                "day",
                "name",
                "arguments",
                "request_id",
                "result",
                "replayed",
            }:
                raise ValueError("Invalid checkpoint trace entry.")
            if (
                type(item["day"]) is not int
                or item["day"] < 1
                or type(item["replayed"]) is not bool
            ):
                raise ValueError("Invalid checkpoint trace day or replay flag.")
            _validate_receipt(item["result"])
            if isinstance(item["request_id"], str):
                signature = json.dumps(
                    [item["name"], item["arguments"]], sort_keys=True, allow_nan=False
                )
                trace_receipts[(item["request_id"], signature)] = item["result"]
        completed = {}
        for request_id, entry in state["completed"].items():
            if not isinstance(request_id, str) or not request_id:
                raise ValueError("Invalid checkpoint request ID.")
            if not isinstance(entry, dict) or set(entry) != {"signature", "result"}:
                raise ValueError("Invalid checkpoint receipt fields.")
            signature = entry["signature"]
            if not isinstance(signature, str):
                raise TypeError("Invalid checkpoint tool signature.")
            decoded = json.loads(signature)
            if (
                not isinstance(decoded, list)
                or len(decoded) != 2
                or not isinstance(decoded[0], str)
            ):
                raise ValueError("Invalid checkpoint tool signature.")
            name, arguments = decoded
            if name not in self._parameters:
                raise ValueError("Checkpoint references an unknown tool.")
            _validate_arguments(arguments, self._parameters[name])
            if signature != json.dumps(
                [name, arguments], sort_keys=True, allow_nan=False
            ):
                raise ValueError("Invalid checkpoint tool signature.")
            result = entry["result"]
            _validate_receipt(result)
            if trace_receipts.get((request_id, signature)) != result:
                raise ValueError("Tool receipt does not match its trace.")
            completed[request_id] = (signature, deepcopy(result))
        for item in state["trace"]:
            request_id = item["request_id"]
            if (
                not isinstance(request_id, str)
                or not request_id
                or not isinstance(item["name"], str)
                or item["name"] not in self._parameters
            ):
                continue
            try:
                _validate_arguments(item["arguments"], self._parameters[item["name"]])
            except ToolError:
                continue  # Rejected arguments never reserve a request ID.
            if request_id not in completed:
                raise ValueError(
                    "Trace contains a completed request without its replay receipt."
                )
            signature = json.dumps(
                [item["name"], item["arguments"]], sort_keys=True, allow_nan=False
            )
            expected_signature, expected_result = completed[request_id]
            if signature == expected_signature:
                if item["result"] != expected_result:
                    raise ValueError("Repeated request has inconsistent receipts.")
            elif item["result"].get("error", {}).get("code") != "request_id_conflict":
                raise ValueError("Conflicting request is not recorded as an error.")
        self._completed = completed
        self.trace = deepcopy(state["trace"])

    def call(
        self,
        name: str,
        arguments: dict[str, Any],
        *,
        request_id: str | None = None,
    ) -> dict[str, Any]:
        day = self._environment.day
        recorded_arguments = _trace_input(arguments)
        result, replayed = self._execute(name, arguments, request_id=request_id)
        self.trace.append(
            {
                "day": day,
                "name": _trace_input(name),
                "arguments": recorded_arguments,
                "request_id": _trace_input(request_id),
                "result": deepcopy(result),
                "replayed": replayed,
            }
        )
        return deepcopy(result)

    def _execute(
        self, name: str, arguments: dict[str, Any], *, request_id: str | None
    ) -> tuple[dict[str, Any], bool]:
        """Return a result and whether it came from the completed-call cache."""
        if not isinstance(name, str) or name not in self._handlers:
            return _error("unknown_tool", "Unknown tool name."), False
        if request_id is not None and (
            not isinstance(request_id, str) or not request_id
        ):
            return _error(
                "invalid_request_id", "Request ID must be a nonempty string."
            ), False
        try:
            _validate_arguments(arguments, self._parameters[name])
        except ToolError as error:
            return _error(error.code, str(error)), False

        signature = json.dumps([name, arguments], sort_keys=True, allow_nan=False)
        if request_id is not None and request_id in self._completed:
            previous_signature, previous_result = self._completed[request_id]
            if signature != previous_signature:
                return _error(
                    "request_id_conflict",
                    "This request ID was already used for a different tool call.",
                ), False
            return deepcopy(previous_result), True

        try:
            data = self._handlers[name](**deepcopy(arguments))
            result = {"ok": True, "data": data}
        except ToolError as error:
            result = _error(error.code, str(error))

        # A malformed environment result is a programming error, not an agent error.
        # Validate before caching so failed invocations can be retried.
        json.dumps(result, allow_nan=False)
        if request_id is not None:
            self._completed[request_id] = (signature, deepcopy(result))
        return deepcopy(result), False
