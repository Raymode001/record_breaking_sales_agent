"""Readable files for one run: what the agent did, what it cost, what it earned.

    transcript.md   each day's tool calls, the operations under them, and both
                    sides of every customer conversation
    window.csv      input, cached and output tokens per model call
    window.svg      Lecture 4's "what the window costs": input tokens per call
"""

import json
from html import escape

from .harness import World


def write_run_files(directory, seller, business_trace, row=None):
    """Write transcript.md, window.csv and window.svg; skip what the run never produced."""
    world = getattr(seller, "world", None)
    model = getattr(seller, "model", None)
    usage = list(getattr(model, "usage", []) or [])
    (directory / "window.csv").write_text(
        "call,input_tokens,cached_input_tokens,output_tokens\n"
        + "".join(f"{i},{_cell(r['input_tokens'])},{_cell(r['cached_input_tokens'])},{_cell(r['output_tokens'])}\n"
                  for i, r in enumerate(usage, 1)), encoding="utf-8")
    (directory / "window.svg").write_text(window_svg(usage), encoding="utf-8")
    if world is not None:
        (directory / "transcript.md").write_text(
            transcript(world, business_trace, row or {}, getattr(seller, "result", None) or {}, usage),
            encoding="utf-8")


def _cell(value):
    return "" if value is None else str(value)


def _money(cents):
    return "unknown" if cents is None else f"${cents / 100:,.2f}"


def _call(name, arguments):
    shown = (", ".join(f"{key}={value!r}" for key, value in arguments.items())
             if isinstance(arguments, dict) else repr(arguments))
    return f"{name}({shown})"


def _operation(op, indent):
    result = op["result"]
    data = result.get("data") if result.get("ok") else None
    if op["name"] in World.CONTACTS and isinstance(data, dict) and "reply" in data:
        args = op["arguments"]
        who = data["reply"]["customer_id"]
        label = f"QUOTE {args.get('quote_id')}" if op["name"] == "present_quote" else "TALK"
        return [f"{indent}- **{label} → {who}:** {args.get('message', '')}",
                f"{indent}  > **{who} ({data['decision']}):** {data['reply']['text']}"]
    status = "" if result.get("ok") else f" → **{result.get('error', {}).get('code', 'error')}**"
    return [f"{indent}- {_call(op['name'], op['arguments'])}{status}"]


def transcript(world, business_trace, row, result, usage):
    outcome = world.outcome() or {}
    inputs = [r["input_tokens"] for r in usage if r.get("input_tokens") is not None]
    contacts = sum(1 for op in business_trace if op.get("name") in World.CONTACTS
                   and op.get("result", {}).get("ok") and "reply" in (op["result"].get("data") or {}))
    tools = [e for e in world.events if e["kind"] == "tool"]
    lines = [f"# {row.get('case_id', 'Campaign')} · {row.get('variant') or row.get('agent_id') or ''}".rstrip(" ·"),
             "",
             f"Profit {_money(outcome.get('profit_cents'))} · {outcome.get('accepted_orders', 0)} orders "
             f"({outcome.get('retained_orders', 0)} retained) · {contacts} contacts · {len(usage)} model calls · "
             f"{sum(inputs):,} input tokens · {sum(1 for e in tools if e.get('error'))} tool errors "
             f"({sum(1 for e in tools if e.get('error') == 'tool_crashed')} crashes)"
             + ("" if row.get("seller_cost_usd") is None else f" · seller API cost ${row['seller_cost_usd']:,.4f}")]
    if result.get("model_stopped"):
        lines.append(f"\nThe model fell silent: {result['model_stopped']}. The calendar ran on and the campaign settled.")
    if result.get("error"):
        lines.append(f"\n**Run stopped:** {result['error']}")
    day = None
    for event in world.events:
        if event["day"] != day:
            day = event["day"]
            lines.append(f"\n## Day {day}")
        if event["kind"] == "end_of_day":
            reason = "turn limit reached" if event.get("cut_off") else (event.get("note") or "")[:400]
            lines.append(f"- *end of day.* {reason}".rstrip())
            continue
        operations = event.get("operations", [])
        thin_wrapper = (len(operations) == 1 and operations[0]["name"] == event["name"]
                        and operations[0]["arguments"] == event["arguments"])
        if not thin_wrapper:                     # a custom tool: show it, then what it did underneath
            failure = f" → **{event['error']}**" if event.get("error") else ""
            lines.append(f"- **{_call(event['name'], event['arguments'])}**{failure}")
        for op in operations:
            lines += _operation(op, "" if thin_wrapper else "  ")
        if event.get("error") == "tool_crashed" and event.get("output"):
            lines.append(f"  - crash: {json.loads(event['output'])['error']['message']}")
    lines.append(f"\n## Outcome\n\n```json\n{json.dumps(outcome, indent=2)}\n```")
    return "\n".join(lines) + "\n"


def window_svg(usage, width=640, height=260):
    """A small line chart of input tokens per model call; no plotting library needed."""
    values = [r.get("input_tokens") for r in usage]
    values = [v for v in values if isinstance(v, int)]
    title = "What the window costs: input tokens sent on each model call"
    if not values:
        return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="60">'
                f'<text x="10" y="30" font-family="sans-serif" font-size="13">{escape(title)}: no model calls</text></svg>\n')
    left, right, top, bottom = 64, width - 16, 36, height - 36
    peak = max(values) or 1
    step = max(1, len(values) - 1)
    points = " ".join(f"{left + i * (right - left) / step:.1f},{bottom - v / peak * (bottom - top):.1f}"
                      for i, v in enumerate(values))
    total = sum(values)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
            f'font-family="sans-serif" font-size="12" role="img" aria-label="{escape(title)}">'
            f'<text x="{left}" y="20" font-size="13" font-weight="600">{escape(title)}</text>'
            f'<line x1="{left}" y1="{bottom}" x2="{right}" y2="{bottom}" stroke="#999"/>'
            f'<line x1="{left}" y1="{top}" x2="{left}" y2="{bottom}" stroke="#999"/>'
            f'<text x="{left - 6}" y="{top + 4}" text-anchor="end">{peak:,}</text>'
            f'<text x="{left - 6}" y="{bottom + 4}" text-anchor="end">0</text>'
            f'<text x="{left}" y="{bottom + 18}">1</text>'
            f'<text x="{right}" y="{bottom + 18}" text-anchor="end">{len(values)} calls · {total:,} input tokens in total</text>'
            f'<polyline fill="none" stroke="#2f6fd1" stroke-width="2" points="{points}"/></svg>\n')
