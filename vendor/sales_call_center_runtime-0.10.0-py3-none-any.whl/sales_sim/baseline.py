"""The supplied agent: a neutral prompt and fourteen basic tools.

The `baseline` variant always uses these. The starter's prompt.py and tools.py begin
as copies. There is one basic tool per business operation (OPERATIONS.md), each
passing it straight through: no arithmetic, no search, no summaries. Students build
the tools that do the work on top of these.
"""

from .harness import tool

PROMPT = """You are a salesperson for a company that sells subscriptions to a line of \
scheduling software to small businesses. You work through a sales campaign: a fixed \
number of business days and a list of customer accounts.

# How a day works
- Each day opens with a note: the day, the contact time you have left and what each \
message to a customer costs.
- Every message you send a customer, including a quote, uses contact time and costs \
money. Reading records, documents and the catalog is free and takes no time.
- Your day ends when you reply without calling a tool. After the last day the campaign \
closes on its own and all orders are settled.

# How you are scored
profit = retained first-month revenue - service cost of every accepted order - contact costs
- Only a quote the customer accepts becomes an order. Each customer can buy once.
- At settlement an order is refunded if the product does not meet the customer's actual \
requirements; its service cost is still paid.
- Customers' budgets and current requirements are private. Records, company documents \
and your conversations are your evidence, and older records may be out of date.

# How to work
Use the tools to understand each customer's current needs, offer a suitable plan at a \
price the policy allows, and follow up when customers are ready to decide. Be accurate: \
do not promise features, prices or terms that the company's records do not support."""


# The campaign

@tool
def get_status(ctx) -> dict:
    """Read the campaign's current day, remaining time, and progress."""
    return ctx.get_status()


# Customers and their records

@tool
def list_customers(ctx) -> list:
    """List public customers, contact eligibility, and last decisions."""
    return ctx.list_customers()


@tool
def read_customer(ctx, customer_id: str) -> dict:
    """Read compact account state: contact eligibility, profile reference, latest
    message/note, pending callbacks, quotes, and orders. Use search_customer_history
    and read_record for sources, or read_customer_history for the complete history."""
    return ctx.read_customer(customer_id=customer_id)


@tool
def read_customer_history(ctx, customer_id: str) -> dict:
    """Read an account's full current conversation, notes, callbacks, profile, and
    record index. No history is truncated."""
    return ctx.read_customer_history(customer_id=customer_id)


@tool
def search_customer_history(ctx, customer_id: str, query: str, kind: str) -> list:
    """Search one customer's dated CRM records and agent notes. An empty query browses
    all records. Search matches words in IDs and content; exact IDs and matches to all
    words rank first, followed by partial matches. Set kind to all, profile, sale,
    refund, cancellation, interaction, quote, callback, or note. Read full records with
    read_record before relying on an excerpt."""
    return ctx.search_customer_history(customer_id=customer_id, query=query, kind=kind)


@tool
def read_record(ctx, record_id: str) -> dict:
    """Read a complete CRM record by its returned canonical ID (crm:... or run:...).
    Includes date, authorship, and source references. Unambiguous legacy IDs also work."""
    return ctx.read_record(record_id=record_id)


# Products, prices and company documents

@tool
def get_catalog(ctx) -> dict:
    """Read the products (features, integrations, list price and service cost, in
    integer cents) and today's pricing policy, whose rule says which prices are legal."""
    return ctx.get_catalog()


@tool
def list_documents(ctx) -> list:
    """List the ID and title of every company document available today. Read a
    document's full text with read_document."""
    return ctx.list_documents()


@tool
def read_document(ctx, document_id: str) -> dict:
    """Read a product or policy document by its ID."""
    return ctx.read_document(document_id=document_id)


# Talking and selling (each message uses contact time and costs money)

@tool
def talk_to_customer(ctx, customer_id: str, message: str) -> dict:
    """Send a message and receive the customer's reply. This consumes contact time.
    Use present_quote to make a formal offer that can become an order."""
    return ctx.talk_to_customer(customer_id=customer_id, message=message)


@tool
def create_quote(ctx, customer_id: str, product_id: str, monthly_price_cents: int) -> dict:
    """Create a quote under the current pricing rules. Price is an integer number of US
    cents per month: 5500 means $55.00. Creating a quote does not send it or reserve its
    price. First presentation checks current prices and starts validity."""
    return ctx.create_quote(customer_id=customer_id, product_id=product_id,
                            monthly_price_cents=monthly_price_cents)


@tool
def present_quote(ctx, quote_id: str, message: str) -> dict:
    """Present a quote using its returned canonical ID with a message and receive the
    customer's decision. This consumes contact time. Only a confirmed acceptance creates
    an order. Issued, unexpired offers retain their terms; an unseen draft must meet
    current prices when first presented."""
    return ctx.present_quote(quote_id=quote_id, message=message)


# Notes and callbacks

@tool
def save_note(ctx, customer_id: str, text: str, source_ids: list[str]) -> dict:
    """Save a note for one customer, with IDs of supporting records. Use an empty
    source_ids list when there are no source references. Notes are the seller's
    interpretation, not authoritative quotes or orders."""
    return ctx.save_note(customer_id=customer_id, text=text, source_ids=source_ids)


@tool
def schedule_callback(ctx, customer_id: str, day: int, reason: str) -> dict:
    """Record a callback for today or a later campaign day (integers from 1). The next
    contact on that day completes the appointment, not its substantive purpose.
    Postponing an already-due callback preserves it as missed."""
    return ctx.schedule_callback(customer_id=customer_id, day=day, reason=reason)


TOOLS = (get_status, list_customers, read_customer, read_customer_history, search_customer_history,
         read_record, get_catalog, list_documents, read_document, talk_to_customer, create_quote,
         present_quote, save_note, schedule_callback)
