"""Bounded transport retries and durable, metadata-only API request receipts.

This does not change model inputs or retry invalid model output. An interrupted
or failed request may still be billed, so its missing usage remains unknown.
"""

import json
import math
import os
import random
import threading
import time
import uuid
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any

from .execution import BillingUncertain, ExecutionBudget, current_budget
from .response_cache import current_cache

_EVENT_LOCK = threading.Lock()
# Guarded runs ride out a dropped connection, a timeout or a server error: each failed
# attempt is charged at the most it could have cost, then the same request is sent
# again after these waits (about five minutes in all: a short sleep or Wi-Fi drop).
TRANSPORT_RETRY_DELAYS = (5, 15, 30, 60, 90, 120)
# A rate limit (429) is refused, not billed. Many campaigns at once can exhaust a
# tokens-per-minute limit for a minute or two, and the provider's suggested wait is often
# a few milliseconds: wait at least this long, with jitter so processes do not retry together.
RATE_LIMIT_RETRY_DELAYS = (2, 5, 10, 20, 40, 60, 60, 60)
# MIT's Parley gateway: an OpenAI-compatible endpoint paid by MIT's monthly API credits.
PARLEY_BASE_URL = "https://parley.api.mit.edu/v1"


def _colab_secret(name):
    """A secret saved in Google Colab's Secrets panel, or "" outside Colab."""
    try:
        from google.colab import userdata
        return (userdata.get(name) or "").strip()
    except Exception:          # not in Colab, no such secret, or no notebook access
        return ""


def api_credentials(*, colab=True):
    """Which API to call: MIT Parley when PARLEY_API_KEY is set (in the environment, or in
    Colab's Secrets), otherwise OpenAI with OPENAI_API_KEY. Returns provider, key and base URL."""
    key = os.environ.get("PARLEY_API_KEY", "").strip() or (_colab_secret("PARLEY_API_KEY") if colab else "")
    if key:
        return {"provider": "parley", "api_key": key,
                "base_url": os.environ.get("PARLEY_BASE_URL", "").strip() or PARLEY_BASE_URL}
    key = os.environ.get("OPENAI_API_KEY", "").strip()
    return {"provider": "openai", "api_key": key or None, "base_url": os.environ.get("OPENAI_BASE_URL") or None}


def create_client(role: str) -> Any:
    """Create the default client; explicitly injected clients bypass this path.

    The SDK timeout bounds network inactivity, not total request duration. The
    evaluator separately enforces the overall worker deadline.
    """
    try:
        from openai import OpenAI
    except ImportError as error:
        raise RuntimeError(
            "Install the starter dependencies: python -m pip install -r requirements.txt"
        ) from error
    timeout = float(os.environ.get("SALES_SIM_API_TIMEOUT_SECONDS", "120"))
    retries = int(os.environ.get("SALES_SIM_API_MAX_RETRIES", "2"))
    if not math.isfinite(timeout) or timeout <= 0:
        raise ValueError("SALES_SIM_API_TIMEOUT_SECONDS must be finite and positive.")
    if not 0 <= retries <= 10:
        raise ValueError("SALES_SIM_API_MAX_RETRIES must be between 0 and 10.")
    credentials = api_credentials()
    if credentials["provider"] == "parley":
        client = OpenAI(api_key=credentials["api_key"], base_url=credentials["base_url"],
                        timeout=timeout, max_retries=0)
    else:
        try:   # the OpenAI SDK reads OPENAI_API_KEY and OPENAI_BASE_URL itself
            client = OpenAI(timeout=timeout, max_retries=0)
        except Exception as error:
            if credentials["api_key"]:
                raise
            raise RuntimeError("No API key. Set PARLEY_API_KEY to your MIT Parley API key "
                               "(in Colab, add it under Secrets), or OPENAI_API_KEY to an OpenAI key.") from error
    instrumented = InstrumentedClient(
        client,
        role=role,
        timeout_seconds=timeout,
        max_retries=retries,
        events_path=os.environ.get("SALES_SIM_API_EVENTS_PATH"),
        cache=current_cache(),   # only provider clients replay and record spending
    )
    if credentials["provider"] == "parley":
        instrumented.responses._service_tier = None     # an OpenAI processing tier; Parley sets its own
    return instrumented


def ensure_instrumented(client, *, role):
    """Give injected test clients the same accounting path without transport retries."""
    if getattr(type(client), "_sales_receipts", False):
        return client
    return InstrumentedClient(
        client, role=role, timeout_seconds=120, max_retries=0,
        events_path=os.environ.get("SALES_SIM_API_EVENTS_PATH"),
    )


class InstrumentedClient:
    """Responses endpoint and a usage view derived from its durable receipts."""

    _sales_receipts = True

    def __init__(
        self, client: Any, *, role: str, timeout_seconds: float,
        max_retries: int, events_path: str | Path | None = None, cache=None,
    ):
        self.responses = _Responses(
            client.responses, role, timeout_seconds, max_retries, events_path,
            budget=current_budget(), cache=cache,
        )

    @property
    def usage(self):
        return [
            {"response_id": event.get("response_id"), "model": event.get("model"),
             **event["usage"]}
            for event in self.responses.events if event["event"] == "completed"
        ]


class _Responses:
    def __init__(self, responses, role, timeout_seconds, max_retries, events_path, budget, cache=None):
        self._responses = responses
        self._role = role
        self._timeout = timeout_seconds
        self._max_retries = max_retries
        self._path = Path(events_path) if events_path else None
        self._budget = budget
        # Development runs only: replay stored responses and record spending (response_cache.py).
        self._cache = cache
        # Optional processing tier for every request, e.g. "priority" (OpenAI's faster, pricier
        # tier). Set by the runner from course.json; dropped if the model does not accept it.
        self._service_tier = os.environ.get("SALES_SIM_SERVICE_TIER") or None
        self.events = []

    def _record(self, event: dict[str, Any]) -> None:
        event = {
            "schema_version": 1,
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            **event,
        }
        # Publish an in-memory view only after the authoritative disk write.
        # A missing path is supported for isolated unit tests and old clients.
        with _EVENT_LOCK:
            if self._path is not None:
                self._path.parent.mkdir(parents=True, exist_ok=True)
                with self._path.open("a", encoding="utf-8") as stream:
                    stream.write(json.dumps(event, allow_nan=False) + "\n")
                    stream.flush()
                    os.fsync(stream.fileno())
            self.events.append(event)
            if self._budget is not None:
                self._budget.observe(event)

    def create(self, **kwargs):
        if kwargs.get("stream"):
            raise ValueError("Request receipts require a non-streaming response.")
        if self._budget is not None:
            kwargs = self._budget.prepare(kwargs)
        if self._service_tier and "service_tier" not in kwargs:
            kwargs = {**kwargs, "service_tier": self._service_tier}
        cache = self._cache
        # The processing tier changes speed and price, not the reply, so it is not part of the key.
        cache_key = (cache.key(self._role, {name: value for name, value in kwargs.items() if name != "service_tier"})
                     if cache is not None else None)
        call = {"call_id": uuid.uuid4().hex, "role": self._role, "model": kwargs.get("model")}
        if cache_key is not None:
            stored = cache.lookup(cache_key)
            if stored is not None:
                return self._replay(call, kwargs, cache, stored[0])
            cache.require_allowance()   # the personal spending cap stops a paid request here
        attempt = 0
        while True:
            attempt += 1
            metadata = {**call, "attempt": attempt}
            key = (call["call_id"], attempt)
            if self._budget is not None:
                self._budget.reserve(key, kwargs)
            try:
                self._record({
                    **metadata, "event": "started", "timeout_seconds": self._timeout,
                    "max_retries": self._max_retries,
                })
            except BaseException:
                if self._budget is not None:
                    self._budget.logging_failed(key, sent=False)
                raise
            started = time.monotonic()
            try:
                try:
                    response = self._responses.create(**kwargs)
                except Exception as error:
                    if not (kwargs.get("service_tier") and getattr(error, "status_code", None) == 400
                            and "service_tier" in str(error).lower()):
                        raise
                    # A rejected request is not billed: send it again on the standard tier.
                    kwargs = {key: value for key, value in kwargs.items() if key != "service_tier"}
                    self._service_tier = None
                    response = self._responses.create(**kwargs)
            except BaseException as error:
                # Historical staff runs retain their original transport policy. Guarded
                # development retries a clearly rejected rate limit, and a transport
                # failure (dropped connection, timeout, server error) charged at its
                # worst case; any other failure leaves billing unknown and stops.
                rejected = self._budget is not None and _known_rejection(error)
                transport = (self._budget is not None and not rejected
                             and isinstance(error, Exception) and _retryable(error))
                if transport:
                    retrying = attempt <= len(TRANSPORT_RETRY_DELAYS)
                    delay = TRANSPORT_RETRY_DELAYS[attempt - 1] if retrying else None
                else:
                    rate_limited = rejected and getattr(error, "status_code", None) == 429
                    if self._budget is not None and rate_limited:
                        retrying = attempt <= len(RATE_LIMIT_RETRY_DELAYS)
                        delay = (max(_retry_delay(error, attempt), RATE_LIMIT_RETRY_DELAYS[attempt - 1])
                                 * random.uniform(1.0, 1.5)) if retrying else None
                    else:
                        if self._budget is not None:
                            retryable = False
                        else:
                            retryable = attempt <= self._max_retries and isinstance(error, Exception) and _retryable(error)
                        retrying = attempt <= self._max_retries and retryable
                        delay = _retry_delay(error, attempt) if retrying else None
                worst_input, worst_output = ExecutionBudget.worst_case(kwargs) if transport else (None, None)
                # An interrupted historical call remains a started-only receipt.
                if not isinstance(error, Exception) and self._budget is None:
                    raise
                try:
                    self._record({
                        **metadata, "event": "error",
                        "elapsed_seconds": time.monotonic() - started,
                        "error_type": type(error).__name__,
                        "status_code": getattr(error, "status_code", None),
                        "request_id": getattr(error, "request_id", None),
                        "retrying": retrying, "retry_delay_seconds": delay,
                        "billing": "rejected" if rejected else "assumed" if transport else "unknown",
                        **({"assumed_token_units": worst_input + 6 * worst_output} if transport else {}),
                    })
                except BaseException:
                    if self._budget is not None:
                        self._budget.logging_failed(key, sent=True)
                    raise
                if transport and cache is not None:
                    cache.charge(role=self._role, model=kwargs.get("model"), response_id=None, replayed=False,
                                 assumed=True, usage={"input_tokens": worst_input, "output_tokens": worst_output,
                                                      "cached_input_tokens": 0})
                if self._budget is not None and not rejected and not transport:
                    if not isinstance(error, Exception):
                        raise
                    raise BillingUncertain("The API request failed without reliable billing information; further calls are stopped.") from error
                if not retrying:
                    raise
                time.sleep(delay)
                if transport and cache is not None:
                    cache.require_allowance()      # the worst-case charge counts toward the cap
                continue
            try:
                self._record({
                    **metadata, "event": "completed",
                    "elapsed_seconds": time.monotonic() - started,
                    "model": getattr(response, "model", call["model"]),
                    "response_id": getattr(response, "id", None),
                    "request_id": getattr(response, "_request_id", None),
                    "response_status": getattr(response, "status", None),
                    "service_tier": getattr(response, "service_tier", None),
                    "usage": _response_usage(response),
                })
            except BaseException:
                if self._budget is not None:
                    self._budget.logging_failed(key, sent=True)
                raise
            if cache_key is not None:
                self._keep(cache, cache_key, response)
            return response

    def _replay(self, call, kwargs, cache, response):
        """Account for a stored response exactly like the original request, without sending it.

        The same execution guards apply and the receipt carries the original token
        counts, so a replayed trial reaches its limits at the same point.
        """
        metadata = {**call, "attempt": 1, "replayed": True}
        key = (call["call_id"], 1)
        if self._budget is not None:
            self._budget.reserve(key, kwargs)
        usage = _response_usage(response)
        model = getattr(response, "model", call["model"])
        try:
            self._record({**metadata, "event": "started", "timeout_seconds": self._timeout,
                          "max_retries": self._max_retries})
            self._record({
                **metadata, "event": "completed", "elapsed_seconds": 0.0, "model": model,
                "response_id": getattr(response, "id", None), "request_id": None,
                "response_status": getattr(response, "status", None),
                "service_tier": getattr(response, "service_tier", None), "usage": usage,
            })
        except BaseException:
            if self._budget is not None:
                self._budget.logging_failed(key, sent=False)
            raise
        cache.charge(role=self._role, model=model, usage=usage,
                     response_id=getattr(response, "id", None), replayed=True)
        return response

    def _keep(self, cache, cache_key, response):
        """Record a paid response in the ledger and store it for replay."""
        usage = _response_usage(response)
        model = getattr(response, "model", None)
        response_id = getattr(response, "id", None)
        cache.charge(role=self._role, model=model, usage=usage, response_id=response_id, replayed=False)
        cache.store(cache_key, response, role=self._role, model=model, usage=usage, response_id=response_id)


def _response_usage(response):
    """Extract once; consumers never reconstruct receipts from model objects."""
    usage = getattr(response, "usage", None)
    details = getattr(usage, "input_tokens_details", None)
    values = {
        "input_tokens": getattr(usage, "input_tokens", None),
        "output_tokens": getattr(usage, "output_tokens", None),
        "cached_input_tokens": getattr(details, "cached_tokens", None),
    }
    return {name: value if type(value) is int and value >= 0 else None
            for name, value in values.items()}


def _known_rejection(error):
    try:
        from openai import APIStatusError
    except ImportError:  # Offline clients need no provider SDK.
        return False
    return isinstance(error, APIStatusError) and error.status_code in {400, 401, 403, 404, 405, 422, 429}


def _retryable(error: Exception) -> bool:
    try:
        from openai import APIConnectionError, APIStatusError
    except ImportError:  # Offline clients need no provider SDK.
        return False

    if isinstance(error, APIConnectionError):  # includes APITimeoutError
        return True
    return isinstance(error, APIStatusError) and (
        error.status_code in {408, 409, 429} or error.status_code >= 500
    )


def _retry_delay(error: Exception, attempt: int) -> float:
    headers = getattr(getattr(error, "response", None), "headers", {})
    try:
        if headers.get("retry-after-ms") is not None:
            delay = float(headers["retry-after-ms"]) / 1000
        elif headers.get("retry-after") is not None:
            try:
                delay = float(headers["retry-after"])
            except ValueError:
                deadline = parsedate_to_datetime(headers["retry-after"])
                delay = deadline.timestamp() - time.time()
        else:
            delay = 0.5 * 2 ** (attempt - 1)
        if math.isfinite(delay) and delay >= 0:
            return min(delay, 60.0)
    except (TypeError, ValueError, OverflowError):
        pass
    return min(0.5 * 2 ** (attempt - 1), 60.0)


def _valid_event(event: Any) -> bool:
    if (
        not isinstance(event, dict)
        or event.get("schema_version") != 1
        or event.get("event") not in {"started", "completed", "error"}
        or not isinstance(event.get("call_id"), str)
        or type(event.get("attempt")) is not int
        or event["attempt"] < 1
        or not isinstance(event.get("role"), str)
    ):
        return False
    if event["event"] == "started":
        return True
    elapsed = event.get("elapsed_seconds")
    if type(elapsed) not in (int, float) or not math.isfinite(elapsed) or elapsed < 0:
        return False
    if event["event"] == "error":
        return type(event.get("retrying")) is bool
    usage = event.get("usage")
    return isinstance(usage, dict) and all(
        usage.get(field) is None or (type(usage[field]) is int and usage[field] >= 0)
        for field in ("input_tokens", "output_tokens", "cached_input_tokens")
    )


def _load_events(path: str | Path) -> tuple[list[dict[str, Any]], int, str | None]:
    events, invalid = [], 0
    try:
        lines = Path(path).read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError) as error:
        return events, invalid, type(error).__name__
    for line in lines:
        try:
            event = json.loads(line)
            if not _valid_event(event):
                raise ValueError("Invalid event metadata.")
            events.append(event)
        except (ValueError, TypeError):
            # A worker can be killed partway through its final write. Preserve
            # earlier receipts and make the incomplete telemetry visible.
            invalid += 1
    return events, invalid, None


def read_api_events(path: str | Path) -> list[dict[str, Any]]:
    """Read valid receipts, retaining earlier records after a partial write."""
    return _load_events(path)[0]


def summarize_api_events(path: str | Path) -> dict[str, Any]:
    """Summarize observed timing and usage; missing receipts are never free."""
    events, invalid, read_error = _load_events(path)
    summary = _summarize(events)
    summary.update(
        {
            "available": read_error is None,
            "read_error": read_error,
            "parse_errors": invalid,
            "by_role": {
                role: _summarize([event for event in events if event["role"] == role])
                for role in sorted({event["role"] for event in events})
            },
        }
    )
    if invalid or read_error or not events:
        summary["billing_complete"] = False
    return summary


def _summarize(events: list[dict[str, Any]]) -> dict[str, Any]:
    started = [event for event in events if event["event"] == "started"]
    completed = [event for event in events if event["event"] == "completed"]
    errors = [event for event in events if event["event"] == "error"]
    ended = {(event["call_id"], event["attempt"]) for event in completed + errors}
    pending = [
        event for event in started if (event["call_id"], event["attempt"]) not in ended
    ]
    latencies = [event["elapsed_seconds"] for event in completed + errors]
    calls = {event["call_id"] for event in events}
    successful_calls = {event["call_id"] for event in completed}
    failed_calls = {event["call_id"] for event in errors if not event["retrying"]}
    usage = {"responses": len(completed), "complete": True}
    for field in ("input_tokens", "output_tokens", "cached_input_tokens"):
        known = [event.get("usage", {}).get(field) for event in completed]
        usage[field] = sum(value for value in known if type(value) is int)
        if any(type(value) is not int for value in known):
            usage["complete"] = False
    return {
        "logical_calls": len(calls),
        "replayed_responses": sum(bool(event.get("replayed")) for event in completed),
        "attempts_started": len(started),
        "attempts_completed": len(completed),
        "attempts_errored": len(errors),
        "pending_attempts": len(pending),
        "pending_requests": pending,
        "retried_calls": len(
            {event["call_id"] for event in started if event["attempt"] > 1}
        ),
        "failed_calls": len(failed_calls - successful_calls),
        "unfinished_calls": len(calls - successful_calls - failed_calls),
        "observed_request_seconds": sum(latencies),
        "request_latency_seconds": {
            "count": len(latencies),
            "min": min(latencies) if latencies else None,
            "mean": sum(latencies) / len(latencies) if latencies else None,
            "max": max(latencies) if latencies else None,
        },
        "known_usage": usage,
        # A transport failure charged at its worst case ("assumed") is accounted for.
        "assumed_attempts": sum(event.get("billing") == "assumed" for event in errors),
        "assumed_token_units": sum(event.get("assumed_token_units") or 0 for event in errors
                                   if event.get("billing") == "assumed"),
        "billing_complete": not pending and usage["complete"] and all(
            event.get("billing") in {"rejected", "assumed"} for event in errors),
    }
