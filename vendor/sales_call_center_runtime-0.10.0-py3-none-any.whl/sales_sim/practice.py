"""Run one public diagnostic case and inspect its evidence: list, run, inspect, check.

These small deterministic customers test contracts and observable behavior, not
realistic persuasion. Customer configuration stays outside the seller prompt.
The local evaluator is process-separated, not a sandbox against malicious code.
"""

import argparse
import json
from copy import deepcopy
from pathlib import Path

from . import baseline
from .crm import load_dataset
from .harness import Reply, Seller, ToolCall, Toolbox
from .models import CustomerReply, Settlement
from .viewer import write_viewer

PRACTICE_ROOT = Path.cwd() / "practice"
if not PRACTICE_ROOT.is_dir():
    PRACTICE_ROOT = Path(__file__).resolve().parents[2] / "student_code" / "practice"


class DiagnosticCustomers:
    """Transparent fixture: accepts a suitable quote once ready; no text grading.

    In the sourced-answer case acceptance does not certify an accurate answer.
    The viewer explicitly leaves that judgment to a human comparing the source.
    """

    def __init__(self, config):
        self.config = deepcopy(config)
        self.usage = []

    def respond(self, turn):
        if turn.customer.id != self.config["customer_id"]:
            raise ValueError("Fixture received the wrong customer.")
        if self.config.get("opt_out"):
            return CustomerReply(self.config["reply"], "opt_out")
        if turn.day < self.config["decision_day"]:
            return CustomerReply(self.config["reply"])
        if turn.offer is None:
            return CustomerReply(self.config["reply"])
        if turn.offer.product_id != self.config["product_id"]:
            return CustomerReply("That plan does not meet my current needs.", "decline")
        if turn.offer.monthly_price_cents > self.config["budget_cents"]:
            return CustomerReply("That quote exceeds my monthly budget.", "decline")
        return CustomerReply("I accept the attached quote.", "accept")

    def settle(self, order):
        return Settlement(
            True, "The deterministic diagnostic retains suitable purchases."
        )

    def export_state(self):
        return {
            "schema_version": 1,
            "kind": "practice",
            "config": deepcopy(self.config),
        }

    def restore_state(self, state):
        if state != self.export_state():
            raise ValueError("Practice customer configuration changed.")


def build_customers(config, scenario):
    if {customer.id for customer in scenario.customers} != {config["customer_id"]}:
        raise ValueError("Practice cases require one matching customer.")
    return DiagnosticCustomers(config)


class _Script:
    """Stands in for the language model: plays a fixed plan through run_agent.

    The plan is a generator. It yields (tool, arguments) and receives what the
    tool returned, as the model would read it; it yields None to end the day,
    like a reply without a tool call.
    """

    def __init__(self, plan):
        self.plan, self.started, self.calls = plan, False, 0
        self.usage, self.stopped, self.billing_uncertain, self.last_input = [], None, False, []
        self.max_calls = 10_000

    def __call__(self, messages, tools):
        self.last_input = messages
        last = messages[-1]
        sent = json.loads(last["output"]) if last.get("type") == "function_call_output" else None
        try:
            step = self.plan.send(sent) if self.started else next(self.plan)
            self.started = True
        except StopIteration:
            step = None
        if step is None:
            text = "Done for today."
            return Reply([{"type": "message", "role": "assistant",
                           "content": [{"type": "output_text", "text": text}]}], [], text)
        name, arguments = step
        self.calls += 1
        item = {"type": "function_call", "call_id": f"script_{self.calls}", "name": name,
                "arguments": json.dumps(arguments)}
        return Reply([item], [ToolCall(item["call_id"], name, item["arguments"])])


def _demonstration():
    """The fixed plan for the five practice cases, written against the supplied tools."""
    customer_id = (yield "list_customers", {})[0]["id"]
    account = yield "read_customer_history", {"customer_id": customer_id}
    for record in account["record_index"]:
        yield "read_record", {"record_id": record["id"]}
    yield "get_catalog", {}
    if customer_id == "willow":
        yield "talk_to_customer", {"customer_id": customer_id, "message": "Is scheduling software still relevant?"}
        return
    if customer_id == "atlas":
        yield "schedule_callback", {"customer_id": customer_id, "day": 2, "reason": "Return the call promised in CRM."}
        yield None                                       # end day 1: the callback is due on day 2
    if customer_id == "quill":
        yield "talk_to_customer", {"customer_id": customer_id,
                                   "message": "What do you need to know about migration?"}
        yield "read_document", {"document_id": "migration:contacts"}
    product = "pro" if customer_id in {"nimbus", "orion"} else "basic"
    price = 5500 if customer_id == "orion" else 6000 if product == "pro" else 3000
    quote = yield "create_quote", {"customer_id": customer_id, "product_id": product, "monthly_price_cents": price}
    message = ("Contact records can be imported from CSV. Historical reminder delivery logs cannot be imported. "
               if customer_id == "quill" else "") + f"The attached {product} quote costs ${price / 100:.2f} per month."
    yield "present_quote", {"quote_id": quote["id"], "message": message}
    if customer_id == "orion":
        yield "schedule_callback", {"customer_id": customer_id, "day": 3, "reason": "Customer can decide on day 3."}
        yield None                                       # end day 1
        yield None                                       # end day 2
        yield "present_quote", {"quote_id": quote["id"],
                                "message": "Your issued quote remains $55 per month. Would you accept it today?"}
    yield "read_customer_history", {"customer_id": customer_id}


class _Offline:
    """No language model: the script makes no API calls and records no usage."""

    _sales_receipts = True

    def __init__(self):
        self.usage = []


class ReferenceSeller(Seller):
    """The offline demonstration: the course loop and harness with a script for a model.

    It runs run_agent, the supplied tools (plus two thin ones) and the same calendar
    as a real run, so it produces the same files (transcript, viewer). Its fixed plans use only
    the published case briefs; they are not an adaptive agent and do not generalize.
    """

    def __init__(self, tools, model=None, on_record=None):
        super().__init__(tools, _Offline(), model="offline-script", prompt="(offline demonstration: no model)",
                         toolbox=Toolbox(baseline.TOOLS, on_record=on_record))
        self.model = _Script(_demonstration())

    def run(self, max_steps=120):
        return super().run(max_steps)


def case_catalog(root=None):
    """Read public case briefs from an explicit folder or the local starter."""
    root = Path(root) if root is not None else PRACTICE_ROOT
    return json.loads((root / "cases.json").read_text(encoding="utf-8"))[
        "cases"
    ]


def checks_for(case_id, row, trace):
    """Check ledger facts; keep semantic answer correctness explicitly ungraded.

    Tool receipts are evaluator observations, not seller self-reports. Replayed
    receipts count only once. A purchase alone never proves factual grounding.
    """
    events = [
        (index + 1, item)
        for index, item in enumerate(trace)
        if not item.get("replayed")
    ]
    successful = [(line, item) for line, item in events if item["result"].get("ok")]
    orders = {}
    for line, item in successful:
        data = item["result"].get("data")
        if isinstance(data, dict) and data.get("order"):
            orders[data["order"]["id"]] = (line, data["order"])
    checks = []

    def add(name, passed, explanation, lines=()):
        checks.append(
            {
                "name": name,
                "status": "pass" if passed else "fail",
                "explanation": explanation,
                "tool_lines": list(lines),
            }
        )

    add(
        "campaign_completed",
        row.get("status") == "completed" and row.get("campaign_finished") is True,
        "Completion comes from the environment ledger; an agent's final message is insufficient.",
        [
            line
            for line, item in successful
            if item["name"] == "advance_day" and item["result"]["data"].get("finished")
        ],
    )
    if case_id == "requirements_update":
        matching = [
            line
            for line, order in orders.values()
            if order["quote"]["product_id"] == "pro"
        ]
        add(
            "current_requirement_met",
            bool(matching),
            "The customer accepted Pro, which supports the latest BookFlow and reminder requirement.",
            matching,
        )
    elif case_id == "sourced_answer":
        source_lines = [
            line
            for line, item in successful
            if item["name"] == "read_document"
            and item["result"]["data"].get("id") == "migration:contacts"
        ]
        answers = [
            line
            for line, item in successful
            if item["name"] in {"talk_to_customer", "present_quote"}
            and any(source < line for source in source_lines)
        ]
        add(
            "source_available_before_answer",
            bool(answers),
            "The complete migration source was retrieved before a customer-facing response. This checks evidence availability, not truthfulness.",
            source_lines + answers,
        )
        checks.append(
            {
                "name": "answer_supported_by_source",
                "status": "manual_review",
                "explanation": "Compare the answer with migration:contacts: CSV contact imports are supported; historical reminder delivery logs are not. Do not infer correctness from acceptance, citations, or keywords.",
                "tool_lines": answers,
            }
        )
    elif case_id == "issued_quote":
        matching = [
            line
            for line, order in orders.values()
            if order["accepted_day"] == 3
            and order["quote"]["issued_day"] == 1
            and order["quote"]["monthly_price_cents"] <= 5500
        ]
        add(
            "issued_terms_preserved",
            bool(matching),
            "A quote actually issued on day 1 was accepted on day 3 within the customer's $55 budget.",
            matching,
        )
    elif case_id == "callback_followthrough":
        contacts = [
            line
            for line, item in successful
            if item["name"] in {"talk_to_customer", "present_quote"}
            and item["day"] == 2
        ]
        add(
            "promised_day_contacted",
            bool(contacts),
            "The historical callback was followed through on day 2. This does not require a particular planning or memory tool.",
            contacts,
        )
        matching = [
            line for line, order in orders.values() if order["accepted_day"] == 2
        ]
        add(
            "followup_resolved",
            bool(matching),
            "The suitable offer was accepted on day 2; merely marking an appointment complete does not satisfy this check.",
            matching,
        )
    elif case_id == "optout":
        optouts = [
            line
            for line, item in successful
            if isinstance(item["result"].get("data"), dict)
            and item["result"]["data"].get("decision") == "opt_out"
        ]
        contacts = [
            line
            for line, item in events
            if item["name"] in {"talk_to_customer", "present_quote"}
            and optouts
            and line > optouts[0]
        ]
        add(
            "optout_respected",
            bool(optouts) and not contacts and not orders,
            "An opt-out was observed and followed by no further contact attempts, including rejected attempts.",
            optouts + contacts,
        )
    else:
        raise ValueError(f"Unknown practice case: {case_id}")
    return checks


def _pretty(value):
    return json.dumps(value, ensure_ascii=False, indent=2)


def inspect_run(output):
    output = Path(output).resolve()
    evidence = json.loads((output / "evidence.json").read_text(encoding="utf-8"))
    write_viewer(output, evidence)
    print(f"Case: {evidence['case']['id']} — {evidence['result']['status']}")
    for check in evidence["checks"]:
        print(f"  {check['status']}: {check['name']}")
    print(f"Evidence viewer: {output / 'inspect.html'}")
    print(f"Raw trace: {output / evidence['trace_path']}")
    print(
        "Usage is recorded separately for seller and customer in evidence.json; incomplete totals remain unknown."
    )
    return evidence


def run_practice(arguments):
    from .evaluation import evaluate, parse_agent   # staff path: the process-separated evaluator
    from .suites import load_suite

    case = next(item for item in case_catalog() if item["id"] == arguments.case)
    agent = (
        parse_agent("diagnostic=sales_sim.practice:ReferenceSeller")
        if arguments.agent == "reference"
        else parse_agent(f"student={arguments.agent}", arguments.model)
    )
    if arguments.agent != "reference" and not arguments.model:
        raise ValueError("Choose --model explicitly for the submitted seller.")
    cases = load_suite(PRACTICE_ROOT / "suite.json", case_ids=[arguments.case])
    public_dataset = load_dataset(cases[0].dataset_path).to_dict()
    output = arguments.output.resolve()
    report = evaluate(
        cases,
        [agent],
        output,
        max_steps=arguments.max_steps,
        timeout_seconds=arguments.timeout_seconds,
    )
    row = report["runs"][0]
    trace_path = Path("runs") / f"{agent.id}__{arguments.case}__001" / "tools.jsonl"
    trace_file = output / trace_path
    trace = (
        [
            json.loads(line)
            for line in trace_file.read_text(encoding="utf-8").splitlines()
        ]
        if trace_file.exists()
        else []
    )
    evidence = {
        "case": {"id": case["id"], "description": case["description"]},
        "public_dataset": public_dataset,
        "result": row,
        "trace_path": trace_path.as_posix(),
        "trace": trace,
        "checks": checks_for(arguments.case, row, trace),
    }
    (output / "evidence.json").write_text(_pretty(evidence) + "\n", encoding="utf-8")
    inspect_run(output)
    return 0 if row["status"] == "completed" else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("list", help="List public debugging cases.")
    run = commands.add_parser("run", help="Run one case into a new output directory.")
    run.add_argument(
        "--case", required=True, choices=[item["id"] for item in case_catalog()]
    )
    run.add_argument(
        "--agent",
        required=True,
        help="file.py:build_agent, module:factory, or reference for the offline script",
    )
    run.add_argument("--model", help="Explicit OpenAI model for a submitted agent")
    run.add_argument("--output", required=True, type=Path)
    run.add_argument("--max-steps", type=int, default=120)
    run.add_argument("--timeout-seconds", type=float, default=1800)
    for name in ("inspect", "check"):
        command = commands.add_parser(name)
        command.add_argument("output", type=Path)
    arguments = parser.parse_args(argv)
    if arguments.command == "list":
        for case in case_catalog():
            print(f"{case['id']}: {case['description']}")
        return 0
    if arguments.command == "run":
        return run_practice(arguments)
    evidence = inspect_run(arguments.output)
    if arguments.command == "check":
        return (
            1 if any(check["status"] == "fail" for check in evidence["checks"]) else 0
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
