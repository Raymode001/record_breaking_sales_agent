"""Shared development guards for seller and customer API calls.

These are execution guards, not dollar estimates or context-window limits.
History is never shortened: a request that cannot fit the remaining allowance
is stopped before transport. Input reservation uses serialized UTF-8 bytes as a
conservative estimate; observed usage comes only from provider receipts.
"""

import json
import threading
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import asdict, dataclass

_ACTIVE_BUDGET = ContextVar("sales_execution_budget", default=None)


class BudgetExceeded(RuntimeError):
    """A development execution guard stopped the next API request."""


class BillingUncertain(RuntimeError):
    """A previous request has no trustworthy accounting; do not spend again."""


@dataclass(frozen=True)
class ExecutionLimits:
    max_api_calls: int = 400
    max_output_tokens: int = 8192
    max_token_units: int = 2_000_000

    def __post_init__(self):
        for name, value in asdict(self).items():
            if type(value) is not int or value < 1:
                raise ValueError(f"{name} must be a positive integer.")


def current_budget():
    """Return the execution shared by clients created in the active context."""
    return _ACTIVE_BUDGET.get()


class ExecutionBudget:
    def __init__(self, limits=None):
        self.limits = limits if limits is not None else ExecutionLimits()
        if not isinstance(self.limits, ExecutionLimits):
            raise TypeError("limits must be ExecutionLimits.")
        self.stop_reason = None
        self.billing_unknown = False
        self._observed = self._empty_usage()
        self._by_role = {}
        self._reservations = {}
        self._lock = threading.RLock()

    @staticmethod
    def _empty_usage():
        return dict(api_attempts=0, input_tokens=0, output_tokens=0,
                    cached_input_tokens=0, token_units=0)

    @contextmanager
    def activate(self):
        """Clients created here retain this budget for their entire lifetime."""
        token = _ACTIVE_BUDGET.set(self)
        try:
            yield self
        finally:
            _ACTIVE_BUDGET.reset(token)

    def prepare(self, request):
        """Cap response generation without changing the input or its history."""
        request = dict(request)
        requested = request.get("max_output_tokens", self.limits.max_output_tokens)
        if type(requested) is not int or requested < 1:
            raise ValueError("max_output_tokens must be a positive integer.")
        request["max_output_tokens"] = min(requested, self.limits.max_output_tokens)
        return request

    @staticmethod
    def worst_case(request):
        """(input, output) tokens an attempt could at most be billed for.

        JSON escaping and the byte count deliberately overestimate ordinary text
        tokenization; the extra allowance covers message framing.
        """
        input_bytes = len(json.dumps(request, ensure_ascii=True, allow_nan=False).encode("utf-8"))
        return input_bytes + 256, request["max_output_tokens"]

    @classmethod
    def worst_case_units(cls, request):
        input_tokens, output_tokens = cls.worst_case(request)
        return input_tokens + 6 * output_tokens

    def reserve(self, key, request):
        """Reserve one attempt, including possible output, before transport."""
        estimate = self.worst_case_units(request)
        with self._lock:
            self.check()
            pending = sum(item["units"] for item in self._reservations.values())
            unstarted = sum(not item["started"] for item in self._reservations.values())
            if self._observed["api_attempts"] + unstarted >= self.limits.max_api_calls:
                self.stop_reason = "api_call_limit"
                raise BudgetExceeded("API attempt limit reached; no further request was sent.")
            if self._observed["token_units"] + pending + estimate > self.limits.max_token_units:
                self.stop_reason = "token_unit_limit"
                raise BudgetExceeded("The next complete request exceeds the remaining token-unit allowance; no request was sent.")
            self._reservations[key] = {"units": estimate, "started": False}

    def check(self):
        """Raise if another paid call or trial must not start."""
        with self._lock:
            if self.billing_unknown:
                raise BillingUncertain("API billing is unresolved. Inspect the receipts before starting another run.")
            if self.stop_reason:
                raise BudgetExceeded(f"Execution stopped: {self.stop_reason}.")

    def observe(self, event):
        """Consume the same durable events used by reporting, exactly once."""
        key = (event["call_id"], event["attempt"])
        role = event["role"]
        with self._lock:
            role_usage = self._by_role.setdefault(role, self._empty_usage())
            if event["event"] == "started":
                self._reservations[key]["started"] = True
                for usage in (self._observed, role_usage):
                    usage["api_attempts"] += 1
                return
            self._reservations.pop(key, None)
            if event["event"] == "error":
                if event.get("billing") == "assumed":
                    # A dropped connection or timeout: the attempt is charged at the most
                    # it could have cost, so the limits stay safe and the run can retry.
                    units = event.get("assumed_token_units")
                    if type(units) is not int or units < 0:
                        self.mark_unknown()
                        return
                    for usage in (self._observed, role_usage):
                        usage["token_units"] += units
                    if self._observed["token_units"] > self.limits.max_token_units and not self.billing_unknown:
                        self.stop_reason = "token_unit_limit"
                elif event.get("billing") != "rejected":
                    self.mark_unknown()
                return
            receipt = event["usage"]
            for field in ("input_tokens", "output_tokens", "cached_input_tokens"):
                value = receipt.get(field)
                if type(value) is int and value >= 0:
                    self._observed[field] += value
                    role_usage[field] += value
            if any(type(receipt.get(field)) is not int for field in ("input_tokens", "output_tokens")):
                self.mark_unknown()
                return
            units = receipt["input_tokens"] + 6 * receipt["output_tokens"]
            self._observed["token_units"] += units
            role_usage["token_units"] += units
            if type(receipt.get("cached_input_tokens")) is not int:
                self.mark_unknown()
            if self._observed["token_units"] > self.limits.max_token_units and not self.billing_unknown:
                self.stop_reason = "token_unit_limit"

    def mark_unknown(self):
        with self._lock:
            self.billing_unknown = True
            self.stop_reason = "billing_uncertain"

    def logging_failed(self, key, *, sent):
        """Never make an unlogged request or continue after a lost receipt."""
        with self._lock:
            self._reservations.pop(key, None)
            if sent:
                self.mark_unknown()
            else:
                self.stop_reason = "telemetry_error"

    def snapshot(self):
        with self._lock:
            return {
                "limits": asdict(self.limits),
                "observed": dict(self._observed),
                "by_role": {role: dict(usage) for role, usage in sorted(self._by_role.items())},
                "reserved_token_units": sum(item["units"] for item in self._reservations.values()),
                "billing_unknown": self.billing_unknown,
                "stop_reason": self.stop_reason,
            }
