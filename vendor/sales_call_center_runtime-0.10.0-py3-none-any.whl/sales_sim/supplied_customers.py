"""Fixed development customers using the shared dialogue and eligibility rules."""

from copy import deepcopy
from dataclasses import asdict

from sales_sim.customers import CustomerProfile, OpenAICustomers
from sales_sim.models import Document


def build_customers(config, scenario):
    """Profiles may add purchase_concerns with id, question and document_ids."""
    profiles = tuple(
        CustomerProfile(
            customer_id=item["customer_id"],
            persona=item["persona"],
            monthly_budget_cents=item["monthly_budget_cents"],
            required_features=tuple(item.get("required_features", [])),
            required_integration=item.get("required_integration"),
            decision_day=item.get("decision_day", 1),
        )
        for item in config["profiles"]
    )
    return DevelopmentCustomers(
        profiles, scenario.products, config["model"], documents=scenario.documents,
        purchase_concerns={item["customer_id"]: item.get("purchase_concerns", [])
                           for item in config["profiles"]},
    )


class DevelopmentCustomers(OpenAICustomers):
    """Supply account-specific concerns and available documents to one adapter.

    Dialogue remains model-generated; eligibility gates acceptance and suitable
    purchases are retained. These are simulation assumptions, not quality grades.
    """

    def __init__(self, profiles, products, model, client=None, *, documents=(),
                 purchase_concerns=None):
        documents = tuple(documents)
        concerns = deepcopy(purchase_concerns) if purchase_concerns is not None else {}
        document_ids = {document.id for document in documents}
        if not isinstance(concerns, dict) or set(concerns) - {p.customer_id for p in profiles}:
            raise ValueError("Purchase concerns must belong to a configured customer.")
        for items in concerns.values():
            if not isinstance(items, list):
                raise ValueError("purchase_concerns must be a list.")
            seen = set()
            for item in items:
                if (not isinstance(item, dict)
                    or set(item) != {"id", "question", "document_ids"}
                    or not isinstance(item["id"], str) or not item["id"].strip()
                    or not isinstance(item["question"], str) or not item["question"].strip()
                    or not isinstance(item["document_ids"], list) or not item["document_ids"]
                    or any(not isinstance(source, str) or source not in document_ids
                           for source in item["document_ids"])):
                    raise ValueError("Each purchase concern needs an ID, question and valid document IDs.")
                if item["id"] in seen:
                    raise ValueError("Purchase concern IDs must be unique per customer.")
                seen.add(item["id"])
        super().__init__(profiles, products, model, client)
        self._documents = documents
        self._purchase_concerns = concerns

    def respond(self, turn):
        return super().respond(turn, dialogue_constraints={
            "purchase_concerns": deepcopy(self._purchase_concerns.get(turn.customer.id, [])),
            "company_documents": [asdict(document) for document in self._documents
                                  if document.available_day <= turn.day],
        })

    def export_state(self):
        return {
            **super().export_state(), "kind": "development",
            "documents": [asdict(document) for document in self._documents],
            "purchase_concerns": deepcopy(self._purchase_concerns),
        }

    def restore_state(self, state):
        expected = self.export_state()
        if not isinstance(state, dict) or set(state) != set(expected) or any(
            state.get(key) != expected[key] for key in ("kind", "documents", "purchase_concerns")
        ):
            raise ValueError("Development customer documents or concerns changed.")
        original = {key: value for key, value in state.items()
                    if key not in {"documents", "purchase_concerns"}}
        super().restore_state({**original, "kind": "openai"})

    @classmethod
    def from_state(cls, state, products, client=None):
        profiles = tuple(CustomerProfile(**{**item, "required_features": tuple(item["required_features"])})
                         for item in state["profiles"])
        simulator = cls(profiles, products, state["model"], client,
                        documents=tuple(Document(**item) for item in state["documents"]),
                        purchase_concerns=state["purchase_concerns"])
        simulator.restore_state(state)
        return simulator
