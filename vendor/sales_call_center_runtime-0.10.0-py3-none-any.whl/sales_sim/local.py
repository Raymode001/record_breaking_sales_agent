"""Local development: one Python process, the same business rules, no recovery.

Every attempt has an initial failed/unknown result before any paid call. A normal
return replaces it. An interrupted attempt stays visible and is never resumed.
Official evaluation uses the separate staff runner.
"""

import hashlib
import inspect
import json
import os
import time
from contextlib import contextmanager, nullcontext
from copy import deepcopy
from dataclasses import asdict, is_dataclass
from pathlib import Path

from . import agent as agent_module
from . import harness
from .api_client import read_api_events, summarize_api_events
from .crm import load_dataset
from .environment import SalesEnvironment
from .evaluation_report import (
    FAILED_STOPS,
    FINAL_METRICS,
    _metrics,
    _summarize_receipt_evidence,
    api_cost_usd,
    build_report,
    summarize_usage,
    write_report,
)
from .execution import BillingUncertain, BudgetExceeded, ExecutionBudget, ExecutionLimits
from .response_cache import ResponseCache, cache_directory, cache_enabled, cap_from_environment, replay_summary
from .model_client import SuppliedModelClient
from .practice import ReferenceSeller, case_catalog, checks_for
from .files import _atomic_write, _json
from .student_submission import FrozenSubmission, load_submission
from .suites import load_agent, load_suite
from .tools import LocalToolClient
from .transcript import write_run_files
from .viewer import write_index, write_viewer

# Batch reasons that stop later trials. A trial that reaches its own execution
# guard still settles (the model falls silent), so the next trial may start.
BATCH_STOPS = {"interrupted", "billing_uncertain", "telemetry_error", "spend_cap"}


def _save(path, value):
    _atomic_write(path, _json(value))


def _prices(root):
    """Published per-million-token prices from course.json, when the starter has them."""
    try:
        prices = json.loads((Path(root) / "course.json").read_text(encoding="utf-8"))["prices_usd_per_million_tokens"]
    except (OSError, ValueError, KeyError, TypeError):
        return {}
    return prices if isinstance(prices, dict) else {}


@contextmanager
def _service_tier(root):
    """Apply course.json's optional service_tier to every API client created in this run."""
    try:
        tier = json.loads((Path(root) / "course.json").read_text(encoding="utf-8")).get("service_tier")
    except (OSError, ValueError, AttributeError):
        tier = None
    name, previous = "SALES_SIM_SERVICE_TIER", os.environ.get("SALES_SIM_SERVICE_TIER")
    if tier:
        os.environ[name] = tier
    try:
        yield tier
    finally:
        if previous is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = previous


def _course_value(root, name):
    try:
        return json.loads((Path(root) / "course.json").read_text(encoding="utf-8")).get(name)
    except (OSError, ValueError, AttributeError):
        return None


def course_reasoning(root):
    """The seller's reasoning effort from course.json; None leaves the model's default."""
    try:
        return json.loads((Path(root) / "course.json").read_text(encoding="utf-8")).get("reasoning_effort")
    except (OSError, ValueError, AttributeError):
        return None


def _dollars(value):
    return "unknown" if value is None else f"${value:,.4f}"


def _money(cents):
    return "unknown" if cents is None else f"{'-' if cents < 0 else ''}${abs(cents) / 100:,.2f}"


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


@contextmanager
def _telemetry(path):
    # This runner is sequential. Clients bind this path when they are created;
    # roles in each receipt keep seller and customer requests separate.
    name = "SALES_SIM_API_EVENTS_PATH"
    previous = os.environ.get(name)
    os.environ[name] = str(path)
    try:
        yield
    finally:
        if previous is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = previous


class RecordedTools:
    """Flush each receipt; a failed customer request must end the attempt."""

    def __init__(self, environment, directory):
        self.client = LocalToolClient(environment)
        self.path = directory / "tools.jsonl"
        self.failure = None

    def definitions(self):
        return self.client.definitions()

    def call(self, name, arguments, *, request_id=None):
        if self.failure:
            raise RuntimeError("This attempt already failed; start a fresh campaign.")
        try:
            return self.client.call(name, arguments, request_id=request_id)
        except (BudgetExceeded, BillingUncertain):
            # The environment commits nothing when a customer call cannot be paid
            # for, so the campaign can still advance and settle without it.
            raise
        except Exception as error:
            self.failure = f"{type(error).__name__}: {error}"
            _save(self.path.parent / "tool_failure.json", {
                "name": name, "arguments": arguments, "request_id": request_id,
                "error": self.failure,
            })
            raise
        finally:
            try:
                _atomic_write(self.path, "".join(json.dumps(row) + "\n" for row in self.client.trace))
            except Exception as error:
                self.failure = self.failure or f"Trace could not be saved: {error}"
                raise


def _usage(records, events, role, *, complete):
    """Compatibility for legacy staff agents that supply their own receipts."""
    selected = [event for event in events if event["role"] == role]
    # Receipts are joined by response ID, so a metered helper is not counted twice.
    telemetry = [
        {"response_id": event.get("response_id"), **event["usage"]}
        for event in selected if event["event"] == "completed"
    ]
    telemetry = list({
        record.get("response_id") or ("anonymous", index): record
        for index, record in enumerate(telemetry)
    }.values())
    separate = None
    joined = records if not telemetry else telemetry if not records else list(records)
    if records and telemetry:
        if any(not record.get("response_id") for record in [*records, *telemetry]):
            separate = telemetry
        else:
            identities = {record["response_id"] for record in records}
            for record in telemetry:
                if record["response_id"] not in identities:
                    joined.append(record)
                    identities.add(record["response_id"])
    started = {(event["call_id"], event["attempt"]) for event in selected if event["event"] == "started"}
    ended = {(event["call_id"], event["attempt"]) for event in selected if event["event"] == "completed"}
    complete = complete and records is not None and started == ended
    return _summarize_receipt_evidence(joined, separate, complete=complete)


def _initial_row(case, agent, model, repeat, dataset, fingerprint):
    return {
        "case_id": case.id, "agent_id": agent, "repeat": repeat,
        "status": "failed", "agent_stop_reason": "interrupted",
        "failure_category": "unresolved", "error": "Attempt did not finish recording a result.",
        "runtime_seconds": 0.0, "runtime_complete": False,
        "customer_count": len(dataset.scenario.customers),
        "campaign_finished": False, "metrics": {},
        "seller_usage": summarize_usage(None), "customer_usage": summarize_usage(None),
        "seller_cost_usd": None, "customer_cost_usd": None,
        "seller_model": model, "customer_model": case.customer_model,
        "case_fingerprint": fingerprint, "dataset_sha256": _hash(dataset.to_dict()),
    }


def _metered_usage(events, summary, role):
    """The fixed student path has one receipt source: the instrumented client."""
    records = [
        {"response_id": event.get("response_id"), **event["usage"]}
        for event in events if event["role"] == role and event["event"] == "completed"
    ]
    role_summary = summary.get("by_role", {}).get(role, {})
    complete = (not summary.get("parse_errors")
                and summary.get("read_error") in {None, "FileNotFoundError"}
                and role_summary.get("billing_complete", True))
    return _summarize_receipt_evidence(records, None, complete=complete)


def _receipts_match_meter(snapshot, summary):
    """A cleanly truncated log must not certify fewer calls or tokens."""
    if snapshot["observed"]["api_attempts"] != summary["attempts_started"]:
        return False
    for role, observed in snapshot["by_role"].items():
        saved = summary.get("by_role", {}).get(role, {})
        if observed["api_attempts"] != saved.get("attempts_started", 0):
            return False
        for field in ("input_tokens", "output_tokens", "cached_input_tokens"):
            if observed[field] != saved.get("known_usage", {}).get(field, 0):
                return False
    return True


def _attempt(case, factory, dataset, config, seller, seller_factory, model, max_steps, directory, row, *,
             limits=None, prices=None, reasoning_effort=None):
    started = time.perf_counter()
    customers = llm = tools = environment = agent = None
    result = {"status": "exception"}
    error = None
    events_path = directory / "api_events.jsonl"
    custom_records = []
    fixed_runtime = seller == "reference" or isinstance(seller_factory, FrozenSubmission)
    budget = ExecutionBudget(limits) if fixed_runtime else None

    def record_custom(record):
        custom_records.append(record)
        _atomic_write(directory / "custom_tools.jsonl", "".join(json.dumps(item) + "\n" for item in custom_records))

    budget_context = budget.activate() if budget else nullcontext()
    with _telemetry(events_path), budget_context:
        try:
            customers = factory(deepcopy(config), dataset.scenario)
            environment = SalesEnvironment(dataset.scenario, customers, dataset.crm)
            tools = RecordedTools(environment, directory)
            if seller == "reference":
                agent = ReferenceSeller(tools, on_record=record_custom)
            else:
                llm = SuppliedModelClient(model)
                extra = ({"on_record": record_custom, "reasoning_effort": reasoning_effort}
                         if isinstance(seller_factory, FrozenSubmission) else {})
                agent = seller_factory(tools, llm, model=model, checkpoint=None, **extra)
            result = agent.run(max_steps=max_steps)
            if is_dataclass(result):
                result = asdict(result)
            if not isinstance(result, dict) or not isinstance(result.get("status"), str):
                raise TypeError("Agent.run must return a result with a string status.")
            error = result.get("error")
        except (Exception, KeyboardInterrupt) as failure:  # noqa: BLE001 -- retain each failed attempt
            result = {"status": "interrupted" if isinstance(failure, KeyboardInterrupt) else "exception"}
            error = f"{type(failure).__name__}: {failure}"
    status = environment.get_status() if environment else None
    failed = result["status"] in FAILED_STOPS or bool(tools and tools.failure)
    row.update(
        status="failed" if failed else "completed" if status and status["finished"] else "incomplete",
        agent_stop_reason=result["status"], error=error or (tools.failure if tools else None),
        failure_category="execution_or_infrastructure" if failed else None,
        runtime_seconds=time.perf_counter() - started, runtime_complete=True,
        final_day=status["day"] if status else None,
        campaign_finished=bool(status and status["finished"]),
        tool_calls=len(tools.client.trace) if tools else 0,
        custom_tool_calls=len(custom_records),
    )
    row["metrics"] = _metrics({"environment": status, "customers_count": row["customer_count"]} if status else None)
    if row["status"] != "completed":
        for field in FINAL_METRICS:
            row["metrics"][field] = None
    events = read_api_events(events_path)
    row["api_requests"] = summarize_api_events(events_path)
    if budget:
        row["execution"] = budget.snapshot()
        row["seller_usage"] = _metered_usage(events, row["api_requests"], "seller")
        row["customer_usage"] = _metered_usage(events, row["api_requests"], "customer")
        # A killed or partially written request is not certified by in-memory totals.
        missing_receipts = (not _receipts_match_meter(row["execution"], row["api_requests"])
                            or (row["execution"]["observed"]["api_attempts"] > 0
                                and not row["api_requests"]["available"]))
        persistence_failure = budget.billing_unknown and row["api_requests"]["billing_complete"]
        if (missing_receipts or persistence_failure or row["api_requests"]["parse_errors"]
                or row["api_requests"]["pending_attempts"]):
            budget.mark_unknown()
            row["execution"] = budget.snapshot()
            for role in ("seller", "customer"):
                row[f"{role}_usage"] = _metered_usage(
                    events, {**row["api_requests"], "parse_errors": 1}, role)
        row["billing_unknown"] = budget.billing_unknown
        _save(directory / "execution.json", row["execution"])
    else:
        seller_records = llm.usage if llm else None
        customer_records = getattr(customers, "usage", None)
        telemetry_valid = not row["api_requests"]["parse_errors"] and (
            row["api_requests"]["available"] or not (seller_records or customer_records)
        )
        row["seller_usage"] = _usage(seller_records, events, "seller", complete=not failed and telemetry_valid)
        row["customer_usage"] = _usage(customer_records, events, "customer", complete=not failed and telemetry_valid)
        row["billing_unknown"] = bool(events) and not row["api_requests"]["billing_complete"]
    # Estimates at the published prices; unknown when token totals are incomplete.
    row["seller_cost_usd"] = api_cost_usd(row["seller_usage"], model, prices)
    row["customer_cost_usd"] = api_cost_usd(row["customer_usage"], config.get("model"), prices)
    # Responses replayed from the development cache keep their original usage above;
    # only what this attempt newly paid for is counted here.
    replay = replay_summary(events, prices, {"seller": model, "customer": config.get("model")})
    row["replayed_responses"] = replay["replayed_responses"]
    row["new_api_cost_usd"] = replay["new_api_cost_usd"]
    _save(directory / "seller_result.json", result)
    _save(directory / "seller_history.json", getattr(agent, "history", []))
    if isinstance(agent, harness.Seller):
        try:
            write_run_files(directory, agent, tools.client.trace if tools else [], row)
        except Exception as failure:  # noqa: BLE001 -- readable extras must never hide the result
            _save(directory / "transcript_error.json", {"error": f"{type(failure).__name__}: {failure}"})
    if hasattr(customers, "diagnostics"):
        # Offline simulator evidence, never included in seller tool results.
        _save(directory / "customer_diagnostics.json", customers.diagnostics)
    if hasattr(agent, "tool_state"):
        try:
            _save(directory / "custom_tool_state.json", agent.tool_state)
        except (TypeError, ValueError) as failure:
            _save(directory / "custom_tool_state.json", {"export_error": str(failure)})
    _save(directory / "result.json", row)
    return row


def _cache_settings(root, arguments):
    """How this batch uses the development response cache (response_cache.py)."""
    enabled = arguments.agent != "reference" and cache_enabled()
    return {"enabled": enabled, "fresh_salt": getattr(arguments, "fresh_salt", None) or None,
            "directory": str(cache_directory(root)) if enabled else None}


def _response_cache(root, arguments, prices):
    """Replay paid responses of unchanged trials and keep the spending ledger.

    Off for the offline script and when SALES_SIM_CACHE=off. SALES_SIM_BUDGET_USD
    sets a personal cap on the ledger's total.
    """
    if arguments.agent == "reference" or not cache_enabled():
        return None
    return ResponseCache(cache_directory(root), prices=prices, cap_usd=cap_from_environment())


def _trial_salt(arguments, label, case_id, repeat):
    """One replay stream per trial slot: repeats stay independent, reruns replay.

    --fresh adds a random salt, so a rerun draws new samples instead.
    """
    fresh = getattr(arguments, "fresh_salt", None)
    return "|".join(str(part) for part in (label, case_id, repeat, fresh) if part)


def prepare_inputs(arguments, root):
    """Load scenario data and customer settings once for a matched experiment."""
    suite = root / "practice/suite.json" if arguments.case else arguments.suite
    cases = load_suite(suite, customer_model=arguments.customer_model,
                       case_ids=[arguments.case] if arguments.case else None)
    inputs = []
    for case in cases:
        dataset = load_dataset(case.dataset_path)
        config = json.loads(case.customer_config_path.read_text())
        if case.customer_model:
            config["model"] = case.customer_model
        factory = load_agent(case.customer_factory)
        source = Path(inspect.getfile(factory)).read_text()
        fingerprint = _hash([dataset.to_dict(), config, source, factory.__qualname__])
        inputs.append((case, factory, dataset, config, source, fingerprint))
    return inputs


def run(arguments, root, *, submission=None, inputs=None):
    if arguments.repeats < 1 or arguments.max_steps < 1:
        raise ValueError("Repeats and max steps must be positive.")
    if arguments.agent != "reference" and not arguments.model:
        raise ValueError("Choose --model for the seller.")
    if arguments.agent == "reference" and not arguments.case:
        raise ValueError("The offline reference is only defined for the five practice cases.")
    limits = ExecutionLimits(**{
        name: getattr(arguments, name, default)
        for name, default in asdict(ExecutionLimits()).items()
    })
    inputs = prepare_inputs(arguments, root) if inputs is None else inputs
    variant = getattr(arguments, "variant", "tools") if arguments.agent is None else None
    if arguments.agent is None:
        seller_factory = submission or load_submission(root, variant)
    elif arguments.agent == "reference":
        seller_factory = None
    else:
        seller_factory = load_agent(arguments.agent)
    if submission is not None and (arguments.agent is not None or submission.variant != variant):
        raise ValueError("The frozen submission must match the requested variant.")
    if variant:   # the loop and the harness that runs it determine the seller's behavior
        seller_source = "".join(Path(inspect.getfile(module)).read_text()
                                for module in (agent_module, harness))
    else:
        seller_source = Path(inspect.getfile(seller_factory or ReferenceSeller)).read_text()
    output = arguments.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    _save(output / "settings.json", {"agent": arguments.agent or "supplied", "variant": variant,
          "model": arguments.model, "service_tier": _course_value(root, "service_tier"), "reasoning_effort": (getattr(arguments, "reasoning_effort", None)
                                                         or course_reasoning(root)) if variant else None,
          "customer_model": arguments.customer_model, "max_steps": arguments.max_steps,
          "repeats": arguments.repeats, "runner": "local", "resume": False,
          "response_cache": _cache_settings(root, arguments),
          "execution_limits": asdict(limits),
          "inputs": [{"case_id": case.id, "fingerprint": fingerprint,
                      "dataset_sha256": _hash(dataset.to_dict()), "customer_model": config.get("model")}
                     for case, _, dataset, config, _, fingerprint in inputs],
          "seller_source_sha256": hashlib.sha256(seller_source.encode()).hexdigest(),
          "submission_source_sha256": _hash(seller_factory.sources) if variant else None,
          "source_sha256": {name: hashlib.sha256(source.encode()).hexdigest()
                            for name, source in seller_factory.sources.items()} if variant else {}})
    (output / "seller_source.py").write_text(seller_source)
    if variant:
        (output / "submission").mkdir()
        for name, source in seller_factory.sources.items():
            (output / "submission" / name).write_text(source, encoding="utf-8")
    catalog = {item["id"]: item for item in case_catalog(root / "practice")}
    prices = _prices(root)
    cache = _response_cache(root, arguments, prices)
    reasoning_effort = getattr(arguments, "reasoning_effort", None) or course_reasoning(root)
    rows = []
    batch = {"state": "running", "stopped": False, "reason": None,
             "planned_attempts": len(inputs) * arguments.repeats,
             "started_attempts": 0, "completed_attempts": 0}
    _save(output / "batch_status.json", batch)
    for case, factory, dataset, config, customer_source, fingerprint in inputs:
        for repeat in range(1, arguments.repeats + 1):
            directory = output / "runs" / f"{case.id}__{repeat:03d}"
            directory.mkdir(parents=True)
            _save(directory / "inputs.json", {"dataset": dataset.to_dict(), "customer_config": config,
                                              "customer_factory": case.customer_factory})
            (directory / "customer_source.py").write_text(customer_source)
            row = _initial_row(case, arguments.name or variant or arguments.agent, arguments.model, repeat, dataset, fingerprint)
            row["variant"] = variant
            _save(directory / "result.json", row)
            rows.append(row)
            batch["started_attempts"] += 1
            _save(output / "batch_status.json", batch)
            write_report(output, rows)
            label = arguments.name or variant or arguments.agent
            trial_cache = cache.scoped(salt=_trial_salt(arguments, label, case.id, repeat),
                                       tag=f"{label}/{case.id}/{repeat:03d}") if cache else None
            with _service_tier(root), (trial_cache.activate() if trial_cache else nullcontext()):
                _attempt(case, factory, dataset, config, arguments.agent, seller_factory, arguments.model,
                         arguments.max_steps, directory, row, limits=limits, prices=prices,
                         reasoning_effort=reasoning_effort)
            trace_file = directory / "tools.jsonl"
            trace = [json.loads(line) for line in trace_file.read_text().splitlines()] if trace_file.exists() else []
            checks = checks_for(case.id, row, trace) if arguments.case else [{
                "name": "campaign_completed", "status": "pass" if row["status"] == "completed" else "fail",
                "explanation": "Completion is measured from the environment. Review sales claims separately.",
                "tool_lines": [],
            }]
            _save(directory / "evidence.json", {
                "case": {"id": case.id, "description": catalog.get(case.id, {}).get("description", "Development campaign")},
                "public_dataset": dataset.to_dict(), "result": row, "trace": trace,
                "trace_path": "tools.jsonl", "checks": checks,
            })
            write_report(output, rows)
            spending = ("offline script, no model" if arguments.agent == "reference" else
                        f"{row['seller_usage']['responses']} model calls · seller API cost {_dollars(row['seller_cost_usd'])}")
            if row.get("replayed_responses"):
                spending += (f" · {row['replayed_responses']} API responses replayed from the cache, "
                             f"new spending {_dollars(row.get('new_api_cost_usd'))} (use --fresh for new samples)")
            print(f"{case.id} repeat {repeat}: {row['status']} · profit {_money(row['metrics'].get('profit_cents'))} "
                  f"· {spending}")
            batch["completed_attempts"] += 1
            reason = ("interrupted" if row["agent_stop_reason"] == "interrupted" else
                      "billing_uncertain" if row.get("billing_unknown") else
                      row.get("execution", {}).get("stop_reason"))
            if cache is not None and cache.cap_reached:
                reason = "spend_cap"
            if reason in BATCH_STOPS:
                batch.update(state="interrupted" if reason == "interrupted" else "stopped",
                             stopped=True, reason=reason)
                _save(output / "batch_status.json", batch)
                print(f"Batch stopped: {reason}. Remaining trials were not launched.")
                return 1
            _save(output / "batch_status.json", batch)
    batch["state"] = "completed"
    _save(output / "batch_status.json", batch)
    return 0 if all(row["status"] == "completed" for row in rows) else 1


def _inspection_evidence(directory, row):
    """Keep partial attempts inspectable without changing their recorded results."""
    warnings = []

    def read_object(name):
        try:
            value = json.loads((directory / name).read_text(encoding="utf-8"))
            if not isinstance(value, dict):
                raise ValueError("Expected a JSON object.")
            return value
        except (OSError, ValueError) as error:
            warnings.append(f"{name} is missing or unreadable ({type(error).__name__}).")
            return {}

    evidence = read_object("evidence.json")
    if not evidence or not all(isinstance(evidence.get(key), list) for key in ("trace", "checks")):
        warnings.append(
            "The evidence snapshot is incomplete. This view contains only saved "
            "receipts; missing replies and final outcomes remain unknown."
        )
        inputs = read_object("inputs.json")
        # inputs also holds private simulator preferences. Never include them.
        dataset = inputs.get("dataset", {})
        trace = []
        trace_path = directory / "tools.jsonl"
        if trace_path.exists():
            try:
                lines = trace_path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError as error:
                warnings.append(f"Tool receipts could not be read ({type(error).__name__}).")
                lines = []
            for line, text in enumerate(lines, 1):
                try:
                    item = json.loads(text)
                    if not isinstance(item, dict):
                        raise ValueError("Expected a tool receipt.")
                except ValueError:
                    message = f"Tool trace line {line} is unreadable; its outcome is unknown."
                    warnings.append(message)
                    # Keep the original line numbers for subsequent action links.
                    item = {
                        "name": "unreadable_trace_entry",
                        "result": {"ok": False, "error": {"message": message}},
                    }
                trace.append(item)
        else:
            warnings.append("No tool receipts were saved.")
        evidence = {
            "case": {"id": row.get("case_id", directory.name),
                     "description": "Partial attempt; inspect the saved evidence below."},
            "public_dataset": dataset, "trace": trace, "trace_path": "tools.jsonl",
            "checks": [{
                "name": "evidence_incomplete", "status": "unavailable",
                "explanation": "Automated evidence checks are unavailable for this partial snapshot.",
                "tool_lines": [],
            }],
        }
    evidence["result"] = row
    if (directory / "tool_failure.json").exists():
        evidence["tool_failure"] = read_object("tool_failure.json")
    evidence["warnings"] = [*evidence.get("warnings", []), *warnings]
    return evidence


def inspect_output(output, *, check=False):
    """Inspect a run, an experiment, or a folder containing several experiments.

    Indexes embed the recorded run pages, so selecting a run also works in HTML
    previews that cannot follow relative file links. Only saved evidence is read.
    """
    output = Path(output).resolve()
    single_run = (output / "result.json").is_file() and output.parent.name == "runs"
    result_paths = [output / "result.json"] if single_run else sorted(
        path for path in output.rglob("result.json")
        if path.parent.parent.name == "runs"
        and path.resolve().is_relative_to(output)
        and not any(part.startswith(".") for part in path.relative_to(output).parts)
    )
    attempts, batches, failed = [], {}, False
    for result_path in result_paths:
        directory = result_path.parent
        result_warning = None
        try:
            row = json.loads(result_path.read_text(encoding="utf-8"))
            if not isinstance(row, dict):
                raise ValueError("Expected a result object.")
        except (OSError, ValueError) as error:
            result_warning = f"result.json is unreadable ({type(error).__name__}); final outcomes are unknown."
            row = {"case_id": directory.name, "status": "unknown", "error": result_warning}
        evidence = _inspection_evidence(directory, row)
        if result_warning:
            evidence["warnings"].append(result_warning)
        write_viewer(directory, evidence)
        failed |= (
            row.get("status") != "completed" or bool(evidence["warnings"])
            or any(item["status"] in {"fail", "unavailable"} for item in evidence["checks"])
        )
        batch = directory.parent.parent
        group = batch.relative_to(output).as_posix() if not single_run and batch != output else ""
        label = f"{group}/{directory.name}" if group else directory.name
        for item in evidence["checks"]:
            print(f"{label}: {item['status']} — {item['name']}")
        for warning in evidence["warnings"]:
            print(f"{label}: {warning}")
        relative = (directory / "inspect.html").relative_to(output)
        attempt = {
            "name": directory.name, "path": relative.as_posix(), "result": row,
            "checks": evidence["checks"], "warnings": evidence["warnings"], "group": group,
        }
        attempts.append(attempt)
        if not single_run:
            batches.setdefault(batch, []).append({
                **attempt, "path": (directory / "inspect.html").relative_to(batch).as_posix(),
                "group": "",
            })
    if not attempts:
        raise ValueError("No local attempts found in this output directory.")
    for batch, rows in batches.items():
        if batch != output:
            write_index(batch, rows)
    if not single_run:
        title = "Experiment" if (output / "experiment.json").is_file() else "All runs" if len(batches) > 1 else "Runs"
        write_index(output, attempts, title=title)
    print(f"Viewer: {output / 'inspect.html'}")
    return int(check and failed)


def compare(outputs, destination=None):
    rows, fingerprints = [], {}
    for index, output in enumerate(outputs, 1):
        paths = sorted((output / "runs").glob("*/result.json"))
        if not paths:
            raise ValueError(f"No local attempts found: {output}")
        for path in paths:
            row = json.loads(path.read_text())
            previous = fingerprints.setdefault(row["case_id"], row["case_fingerprint"])
            if previous != row["case_fingerprint"]:
                raise ValueError(f"Changed scenario inputs for {row['case_id']}; do not treat these as matched trials.")
            row["agent_id"] = f"{index}_{output.name}"
            rows.append(row)
    report = build_report(rows)
    if destination:
        destination.mkdir(parents=True, exist_ok=False)
        write_report(destination, rows)
    for agent in report["agents"]:
        print(f"{agent['agent_id']}: {agent['completed_runs']}/{agent['total_runs']} completed; "
              f"mean profit cents: {agent['mean_profit_cents']}")
    return report
