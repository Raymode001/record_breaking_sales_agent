"""Plain reports for comparing agents on the same evaluation cases.

Financial results are final only after a campaign completes. Missing usage is
unknown, not free, and failed runs stay visible in every completion count.
"""

import csv
import io
import json
import math
import os
import tempfile
from copy import deepcopy
from pathlib import Path

METRICS = (
    "accepted_orders",
    "retained_orders",
    "conversion_rate",
    "retained_conversion_rate",
    "refund_count",
    "booked_revenue_cents",
    "refunded_revenue_cents",
    "retained_revenue_cents",
    "service_cost_cents",
    "contact_cost_cents",
    "profit_cents",
    "missed_callbacks",
)
FINAL_METRICS = (
    "retained_orders",
    "retained_conversion_rate",
    "refund_count",
    "refunded_revenue_cents",
    "retained_revenue_cents",
    "service_cost_cents",
    "profit_cents",
)
TOKEN_FIELDS = ("input_tokens", "output_tokens", "cached_input_tokens")
OBSERVED_TOKEN_FIELDS = tuple(f"observed_{field}" for field in TOKEN_FIELDS)
USAGE_FIELDS = (
    "responses",
    *TOKEN_FIELDS,
    *OBSERVED_TOKEN_FIELDS,
    "complete",
    "receipt_overlap_unknown",
)
METHODOLOGY = (
    "Agents appear in input order, without ranking. Profit and retained sales "
    "are reported only for completed campaigns; the profit mean includes all "
    "completed campaigns and is unknown if any completed profit is missing. "
    "Conversion rates pool completed orders over completed customer counts. "
    "Mean runtime includes completed, incomplete, and failed runs and excludes "
    "runner setup. API usage includes every status; a missing token count or "
    "incomplete usage measurement makes that token total unknown. Missing "
    "response receipts can still be billed: responses counts observed receipts, "
    "and observed_* tokens are lower bounds, not complete totals. A receipt "
    "without a response ID cannot be joined safely to another source; "
    "such overlap makes totals unknown and observed counts use the larger "
    "source value instead of adding possibly duplicated usage. An execution "
    "timeout records the wall-clock guard without attributing its cause to "
    "either the agent or infrastructure. Missing "
    "values remain null in JSON, blank in CSV, and unknown in this document. "
    "Pair comparisons use the same case and repeat, only when both agents "
    "completed. Planned pairs include the union of scheduled case/repeat keys, "
    "so failed or missing counterparts remain visible. A pair difference is "
    "the agent result minus the first agent's result. These are descriptive "
    "results, not significance estimates. API token counts are reported "
    "separately from business profit. Dollar costs are estimates at the "
    "published prices in course.json, unknown when token totals are incomplete."
)


def _sum_known(values):
    values = list(values)
    if not values or any(value is None for value in values):
        return None
    return sum(values)


def _mean_known(values):
    values = list(values)
    total = _sum_known(values)
    return None if total is None else total / len(values)


def _usage_summary(usages):
    complete = all(usage["complete"] for usage in usages)
    summary = {
        "responses": sum(usage["responses"] for usage in usages),
        "complete": complete,
        "receipt_overlap_unknown": any(
            usage["receipt_overlap_unknown"] for usage in usages
        ),
    }
    for name in TOKEN_FIELDS:
        summary[name] = (
            _sum_known(usage[name] for usage in usages) if complete else None
        )
        observed = [usage[f"observed_{name}"] for usage in usages]
        known = [value for value in observed if value is not None]
        summary[f"observed_{name}"] = sum(known) if known else None
    return summary


def _prepare_rows(rows):
    """Check run identity and normalize absent measurements to explicit nulls."""
    prepared = deepcopy(rows)
    seen = set()
    for row in prepared:
        for name in ("case_id", "agent_id"):
            if not isinstance(row.get(name), str) or not row[name]:
                raise ValueError(f"Each run needs a nonempty {name}.")
        if type(row.get("repeat")) is not int or row["repeat"] < 1:
            raise ValueError("Each run needs a positive integer repeat.")
        key = row["agent_id"], row["case_id"], row["repeat"]
        if key in seen:
            raise ValueError(f"Duplicate evaluation run: {key}.")
        seen.add(key)
        if row.get("status") not in ("completed", "incomplete", "failed"):
            raise ValueError("Unknown evaluation run status.")
        runtime = row.get("runtime_seconds")
        if (
            type(runtime) not in (int, float)
            or not math.isfinite(runtime)
            or runtime < 0
        ):
            raise ValueError("Runtime must be a finite nonnegative number.")
        count = row.setdefault("customer_count", None)
        if count is not None and (type(count) is not int or count < 0):
            raise ValueError("Customer count must be a nonnegative integer or null.")
        row.setdefault("agent_stop_reason", None)
        row.setdefault("failure_category", None)
        row.setdefault("error", None)
        row.setdefault("tool_calls", None)
        row.setdefault("final_day", None)
        metrics = row.setdefault("metrics", {})
        for name in METRICS:
            metrics.setdefault(name, None)
        if row["status"] != "completed":
            for name in FINAL_METRICS:
                metrics[name] = None
        for name in ("seller_usage", "customer_usage"):
            usage = row[name]
            if type(usage.get("responses")) is not int or usage["responses"] < 0:
                raise ValueError("Usage response counts must be nonnegative integers.")
            if type(usage.get("complete")) is not bool:
                raise ValueError("Usage needs an explicit complete flag.")
            usage.setdefault("receipt_overlap_unknown", False)
            if type(usage["receipt_overlap_unknown"]) is not bool:
                raise ValueError("Receipt overlap needs an explicit boolean flag.")
            if usage["receipt_overlap_unknown"]:
                usage["complete"] = False
            for field in TOKEN_FIELDS:
                value = usage.setdefault(field, None)
                if value is not None and (type(value) is not int or value < 0):
                    raise ValueError(
                        "Token counts must be nonnegative integers or null."
                    )
                observed = usage.setdefault(f"observed_{field}", value)
                if observed is not None and (type(observed) is not int or observed < 0):
                    raise ValueError(
                        "Observed token counts must be nonnegative integers or null."
                    )
            if not usage["complete"]:
                for field in TOKEN_FIELDS:
                    usage[field] = None
    # Reject non-JSON values and NaN before writing any report file.
    json.dumps(prepared, allow_nan=False)
    return prepared


def _agent_summary(agent_id, rows):
    completed = [row for row in rows if row["status"] == "completed"]
    totals = {
        name: _sum_known(row["metrics"][name] for row in completed)
        for name in METRICS
        if name not in ("conversion_rate", "retained_conversion_rate")
    }
    customers = _sum_known(row["customer_count"] for row in completed)
    seller_usage = _usage_summary([row["seller_usage"] for row in rows])
    customer_usage = _usage_summary([row["customer_usage"] for row in rows])
    summary = {
        "agent_id": agent_id,
        "total_runs": len(rows),
        "completed_runs": len(completed),
        "incomplete_runs": sum(row["status"] == "incomplete" for row in rows),
        "failed_runs": sum(row["status"] == "failed" for row in rows),
        "profit_runs": sum(
            row["metrics"]["profit_cents"] is not None for row in completed
        ),
        "mean_profit_cents": _mean_known(
            row["metrics"]["profit_cents"] for row in completed
        ),
        "mean_runtime_seconds": _mean_known(
            row["runtime_seconds"] if row.get("runtime_complete", True) else None
            for row in rows
        ),
        "customer_count_completed": customers,
        "completed_metrics": totals,
        "seller_usage": seller_usage,
        "customer_usage": customer_usage,
        "total_usage": _usage_summary([seller_usage, customer_usage]),
        "tool_calls": _sum_known(row["tool_calls"] for row in rows),
        # Lecture 4: what the window costs. Unknown if any trial's cost is unknown.
        "mean_seller_cost_usd": _mean_known(row.get("seller_cost_usd") for row in rows),
        "mean_customer_cost_usd": _mean_known(row.get("customer_cost_usd") for row in rows),
        "mean_profit_minus_seller_cost_usd": _mean_known(
            None if row["metrics"]["profit_cents"] is None or row.get("seller_cost_usd") is None
            else row["metrics"]["profit_cents"] / 100 - row["seller_cost_usd"]
            for row in completed
        ),
        "failure_categories": {
            category: sum(row["failure_category"] == category for row in rows)
            for category in sorted({row["failure_category"] for row in rows} - {None})
        },
    }
    for name, count_name in (
        ("conversion_rate", "accepted_orders"),
        ("retained_conversion_rate", "retained_orders"),
    ):
        orders = totals[count_name]
        summary[name] = orders / customers if customers and orders is not None else None
    return summary


def _pair_comparison(reference_id, agent_id, reference_rows, agent_rows):
    reference = {(row["case_id"], row["repeat"]): row for row in reference_rows}
    agent = {(row["case_id"], row["repeat"]): row for row in agent_rows}
    keys = list(dict.fromkeys([*reference, *agent]))
    pairs = []
    for key in keys:
        left, right = reference.get(key), agent.get(key)
        included = bool(
            left and right and left["status"] == right["status"] == "completed"
        )
        pair = {
            "case_id": key[0],
            "repeat": key[1],
            "reference_status": left["status"] if left else "missing",
            "agent_status": right["status"] if right else "missing",
            "included": included,
            "profit_difference_cents": None,
            "retained_conversion_rate_difference": None,
            "runtime_difference_seconds": None,
        }
        if included:
            for name in ("profit_cents", "retained_conversion_rate"):
                before, after = left["metrics"][name], right["metrics"][name]
                field = (
                    "profit_difference_cents"
                    if name == "profit_cents"
                    else "retained_conversion_rate_difference"
                )
                if before is not None and after is not None:
                    pair[field] = after - before
            if left.get("runtime_complete", True) and right.get("runtime_complete", True):
                pair["runtime_difference_seconds"] = (
                    right["runtime_seconds"] - left["runtime_seconds"]
                )
        pairs.append(pair)
    included_pairs = [pair for pair in pairs if pair["included"]]
    return {
        "reference_agent_id": reference_id,
        "agent_id": agent_id,
        "pairs_planned": len(keys),
        "pairs_used": len(included_pairs),
        "profit_pairs": sum(
            pair["profit_difference_cents"] is not None for pair in included_pairs
        ),
        "mean_profit_difference_cents": _mean_known(
            pair["profit_difference_cents"] for pair in included_pairs
        ),
        "mean_retained_conversion_rate_difference": _mean_known(
            pair["retained_conversion_rate_difference"] for pair in included_pairs
        ),
        "mean_runtime_difference_seconds": _mean_known(
            pair["runtime_difference_seconds"] for pair in included_pairs
        ),
        "pairs": pairs,
    }


def build_report(rows: list[dict]) -> dict:
    """Summarize run records without ranking agents or hiding unsuccessful runs."""
    rows = _prepare_rows(rows)
    groups = {}
    for row in rows:
        groups.setdefault(row["agent_id"], []).append(row)
    agent_ids = list(groups)
    reference_id = agent_ids[0] if agent_ids else None
    return {
        "schema_version": 1,
        "methodology": METHODOLOGY,
        "reference_agent_id": reference_id,
        "runs": rows,
        "agents": [_agent_summary(name, group) for name, group in groups.items()],
        "comparisons": [
            _pair_comparison(reference_id, name, groups[reference_id], groups[name])
            for name in agent_ids[1:]
        ],
    }


def _csv_text(rows):
    base = [
        "case_id",
        "agent_id",
        "repeat",
        "status",
        "agent_stop_reason",
        "failure_category",
        "error",
        "customer_count",
        "runtime_seconds",
        "tool_calls",
        "final_day",
    ]
    nested = ("metrics", "seller_usage", "customer_usage")
    extras = sorted({name for row in rows for name in row} - set(base) - set(nested))
    fields = [*base, *METRICS]
    fields += [f"{group}_{field}" for group in nested[1:] for field in USAGE_FIELDS]
    fields += extras
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=fields, lineterminator="\n")
    writer.writeheader()
    for row in rows:
        flat = {field: row.get(field) for field in base + extras}
        flat.update({name: row["metrics"][name] for name in METRICS})
        for group in nested[1:]:
            flat.update(
                {f"{group}_{field}": row[group][field] for field in USAGE_FIELDS}
            )
        for name, value in flat.items():
            if isinstance(value, (dict, list)):
                flat[name] = json.dumps(value, ensure_ascii=False, allow_nan=False)
        writer.writerow(flat)
    return output.getvalue()


def _cell(value):
    if value is None:
        return "unknown"
    return str(value).replace("\\", "\\\\").replace("|", "\\|").replace("\n", " ")


def _money(cents):
    if cents is None:
        return "unknown"
    sign = "-" if cents < 0 else ""
    return f"{sign}${abs(cents) / 100:,.2f}"


def _rate(value):
    return "unknown" if value is None else f"{value:.1%}"


def _dollars(value, places=4):
    if value is None:
        return "unknown"
    sign = "-" if value < 0 else ""
    return f"{sign}${abs(value):,.{places}f}"


def _seconds(value):
    return "unknown" if value is None else f"{value:.2f} s"


def _table(headers, rows):
    lines = ["| " + " | ".join(headers) + " |"]
    lines.append("| " + " | ".join("---" for _ in headers) + " |")
    lines.extend("| " + " | ".join(_cell(cell) for cell in row) + " |" for row in rows)
    return "\n".join(lines)


def _markdown(report):
    lines = ["# Evaluation report", ""]
    recorded = len(report["runs"])
    expected = report.get("metadata", {}).get("expected_runs")
    if type(expected) is int and expected >= recorded:
        lines += [f"Recorded runs: {recorded} / {expected}.", ""]
        if recorded < expected:
            lines += [
                (
                    "Partial evaluation: some planned runs have no recorded result. "
                    "They are not included in aggregates or matched comparisons."
                ),
                "",
            ]
    elif expected is not None:
        lines += [f"Recorded runs: {recorded}. The expected run count is invalid.", ""]
    lines += [report["methodology"], ""]
    if not report["runs"]:
        return "\n".join([*lines, "No runs were supplied.", ""])
    lines += [
        "## Agent results",
        "",
        _table(
            [
                "Agent",
                "Completed / total",
                "Incomplete",
                "Failed",
                "Mean profit (completed)",
                "Profit observations",
                "Conversion",
                "Retained conversion",
                "Mean runtime (all)",
            ],
            [
                [
                    agent["agent_id"],
                    f"{agent['completed_runs']} / {agent['total_runs']}",
                    agent["incomplete_runs"],
                    agent["failed_runs"],
                    _money(agent["mean_profit_cents"]),
                    f"{agent['profit_runs']} / {agent['completed_runs']}",
                    _rate(agent["conversion_rate"]),
                    _rate(agent["retained_conversion_rate"]),
                    _seconds(agent["mean_runtime_seconds"]),
                ]
                for agent in report["agents"]
            ],
        ),
        "",
        "## Cost",
        "",
        "Estimated at the per-million-token prices in course.json. The seller cost is your agent's; "
        "the customer cost is the simulation's. Profit minus seller cost uses completed campaigns.",
        "",
        _table(
            ["Agent", "Mean seller API cost", "Mean profit − seller API cost", "Mean customer API cost"],
            [
                [
                    agent["agent_id"],
                    _dollars(agent.get("mean_seller_cost_usd")),
                    _dollars(agent.get("mean_profit_minus_seller_cost_usd"), places=2),
                    _dollars(agent.get("mean_customer_cost_usd")),
                ]
                for agent in report["agents"]
            ],
        ),
        "",
        "## API usage across all runs",
        "",
        "Cached input tokens are part of input tokens, not an additional token category. Observed counts are receipt lower bounds; unknown totals may include additional billed requests.",
        "",
        _table(
            [
                "Agent",
                "Caller",
                "Observed responses",
                "Input tokens",
                "Output tokens",
                "Cached input tokens",
                "Observed input",
                "Observed output",
                "Observed cached input",
                "Complete measurement",
            ],
            [
                [
                    agent["agent_id"],
                    caller,
                    usage["responses"],
                    usage["input_tokens"],
                    usage["output_tokens"],
                    usage["cached_input_tokens"],
                    usage["observed_input_tokens"],
                    usage["observed_output_tokens"],
                    usage["observed_cached_input_tokens"],
                    usage["complete"],
                ]
                for agent in report["agents"]
                for caller, usage in (
                    ("seller", agent["seller_usage"]),
                    ("customer", agent["customer_usage"]),
                )
            ],
        ),
        "",
    ]
    requests = [
        (row, caller, row.get(f"{caller}_api"))
        for row in report["runs"]
        for caller in ("seller", "customer")
        if row.get(f"{caller}_api", {}).get("available")
    ]
    if requests:
        lines += [
            "## Observed API requests",
            "",
            "Latency includes only attempts with a saved completion or error receipt. Unfinished calls include requests without a final receipt and interrupted retry backoff; they do not establish the cause of a campaign timeout.",
            "",
            _table(
                [
                    "Case / repeat",
                    "Agent",
                    "Caller",
                    "Calls",
                    "Retries",
                    "Errors",
                    "Unfinished calls",
                    "Mean attempt latency",
                    "Max attempt latency",
                ],
                [
                    [
                        f"{row['case_id']} / {row['repeat']}",
                        row["agent_id"],
                        caller,
                        api["logical_calls"],
                        api["retried_calls"],
                        api["attempts_errored"],
                        api.get("unfinished_calls", api["pending_attempts"]),
                        _seconds(api["request_latency_seconds"]["mean"]),
                        _seconds(api["request_latency_seconds"]["max"]),
                    ]
                    for row, caller, api in requests
                ],
            ),
            "",
        ]
    if report["comparisons"]:
        lines += [
            "## Matched pairs",
            "",
            _table(
                [
                    "Agent",
                    "Reference",
                    "Completed pairs / planned",
                    "Profit pairs",
                    "Mean profit difference",
                ],
                [
                    [
                        pair["agent_id"],
                        pair["reference_agent_id"],
                        f"{pair['pairs_used']} / {pair['pairs_planned']}",
                        pair["profit_pairs"],
                        _money(pair["mean_profit_difference_cents"]),
                    ]
                    for pair in report["comparisons"]
                ],
            ),
            "",
        ]
    lines += [
        "## Individual runs",
        "",
        "Booked revenue and contact costs can be partial for unfinished campaigns. See runs.csv for every metric and stop reason.",
        "",
        _table(
            [
                "Case",
                "Repeat",
                "Agent",
                "Status",
                "Category",
                "Stop reason",
                "Day",
                "Final profit",
                "Runtime",
                "Error",
            ],
            [
                [
                    row["case_id"],
                    row["repeat"],
                    row["agent_id"],
                    row["status"],
                    row["failure_category"] or "",
                    row["agent_stop_reason"],
                    row["final_day"],
                    _money(row["metrics"]["profit_cents"]),
                    f"{row['runtime_seconds']:.2f} s" if row.get("runtime_complete", True) else "unknown",
                    row["error"] or row.get("report_error") or "",
                ]
                for row in report["runs"]
            ],
        ),
        "",
    ]
    return "\n".join(lines)


def _atomic_write(path, content):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", newline="", dir=path.parent, delete=False
        ) as output:
            temporary = Path(output.name)
            output.write(content)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def write_report(
    directory: Path, rows: list[dict], metadata: dict | None = None
) -> dict:
    """Write JSON, CSV, and Markdown with atomic replacement of each file.

    All content is serialized before writing. report.json is replaced last and
    is the authoritative report; CSV and Markdown are regenerable views.
    """
    report = build_report(rows)
    report["metadata"] = deepcopy(metadata) if metadata is not None else {}
    json_text = json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    csv_text = _csv_text(report["runs"])
    markdown_text = _markdown(report)
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    _atomic_write(directory / "runs.csv", csv_text)
    _atomic_write(directory / "report.md", markdown_text)
    _atomic_write(directory / "report.json", json_text)
    return report


# Stop reasons that make a trial count as failed, whatever the campaign reached.
FAILED_STOPS = {
    "api_error", "tool_error", "invalid_response", "refused", "incomplete",
    "exception", "timeout", "runner_error", "worker_failed", "startup_timeout",
    "startup_error", "interrupted", "execution_limit", "billing_uncertain",
}


def summarize_usage(records: list[dict] | None, *, complete: bool = True) -> dict:
    """Keep observed receipt lower bounds separate from complete token totals.

    ``responses`` counts recorded receipts, not unobserved or in-flight requests.
    An interrupted request can be billed without leaving a response receipt.
    """
    fields = ("input_tokens", "output_tokens", "cached_input_tokens")
    if records is None:
        return {
            "responses": 0,
            **dict.fromkeys(fields),
            **dict.fromkeys(f"observed_{field}" for field in fields),
            "complete": False,
        }
    result = {"responses": len(records), "complete": complete}
    for field in fields:
        values = [record.get(field) for record in records]
        known = complete and all(type(value) is int and value >= 0 for value in values)
        result[field] = sum(values) if known else None
        result[f"observed_{field}"] = sum(
            value for value in values if type(value) is int and value >= 0
        )
        result["complete"] = result["complete"] and known
    return result


def _summarize_receipt_evidence(records, separate_source, *, complete):
    """Unknown overlap permits maxima as lower bounds, never additive totals."""
    result = summarize_usage(records, complete=complete and separate_source is None)
    result["receipt_overlap_unknown"] = separate_source is not None
    if separate_source is not None:
        other = summarize_usage(separate_source, complete=False)
        for field in (
            "responses",
            "observed_input_tokens",
            "observed_output_tokens",
            "observed_cached_input_tokens",
        ):
            known = [
                value for value in (result[field], other[field]) if value is not None
            ]
            result[field] = max(known) if known else None
    return result


def _metrics(report: dict | None) -> dict:
    names = (
        "accepted_orders",
        "retained_orders",
        "conversion_rate",
        "retained_conversion_rate",
        "refund_count",
        "booked_revenue_cents",
        "refunded_revenue_cents",
        "retained_revenue_cents",
        "service_cost_cents",
        "contact_cost_cents",
        "profit_cents",
        "missed_callbacks",
    )
    result = dict.fromkeys(names)
    if report is None:
        return result
    status = report["environment"]
    result.update(
        accepted_orders=status["orders"],
        booked_revenue_cents=status["booked_revenue_cents"],
        contact_cost_cents=status["contact_cost_cents"],
    )
    if status["finished"]:
        result.update(status["outcome"])
        result["refund_count"] = result["accepted_orders"] - result["retained_orders"]
        count = report["customers_count"]
        result["conversion_rate"] = result["accepted_orders"] / count if count else None
        result["retained_conversion_rate"] = (
            result["retained_orders"] / count if count else None
        )
    return result


def api_cost_usd(usage, model, prices):
    """Dollar estimate for complete token totals at published per-million prices.

    None when the totals are unknown or the model has no listed price. A price
    listed for "gpt-5.4-mini" also covers dated snapshots such as
    "gpt-5.4-mini-2026-03-17". Long-context surcharges are not modeled.
    """
    fields = ("input_tokens", "cached_input_tokens", "output_tokens")
    if not usage or any(type(usage.get(name)) is not int for name in fields):
        return None
    if not any(usage[name] for name in fields):
        return 0.0                       # no calls, or none counted: nothing to pay, whatever the model
    names = [name for name, value in (prices or {}).items() if isinstance(value, dict)
             and (model == name or str(model).startswith(name + "-"))]
    if not names:
        return None
    price = prices[max(names, key=lambda name: (name == model, len(name)))]   # exact, else longest prefix
    fresh = usage["input_tokens"] - usage["cached_input_tokens"]
    return round((fresh * price["input"] + usage["cached_input_tokens"] * price["cached_input"]
                  + usage["output_tokens"] * price["output"]) / 1_000_000, 4)

