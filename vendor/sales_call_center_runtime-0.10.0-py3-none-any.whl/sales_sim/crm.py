"""Load public company records from a small, inspectable JSON dataset.

CRM records contain facts the company has collected. Private customer simulator
preferences belong elsewhere. The loader never writes to the supplied dataset.
"""

import json
import re
from copy import deepcopy
from dataclasses import asdict, dataclass
from datetime import date
from pathlib import Path
from typing import Any

from .models import CampaignConfig, Customer, Document, PricingPolicy, Product, Scenario

RECORD_KINDS = {
    "profile",
    "sale",
    "refund",
    "cancellation",
    "interaction",
    "note",
    "quote",
    "callback",
}


@dataclass(frozen=True)
class CRMRecord:
    """A dated record with explicit provenance and a kind-specific payload."""

    id: str
    customer_id: str
    kind: str
    date: str
    source: str
    source_ids: tuple[str, ...]
    data: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["source_ids"] = list(self.source_ids)
        return result

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "CRMRecord":
        value = _fields(
            value,
            required={
                "id",
                "customer_id",
                "kind",
                "date",
                "source",
                "source_ids",
                "data",
            },
            label="CRM record",
        )
        record = cls(
            id=_identifier(value["id"], "record id"),
            customer_id=_customer_id(value["customer_id"]),
            kind=_string(value["kind"], "record kind"),
            date=_iso_date(value["date"], "record date"),
            source=_string(value["source"], "record source"),
            source_ids=_strings(value["source_ids"], "source_ids"),
            data=deepcopy(_object(value["data"], "record data")),
        )
        if record.kind not in RECORD_KINDS:
            raise ValueError(f"Unknown record kind: {record.kind}")
        _validate_payload(record)
        _json_value(record.data)
        return record


class CRMStore:
    """An immutable initial snapshot. Accessors return independent copies.

    Both records_for() and all_records() include profiles. Records are returned
    in chronological order, with IDs breaking ties on the same date.
    """

    def __init__(
        self,
        profiles: tuple[CRMRecord, ...] = (),
        records: tuple[CRMRecord, ...] = (),
    ) -> None:
        self._profiles: dict[str, CRMRecord] = {}
        self._records: dict[str, CRMRecord] = {}
        for record in records:
            if record.kind == "profile":
                raise ValueError("Profile records belong in profiles")
        for profile in profiles:
            checked = CRMRecord.from_dict(profile.to_dict())
            if checked.kind != "profile":
                raise ValueError("profiles must contain only profile records")
            if checked.customer_id in self._profiles:
                raise ValueError(f"Duplicate customer profile: {checked.customer_id}")
            self._profiles[checked.customer_id] = checked
        for record in (*profiles, *records):
            checked = CRMRecord.from_dict(record.to_dict())
            if record.id in self._records:
                raise ValueError(f"Duplicate record id: {record.id}")
            self._records[record.id] = checked

    def profile(self, customer_id: str) -> CRMRecord | None:
        return deepcopy(self._profiles.get(customer_id))

    def get(self, record_id: str) -> CRMRecord | None:
        return deepcopy(self._records.get(record_id))

    def records_for(self, customer_id: str) -> tuple[CRMRecord, ...]:
        return tuple(
            record for record in self.all_records() if record.customer_id == customer_id
        )

    def all_records(self) -> tuple[CRMRecord, ...]:
        records = sorted(
            self._records.values(), key=lambda record: (record.date, record.id)
        )
        return deepcopy(tuple(records))

    def to_dict(self) -> dict[str, Any]:
        return {
            "profiles": [
                record.to_dict()
                for record in self.all_records()
                if record.kind == "profile"
            ],
            "records": [
                record.to_dict()
                for record in self.all_records()
                if record.kind != "profile"
            ],
        }

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "CRMStore":
        value = _fields(value, required={"profiles", "records"}, label="CRM store")
        return cls(
            profiles=tuple(
                CRMRecord.from_dict(item)
                for item in _array(value["profiles"], "profiles")
            ),
            records=tuple(
                CRMRecord.from_dict(item)
                for item in _array(value["records"], "records")
            ),
        )


@dataclass(frozen=True)
class Dataset:
    """The public scenario and CRM snapshot saved with each run."""

    scenario: Scenario
    crm: CRMStore

    def to_dict(self) -> dict[str, Any]:
        return {"scenario": asdict(self.scenario), "crm": self.crm.to_dict()}

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "Dataset":
        value = _fields(value, required={"scenario", "crm"}, label="dataset")
        dataset = cls(
            _scenario_from_dict(value["scenario"]), CRMStore.from_dict(value["crm"])
        )
        _validate_dataset(dataset)
        return dataset


def load_dataset(path: str | Path) -> Dataset:
    """Read a dataset directory and reject invalid or inconsistent records."""
    root = Path(path)
    if root.is_symlink() or not root.is_dir():
        raise ValueError("Dataset must be a directory, not a symbolic link")
    root = root.resolve()
    manifest = _fields(
        _read_json(root / "manifest.json", root),
        required={"schema_version", "start_date", "config"},
        label="manifest",
    )
    if type(manifest["schema_version"]) is not int or manifest["schema_version"] != 1:
        raise ValueError("Only dataset schema_version 1 is supported")

    profiles: list[CRMRecord] = []
    records: list[CRMRecord] = []
    customer_root = _directory(root / "customers", root)
    for folder in sorted(customer_root.iterdir()):
        if folder.name.startswith("."):
            continue
        _directory(folder, root)
        profile = CRMRecord.from_dict(_read_json(folder / "profile.json", root))
        if profile.kind != "profile":
            raise ValueError(f"{folder.name}/profile.json must contain a profile")
        prefix = profile.customer_id + "_"
        if not folder.name.startswith(prefix) or not re.fullmatch(
            r"[a-z0-9]+(?:_[a-z0-9]+)*", folder.name[len(prefix) :]
        ):
            raise ValueError(f"Customer folder must be named {prefix}<company_slug>")
        profiles.append(profile)
        sales = _array(_read_json(folder / "sales.json", root), "sales")
        customer_records = [CRMRecord.from_dict(item) for item in sales]
        if any(
            record.kind not in {"sale", "refund", "cancellation"}
            for record in customer_records
        ):
            raise ValueError(
                "sales.json accepts sale, refund, and cancellation records only"
            )
        interaction_folder = _directory(folder / "interactions", root)
        for file in sorted(interaction_folder.glob("*.json")):
            record = CRMRecord.from_dict(_read_json(file, root))
            if record.kind != "interaction":
                raise ValueError("Interaction files must contain interaction records")
            customer_records.append(record)
        if any(
            record.customer_id != profile.customer_id for record in customer_records
        ):
            raise ValueError(f"Records in {folder.name} belong to a different customer")
        records.extend(customer_records)

    policy_folder = _directory(root / "policies", root)
    scenario_data = {
        "customers": [
            {
                "id": profile.customer_id,
                **{
                    key: profile.data[key] for key in ("name", "business", "background")
                },
            }
            for profile in profiles
        ],
        "products": _read_json(root / "products.json", root),
        "pricing_policies": [
            _read_json(file, root) for file in sorted(policy_folder.glob("*.json"))
        ],
        "documents": _read_json(root / "documents.json", root),
        "config": manifest["config"],
        "start_date": manifest["start_date"],
    }
    dataset = Dataset(
        _scenario_from_dict(scenario_data), CRMStore(tuple(profiles), tuple(records))
    )
    _validate_dataset(dataset)
    return dataset


def _scenario_from_dict(value: dict[str, Any]) -> Scenario:
    value = _fields(
        value,
        required={
            "customers",
            "products",
            "pricing_policies",
            "documents",
            "config",
            "start_date",
        },
        label="scenario",
    )
    customers = []
    for item in _array(value["customers"], "customers"):
        item = _fields(
            item, required={"id", "name", "business", "background"}, label="customer"
        )
        customers.append(
            Customer(
                _customer_id(item["id"]),
                _string(item["name"], "customer name"),
                _string(item["business"], "business"),
                _string(item["background"], "background", allow_empty=True),
            )
        )
    products = []
    for item in _array(value["products"], "products"):
        item = _fields(
            item,
            required={
                "id",
                "name",
                "monthly_price_cents",
                "monthly_service_cost_cents",
                "features",
                "integrations",
            },
            label="product",
        )
        products.append(
            Product(
                _identifier(item["id"], "product id"),
                _string(item["name"], "product name"),
                _integer(item["monthly_price_cents"], "monthly_price_cents", minimum=1),
                _integer(
                    item["monthly_service_cost_cents"], "monthly_service_cost_cents"
                ),
                _strings(item["features"], "features"),
                _strings(item["integrations"], "integrations"),
            )
        )
    policies = []
    for item in _array(value["pricing_policies"], "pricing_policies"):
        item = _fields(
            item,
            required={
                "id",
                "effective_day",
                "max_discount_percent",
                "quote_valid_days",
            },
            label="pricing policy",
        )
        policies.append(
            PricingPolicy(
                _identifier(item["id"], "policy id"),
                _integer(item["effective_day"], "effective_day", minimum=1),
                _integer(item["max_discount_percent"], "max_discount_percent"),
                _integer(item["quote_valid_days"], "quote_valid_days"),
            )
        )
    documents = []
    for item in _array(value["documents"], "documents"):
        item = _fields(
            item, required={"id", "title", "text", "available_day"}, label="document"
        )
        documents.append(
            Document(
                _identifier(item["id"], "document id"),
                _string(item["title"], "document title"),
                _string(item["text"], "document text"),
                _integer(item["available_day"], "available_day", minimum=1),
            )
        )
    config = _fields(
        value["config"],
        required={
            "days",
            "contact_minutes_per_day",
            "minutes_per_exchange",
            "cost_per_exchange_cents",
        },
        label="config",
    )
    return Scenario(
        customers=tuple(customers),
        products=tuple(products),
        pricing_policies=tuple(policies),
        documents=tuple(documents),
        config=CampaignConfig(
            **{
                key: _integer(
                    number, key, minimum=0 if key == "cost_per_exchange_cents" else 1
                )
                for key, number in config.items()
            }
        ),
        start_date=_iso_date(value["start_date"], "start_date"),
    )


def _validate_dataset(dataset: Dataset) -> None:
    scenario, crm = dataset.scenario, dataset.crm
    if scenario.config.minutes_per_exchange > scenario.config.contact_minutes_per_day:
        raise ValueError("A business day must allow at least one customer exchange")
    customers = _unique(scenario.customers, "customer")
    products = _unique(scenario.products, "product")
    policies = _unique(scenario.pricing_policies, "pricing policy")
    documents = _unique(scenario.documents, "document", allow_empty=True)
    effective_days = [policy.effective_day for policy in policies.values()]
    if 1 not in effective_days or len(set(effective_days)) != len(effective_days):
        raise ValueError(
            "Pricing policies must start on day 1 and have unique effective days"
        )
    if any(policy.max_discount_percent > 100 for policy in policies.values()):
        raise ValueError("max_discount_percent must be between 0 and 100")
    if any(
        product.monthly_service_cost_cents > product.monthly_price_cents
        for product in products.values()
    ):
        raise ValueError("Product service cost cannot exceed its list price")

    record_ids = {record.id for record in crm.all_records()}
    document_ids = (
        set(documents)
        | {f"product:{key}" for key in products}
        | {f"policy:{key}" for key in policies}
    )
    future_document_ids = {
        document.id for document in documents.values() if document.available_day > 1
    } | {
        f"policy:{policy.id}"
        for policy in policies.values()
        if policy.effective_day > 1
    }
    if len(document_ids) != len(documents) + len(products) + len(policies):
        raise ValueError(
            "Document IDs conflict with generated product or policy documents"
        )
    if record_ids & document_ids:
        raise ValueError("CRM record IDs conflict with document IDs")
    if any(document_id.startswith(("run:", "crm:")) for document_id in document_ids):
        raise ValueError("Document IDs cannot use the reserved run: or crm: prefix")
    for customer_id, customer in customers.items():
        profile = crm.profile(customer_id)
        if profile is None:
            raise ValueError(f"Missing profile for customer: {customer_id}")
        for key in ("name", "business", "background"):
            if profile.data[key] != getattr(customer, key):
                raise ValueError(
                    f"Profile and customer directory disagree: {customer_id}.{key}"
                )
    for record in crm.all_records():
        if record.id.startswith(("run:", "crm:")):
            raise ValueError(
                "Initial record IDs cannot use the reserved run: or crm: prefix"
            )
        if record.customer_id not in customers:
            raise ValueError(f"Unknown customer in record: {record.id}")
        if record.date >= scenario.start_date:
            raise ValueError(f"Initial record must predate the campaign: {record.id}")
        for source_id in record.source_ids:
            if source_id not in record_ids | document_ids:
                raise ValueError(f"Unknown source reference {source_id} in {record.id}")
            if source_id in future_document_ids:
                raise ValueError(
                    f"Historical record cites a future document: {record.id}"
                )
            source = crm.get(source_id)
            if source is not None and source.customer_id != record.customer_id:
                raise ValueError(f"Source reference crosses customers: {record.id}")
            if source is not None and source.date > record.date:
                raise ValueError(
                    f"Source reference is newer than its record: {record.id}"
                )
        if (
            record.kind in {"sale", "refund", "cancellation"}
            and record.data["product_id"] not in products
        ):
            raise ValueError(f"Unknown product in record: {record.id}")
        if record.kind in {"refund", "cancellation"}:
            sale = crm.get(record.data["sale_id"])
            if (
                sale is None
                or sale.kind != "sale"
                or sale.customer_id != record.customer_id
            ):
                raise ValueError(f"Invalid sale reference in record: {record.id}")
            if (
                sale.date > record.date
                or sale.data["product_id"] != record.data["product_id"]
            ):
                raise ValueError(
                    f"Sale reference disagrees with transaction: {record.id}"
                )
        if record.kind == "profile":
            for subscription in record.data.get("current_subscriptions", []):
                subscription = _object(subscription, "subscription")
                if subscription.get("product_id") not in products:
                    raise ValueError(
                        f"Unknown subscription product in profile: {record.id}"
                    )


def _validate_payload(record: CRMRecord) -> None:
    data = record.data
    if record.kind == "profile":
        for key in ("name", "business", "background"):
            _string(data.get(key), f"profile.{key}", allow_empty=key == "background")
        if "business_info" in data:
            _object(data["business_info"], "profile.business_info")
        if "contacts" in data:
            for contact in _array(data["contacts"], "profile.contacts"):
                _object(contact, "profile contact")
        if "current_subscriptions" in data:
            _array(data["current_subscriptions"], "profile.current_subscriptions")
    elif record.kind in {"sale", "refund", "cancellation"}:
        _identifier(data.get("product_id"), "transaction.product_id")
        if record.kind == "sale":
            _integer(data.get("monthly_price_cents"), "sale.monthly_price_cents")
        else:
            _identifier(data.get("sale_id"), "transaction.sale_id")
        if record.kind == "refund":
            _integer(data.get("amount_cents"), "refund.amount_cents")
    elif record.kind == "interaction":
        _string(data.get("channel"), "interaction.channel")
        messages = _array(data.get("messages"), "interaction.messages")
        if not messages:
            raise ValueError("Interaction messages cannot be empty")
        for message in messages:
            message = _fields(
                message, required={"role", "text"}, label="interaction message"
            )
            if _string(message["role"], "message role") not in {
                "salesperson",
                "customer",
            }:
                raise ValueError("Interaction role must be salesperson or customer")
            _string(message["text"], "interaction message text")


def _read_json(path: Path, root: Path) -> Any:
    _check_path(path, root)
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(
            f"Cannot read JSON file {path.relative_to(root)}: {exc}"
        ) from exc


def _directory(path: Path, root: Path) -> Path:
    _check_path(path, root)
    if not path.is_dir():
        raise ValueError(f"Expected directory: {path.relative_to(root)}")
    return path


def _check_path(path: Path, root: Path) -> None:
    if path.is_symlink() or not path.resolve().is_relative_to(root):
        raise ValueError("Dataset paths cannot be symbolic links or escape the dataset")


def _object(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, dict) or any(not isinstance(key, str) for key in value):
        raise ValueError(f"{label} must be an object with string keys")
    return value


def _fields(value: Any, *, required: set[str], label: str) -> dict[str, Any]:
    value = _object(value, label)
    if set(value) != required:
        raise ValueError(
            f"{label} fields must be exactly: {', '.join(sorted(required))}"
        )
    return value


def _array(value: Any, label: str) -> list[Any] | tuple[Any, ...]:
    if not isinstance(value, (list, tuple)):
        raise ValueError(f"{label} must be an array")  # noqa: TRY004 -- malformed dataset value
    return value


def _string(value: Any, label: str, *, allow_empty: bool = False) -> str:
    if not isinstance(value, str) or (not allow_empty and not value.strip()):
        raise ValueError(
            f"{label} must be a {'nonempty ' if not allow_empty else ''}string"
        )
    return value


def _identifier(value: Any, label: str) -> str:
    value = _string(value, label)
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]*", value):
        raise ValueError(f"{label} has invalid characters")
    return value


def _customer_id(value: Any) -> str:
    value = _string(value, "customer id")
    if not re.fullmatch(r"[a-z0-9][a-z0-9_-]*", value):
        raise ValueError(
            "Customer IDs must use lowercase letters, numbers, underscores, or hyphens"
        )
    return value


def _strings(value: Any, label: str) -> tuple[str, ...]:
    return tuple(_string(item, label) for item in _array(value, label))


def _integer(value: Any, label: str, *, minimum: int = 0) -> int:
    if type(value) is not int or value < minimum:
        raise ValueError(f"{label} must be an integer >= {minimum}")
    return value


def _iso_date(value: Any, label: str) -> str:
    value = _string(value, label)
    try:
        parsed = date.fromisoformat(value)
    except ValueError as exc:
        raise ValueError(f"{label} must be a valid YYYY-MM-DD date") from exc
    if parsed.isoformat() != value:
        raise ValueError(f"{label} must be a valid YYYY-MM-DD date")
    return value


def _unique(
    items: tuple[Any, ...], label: str, *, allow_empty: bool = False
) -> dict[str, Any]:
    result = {item.id: item for item in items}
    if len(result) != len(items) or (not result and not allow_empty):
        raise ValueError(
            f"{label} IDs must be unique and the collection cannot be empty"
        )
    return result


def _json_value(value: Any) -> None:
    try:
        json.dumps(value, allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise ValueError("Record data must contain JSON-compatible values") from exc
