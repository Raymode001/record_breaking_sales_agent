"""Offline setup checks and the course settings shared by the CLI and the notebook."""

import importlib.metadata
import json
import os
import re
import sys
from pathlib import Path

import sales_sim

from . import agent as agent_module
from .api_client import api_credentials
from .crm import load_dataset
from .environment import SalesEnvironment
from .harness import REASONING_EFFORTS, Toolbox, World, instructions
from .student_submission import load_submission
from .suites import FORMAL_SUITE, load_suite
from .tools import LocalToolClient

LIMIT_DEFAULTS = {"max_steps": 2000, "max_api_calls": 3000,
                  "max_output_tokens": 32768, "max_token_units": 50_000_000}


def course_settings(root):
    """Read course.json: the models, the per-trial limits and the published prices."""
    path = Path(root) / "course.json"
    if not path.is_file():
        raise ValueError("Missing course.json. Restore the supplied course settings.")
    settings = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(settings, dict):
        raise ValueError("course.json must be a JSON object.")
    limits = {**LIMIT_DEFAULTS, **settings.get("limits", {})}
    for name, value in limits.items():
        if name not in LIMIT_DEFAULTS or type(value) is not int or value < 1:
            raise ValueError(f"course.json limits: {name} must be a positive integer.")
    if settings.get("service_tier") not in (None, "auto", "default", "flex", "priority"):
        raise ValueError("course.json service_tier must be auto, default, flex or priority.")
    effort = settings.get("reasoning_effort")
    if effort is not None and effort not in REASONING_EFFORTS:
        raise ValueError(f"course.json reasoning_effort must be one of {', '.join(REASONING_EFFORTS)}.")
    return {**settings, "limits": limits}


def model_settings(root, *, model=None, customer_model=None):
    """The seller and customer models from course.json, unless a caller overrides one."""
    settings = course_settings(root)
    selected = {"model": model, "customer_model": customer_model}
    for name in selected:
        selected[name] = selected[name] if selected[name] is not None else settings.get(name)
        if not isinstance(selected[name], str) or not selected[name].strip():
            raise ValueError(f"Choose a nonempty {name} in course.json.")
    return selected


def tool_definitions(root, variant="tools"):
    """The exact tool schemas the model receives in this variant, read from saved files."""
    _, functions = load_submission(root, variant)._configuration()
    return Toolbox(functions).schemas()


class _NoCustomers:
    """Previews read the campaign; they never contact a customer."""

    def respond(self, turn, **_):
        raise RuntimeError("A preview makes no customer calls.")

    def settle(self, order):
        raise RuntimeError("A preview makes no customer calls.")


def preview_world(suite, case=None):
    """A World for one case of a suite, built offline: no customer model, no API key."""
    selected = load_suite(suite, case_ids=[case] if case else None)[0]
    dataset = load_dataset(selected.dataset_path)
    return World(LocalToolClient(SalesEnvironment(dataset.scenario, _NoCustomers(), dataset.crm))), selected.id


def model_input(root, *, variant="tools", suite=None, case=None):
    """Exactly what the model reads before its first turn, built offline.

    case picks a practice case; otherwise suite (default: the formal campaign).
    Returns the developer message (SYSTEM_PROMPT, exactly as written), the
    first user message, and the tool definitions of this variant.
    """
    root = Path(root).resolve()
    suite = Path(suite) if suite else root / ("practice/suite.json" if case else FORMAL_SUITE)
    world, case_id = preview_world(suite, case)
    prompt, functions = load_submission(root, variant)._configuration()
    return {"case_id": case_id, "variant": variant, "developer": instructions(world, prompt),
            "user": world.morning_note(), "tools": Toolbox(functions).schemas()}


def _dependency_versions(root, errors, warnings):
    path = root / "requirements.lock"
    if not path.exists():
        messages = errors if (root / "requirements.txt").exists() else warnings
        messages.append("No requirements.lock found; restore the supplied file to check dependency versions.")
        return {}
    try:
        from packaging.requirements import Requirement
    except ImportError:
        errors.append("Missing packaging. Install the starter requirements with this Python interpreter.")
        return {}
    versions = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.split("#", 1)[0].strip()
        if not line:
            continue
        requirement = Requirement(line)
        if requirement.marker is not None and not requirement.marker.evaluate():
            continue
        try:
            installed = importlib.metadata.version(requirement.name)
        except importlib.metadata.PackageNotFoundError:
            installed = None
        versions[requirement.name] = installed
        if installed is None or installed not in requirement.specifier:
            errors.append(f"Dependency {requirement}: installed {installed or 'not installed'}.")
    return versions


def check_setup(root, *, display=True, model=None, customer_model=None):
    """Check the installed starter and the student files without any API call.

    A missing API key is fine here. This checks loading and schemas, not sales
    quality or the behavior of code inside student tools.
    """
    root = Path(root).resolve()
    errors, warnings = [], []
    report = {
        "ok": False, "root": str(root), "python": sys.executable,
        "python_version": sys.version.split()[0], "errors": errors, "warnings": warnings,
        "runtime": {"path": str(Path(sales_sim.__file__).resolve()), "version": None},
        "models": {}, "tools": [], "dependencies": {},
        "api_key_configured": bool(api_credentials(colab=False)["api_key"]),
        "api": api_credentials(colab=False)["provider"],
    }
    if sys.version_info < (3, 11):
        errors.append("The supplied course environment requires Python 3.11 or newer.")
    try:
        installed = importlib.metadata.version("sales-call-center-runtime")
    except importlib.metadata.PackageNotFoundError:
        installed = None
    # Old kernels can retain an earlier module after pip updates the installed
    # metadata. Only the version embedded in loaded code identifies that code.
    loaded = getattr(sales_sim, "__version__", None)
    report["runtime"].update(version=loaded, installed_version=installed)
    requirements = root / "requirements.txt"
    if requirements.exists():
        wheel = re.search(r"(?:\./)?vendor/sales_call_center_runtime-([^/\s]+)-py3-none-any\.whl",
                          requirements.read_text(encoding="utf-8"))
        if wheel:
            expected = wheel.group(1)
            report["runtime"]["expected_version"] = expected
            if loaded != expected or installed != expected:
                errors.append(f"Expected runtime {expected}; loaded {loaded or 'unknown'}, installed {installed or 'unknown'}. "
                              "Install requirements.txt with this Python interpreter, then restart the notebook kernel.")
            if not (root / wheel.group(0)).is_file():
                errors.append("The runtime wheel named in requirements.txt is missing from vendor/.")
    if loaded and installed and loaded != installed:
        errors.append("The loaded runtime differs from the installed runtime. Restart the notebook kernel.")

    # Never display credential values, even when a student import error contains one.
    def error_message(error):
        message = f"{type(error).__name__}: {error}"
        for name in ("PARLEY_API_KEY", "OPENAI_API_KEY"):
            key = os.environ.get(name, "").strip()
            message = message.replace(key, "[API key hidden]") if key else message
        return message

    loop = root / "agent.py"
    if not loop.is_file():
        errors.append("agent.py is missing. Restore the supplied copy of the loop.")
    elif loop.read_text(encoding="utf-8") != Path(agent_module.__file__).read_text(encoding="utf-8"):
        errors.append("agent.py differs from the loop the runner uses. Restore the supplied copy; "
                      "edit prompt.py and tools.py instead.")
    try:
        report["models"] = model_settings(root, model=model, customer_model=customer_model)
        report["dependencies"] = _dependency_versions(root, errors, warnings)
    except Exception as error:
        errors.append(error_message(error))
    try:
        report["tools"] = [schema["name"] for schema in tool_definitions(root, "tools")]
    except Exception as error:
        errors.append(error_message(error))
    report["ok"] = not errors
    if display:
        print(f"Python: {report['python']} ({report['python_version']})")
        print(f"Runtime: {loaded or 'unknown'} — {report['runtime']['path']}")
        if report["models"]:
            print(f"Course models: seller {report['models']['model']}; customer {report['models']['customer_model']}")
        if report["tools"]:
            print(f"Your toolbox: {len(report['tools'])} tools ({', '.join(report['tools'])})")
        print("API key: " + (("MIT Parley (PARLEY_API_KEY)" if report["api"] == "parley" else "OpenAI (OPENAI_API_KEY)")
                             if report["api_key_configured"] else
                             "not set: export PARLEY_API_KEY=... before a paid run (fine for offline checks)"))
        for message in warnings:
            print(f"Note: {message}")
        for message in errors:
            print(f"ERROR: {message}")
        print("Setup checks passed. No API calls were made." if report["ok"] else "Fix the setup errors above before continuing.")
    return report
