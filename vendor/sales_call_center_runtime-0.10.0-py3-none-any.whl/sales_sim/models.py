"""Small data records shared by the environment and customer simulators.

Money is always an integer number of US cents. Days start at 1.
"""

from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class Product:
    id: str
    name: str
    monthly_price_cents: int
    monthly_service_cost_cents: int
    features: tuple[str, ...]
    integrations: tuple[str, ...]


@dataclass(frozen=True)
class PricingPolicy:
    id: str
    effective_day: int
    max_discount_percent: int = 15
    quote_valid_days: int = 2


@dataclass(frozen=True)
class Document:
    id: str
    title: str
    text: str
    available_day: int = 1


@dataclass(frozen=True)
class Customer:
    """The public contact directory, never a customer's hidden preferences."""

    id: str
    name: str
    business: str
    background: str


@dataclass(frozen=True)
class Message:
    id: str
    day: int
    customer_id: str
    role: Literal["salesperson", "customer"]
    text: str
    quote_id: str | None = None
    decision: str | None = None


@dataclass(frozen=True)
class Quote:
    id: str
    customer_id: str
    product_id: str
    monthly_price_cents: int
    monthly_service_cost_cents: int
    created_day: int
    expires_day: int
    pricing_policy_id: str
    issued_day: int | None = None


@dataclass(frozen=True)
class Order:
    id: str
    quote: Quote
    accepted_day: int


@dataclass(frozen=True)
class CustomerTurn:
    """A simulator receives only this customer's public conversation.

    The current salesperson message is separate from the previous history.
    An offer is supplied only when the environment presents a valid quote.
    Earlier presented quotes retain their terms; unpresented drafts are omitted.
    """

    customer: Customer
    day: int
    history: tuple[Message, ...]
    salesperson_message: str
    offer: Quote | None = None
    product: Product | None = None
    presented_quotes: tuple[Quote, ...] = ()
    prior_records: tuple[dict, ...] = ()


@dataclass(frozen=True)
class CustomerReply:
    text: str
    decision: Literal["continue", "accept", "decline", "end_call", "opt_out"] = (
        "continue"
    )


@dataclass(frozen=True)
class Settlement:
    """The independent customer's outcome after the 30-day trial period."""

    retained: bool
    reason: str


@dataclass(frozen=True)
class CampaignConfig:
    days: int = 5
    contact_minutes_per_day: int = 120
    minutes_per_exchange: int = 5
    cost_per_exchange_cents: int = 50


@dataclass(frozen=True)
class Scenario:
    customers: tuple[Customer, ...]
    products: tuple[Product, ...]
    pricing_policies: tuple[PricingPolicy, ...]
    documents: tuple[Document, ...] = ()
    config: CampaignConfig = CampaignConfig()
    start_date: str = "2026-10-01"
