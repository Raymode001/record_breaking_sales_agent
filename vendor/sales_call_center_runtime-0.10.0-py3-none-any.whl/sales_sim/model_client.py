"""The supplied seller client: one selected model and receipts for every call.

This adapter is a development interface, not a sandbox. Official grading must
place the provider credentials and authoritative meter outside student code.
"""

from .api_client import create_client, ensure_instrumented


class SuppliedModelClient:
    """Expose Responses.create without making students manage API credentials."""

    _sales_receipts = True

    def __init__(self, model: str, *, client=None):
        if not isinstance(model, str) or not model.strip():
            raise ValueError("Choose a seller model before running the submission.")
        self.model = model
        self._client = ensure_instrumented(client, role="seller") if client is not None else create_client("seller")
        self.responses = _Responses(self, self._client)

    @property
    def usage(self):
        return self._client.usage


class _Responses:
    def __init__(self, owner, client):
        self.owner = owner
        self.client = client

    def create(self, **kwargs):
        if kwargs.get("model") != self.owner.model:
            raise ValueError("Use the model supplied to build_agent for every call.")
        return self.client.responses.create(**kwargs)
