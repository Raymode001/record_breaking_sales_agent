"""Replay recorded API responses, keep a spending ledger, and stop at a personal cap.

Development only: the local runner, the notebook and ``run.py check`` activate a
cache. The staff evaluator never does, so graded runs always call the model.

A response is stored under a key made from the caller's role (seller, customer,
judge), a salt, and the exact request: model, settings, tools and the whole
input. The same request with the same salt returns the stored response without
a paid call. The local runner salts each trial with its variant, case and repeat
number, so the repeats of an experiment stay independent samples, while running
an unchanged trial again (for example after an interruption) replays every
request it had already paid for and continues live from the first new one.

A replayed response is accounted exactly like the original. It passes the same
execution guards and its receipt carries the original token counts, so a trial's
usage, limits and cost estimate never depend on the cache. Only actual spending
does: the ledger records a replay at no cost.

The ledger (``ledger.jsonl`` in the cache directory) records every request with
its estimated cost at the course prices. Set SALES_SIM_BUDGET_USD to stop before
a paid request once the ledger reaches that many dollars; replays stay allowed.
SALES_SIM_CACHE=off disables storage and replay.

Adapted from the cached LM wrapper of Stanford CS329Z Assignment 1
(https://github.com/cs329z/assignment1-harness, MIT license).
"""

import copy
import hashlib
import json
import math
import os
import threading
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime, timezone
from pathlib import Path

from .evaluation_report import api_cost_usd

DIRECTORY_NAME = ".sales_cache"
CACHE_VARIABLE = "SALES_SIM_CACHE"
DIRECTORY_VARIABLE = "SALES_SIM_CACHE_DIR"
BUDGET_VARIABLE = "SALES_SIM_BUDGET_USD"
KEY_VERSION = 1

_ACTIVE = ContextVar("sales_response_cache", default=None)
_LEDGERS = {}
_LEDGERS_LOCK = threading.Lock()


class SpendCapReached(RuntimeError):
    """The personal spending cap stopped a paid request before it was sent."""


def current_cache():
    """The cache clients created in the active context bind for their lifetime."""
    return _ACTIVE.get()


def cache_enabled():
    return os.environ.get(CACHE_VARIABLE, "on").strip().lower() not in {"off", "0", "false", "no"}


def cache_directory(root):
    """SALES_SIM_CACHE_DIR, or .sales_cache in the student folder."""
    override = os.environ.get(DIRECTORY_VARIABLE, "").strip()
    return Path(override).expanduser() if override else Path(root) / DIRECTORY_NAME


def cap_from_environment():
    """The personal cap in dollars from SALES_SIM_BUDGET_USD, or None."""
    text = os.environ.get(BUDGET_VARIABLE, "").strip()
    if not text:
        return None
    try:
        cap = float(text)
    except ValueError:
        raise ValueError(f"{BUDGET_VARIABLE} must be a number of dollars, such as 20.") from None
    if not math.isfinite(cap) or cap <= 0:
        raise ValueError(f"{BUDGET_VARIABLE} must be a positive number of dollars.")
    return cap


class OpenAICodec:
    """Store a Responses API object as JSON and rebuild the same object type."""

    @staticmethod
    def dump(response):
        return response.model_dump(mode="json", warnings=False)

    @staticmethod
    def load(data):
        from openai.types.responses import Response

        try:
            return Response.model_validate(data)
        except Exception:  # noqa: BLE001 -- the SDK itself builds responses leniently
            from openai._models import construct_type

            return construct_type(type_=Response, value=data)


def _now():
    return datetime.now(timezone.utc).isoformat()


def _usage(receipt):
    return {name: (receipt or {}).get(name)
            for name in ("input_tokens", "cached_input_tokens", "output_tokens")}


class _Ledger:
    """One append-only spending record per cache directory, shared in this process."""

    def __init__(self, path):
        self.path = path
        self.lock = threading.Lock()
        self._spent = None

    def spent(self):
        with self.lock:
            if self._spent is None:
                self._spent = sum(row.get("cost_usd") or 0.0 for row in read_ledger(self.path.parent))
            return self._spent

    def append(self, row):
        with self.lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(row, allow_nan=False) + "\n")
                stream.flush()
            if self._spent is not None:
                self._spent += row.get("cost_usd") or 0.0


def _ledger_for(path):
    key = str(path)
    with _LEDGERS_LOCK:
        if key not in _LEDGERS:
            _LEDGERS[key] = _Ledger(path)
        return _LEDGERS[key]


class ResponseCache:
    """Stored responses and the spending ledger of one cache directory.

    ``scoped(salt=..., tag=...)`` returns a view for one trial or one check;
    views share the directory, the ledger and the cap.
    """

    def __init__(self, directory, *, prices=None, cap_usd=None, salt="", tag="",
                 codec=None, replay=True):
        self.directory = Path(directory)
        self.prices = dict(prices or {})
        self.cap_usd = cap_usd
        self.salt = str(salt)
        self.tag = str(tag)
        self.codec = codec or OpenAICodec()
        self.replay = replay
        self._ledger = _ledger_for(self.directory / "ledger.jsonl")
        self._shared = {"cap_reached": False}
        self.stats = self._empty_stats()

    @staticmethod
    def _empty_stats():
        return {"replayed": 0, "live": 0, "stored": 0, "store_errors": 0, "unreadable": 0}

    def scoped(self, *, salt=None, tag=None):
        view = copy.copy(self)
        view.salt = self.salt if salt is None else str(salt)
        view.tag = self.tag if tag is None else str(tag)
        view.stats = self._empty_stats()
        return view

    @property
    def cap_reached(self):
        return self._shared["cap_reached"]

    @contextmanager
    def activate(self):
        """API clients created inside this block replay from and record to this cache."""
        token = _ACTIVE.set(self)
        try:
            yield self
        finally:
            _ACTIVE.reset(token)

    def spent(self):
        return self._ledger.spent()

    # -- stored responses ------------------------------------------------------

    def key(self, role, request):
        """A digest of everything that determines the reply; None if not JSON."""
        try:
            blob = json.dumps([KEY_VERSION, role, self.salt, request], sort_keys=True,
                              ensure_ascii=False, allow_nan=False)
        except (TypeError, ValueError):
            return None
        return hashlib.sha256(blob.encode("utf-8")).hexdigest()

    def _path(self, key):
        return self.directory / "responses" / key[:2] / f"{key}.json"

    def lookup(self, key):
        """(response, stored record) for a stored key, or None. A damaged entry is a miss."""
        if not self.replay or key is None:
            return None
        path = self._path(key)
        try:
            stored = json.loads(path.read_text(encoding="utf-8"))
            response = self.codec.load(stored["response"])
        except FileNotFoundError:
            return None
        except Exception:  # noqa: BLE001 -- the live call that follows rewrites the entry
            self.stats["unreadable"] += 1
            return None
        return response, stored

    def store(self, key, response, *, role, model, usage, response_id):
        """Keep a completed response for later replay. A failure never stops the run."""
        if key is None:
            return False
        path = self._path(key)
        temporary = path.with_name(f"{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
        try:
            record = {"schema_version": 1, "role": role, "model": model, "response_id": response_id,
                      "usage": _usage(usage), "tag": self.tag, "stored_utc": _now(),
                      "response": self.codec.dump(response)}
            path.parent.mkdir(parents=True, exist_ok=True)
            temporary.write_text(json.dumps(record, allow_nan=False), encoding="utf-8")
            os.replace(temporary, path)
        except Exception:  # noqa: BLE001
            self.stats["store_errors"] += 1
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
            return False
        self.stats["stored"] += 1
        return True

    # -- spending --------------------------------------------------------------

    def require_allowance(self):
        """Raise SpendCapReached before a paid request once the ledger reaches the cap."""
        if self.cap_usd is None:
            return
        spent = self._ledger.spent()
        if spent >= self.cap_usd:
            self._shared["cap_reached"] = True
            raise SpendCapReached(
                f"Spent ${spent:.2f} of the ${self.cap_usd:.2f} cap set by {BUDGET_VARIABLE}; "
                "no request was sent. Raise the cap to continue (requests already paid for replay free)."
            )

    def charge(self, *, role, model, usage, response_id, replayed, assumed=False):
        """Append one request to the ledger: its estimated cost, or zero for a replay.

        assumed marks a failed attempt (dropped connection, timeout) charged at the
        most it could have cost, so the spending cap stays conservative.
        """
        usage = _usage(usage)
        cost = api_cost_usd(usage, model, self.prices)
        self.stats["replayed" if replayed else "live"] += 1
        try:
            self._ledger.append({
                "ts": _now(), "role": role, "model": model, "tag": self.tag,
                **usage, "replayed": bool(replayed), "response_id": response_id,
                "cost_usd": 0.0 if replayed else cost,
                "saved_usd": cost if replayed else 0.0,
                **({"assumed_worst_case": True} if assumed else {}),
            })
        except (OSError, TypeError, ValueError):
            self.stats["store_errors"] += 1


def read_ledger(directory):
    """Every readable ledger row; a partly written last line is skipped."""
    path = Path(directory) / "ledger.jsonl"
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError):
        return []
    rows = []
    for line in lines:
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if isinstance(row, dict):
            rows.append(row)
    return rows


def replay_summary(events, prices, models=None):
    """Replayed and live responses in one attempt's receipts, and its new spending."""
    models = models or {}
    completed = [event for event in events if event.get("event") == "completed"]
    replayed = [event for event in completed if event.get("replayed")]
    cost, known = 0.0, True
    for event in completed:
        if event.get("replayed"):
            continue
        value = api_cost_usd(_usage(event.get("usage")), event.get("model") or models.get(event.get("role")),
                             prices)
        if value is None:
            known = False
        else:
            cost += value
    return {"responses": len(completed), "replayed_responses": len(replayed),
            "new_api_cost_usd": round(cost, 4) if known else None}


def _money(value):
    return "unknown" if value is None else f"${value:,.4f}"


def spending_report(directory, *, cap_usd=None):
    """What the ledger records: spending and replays by role and model, then by tag."""
    rows = read_ledger(directory)
    if not rows:
        return f"No API requests recorded yet in {directory}."
    groups = {"By role and model": {}, "By run (most expensive first)": {}}
    for row in rows:
        keys = {"By role and model": f"{row.get('role', '?')} · {row.get('model', '?')}",
                "By run (most expensive first)": row.get("tag") or "(untagged)"}
        for title, key in keys.items():
            total = groups[title].setdefault(key, {"live": 0, "replayed": 0, "input": 0, "output": 0,
                                                   "spent": 0.0, "saved": 0.0, "unknown": 0})
            total["replayed" if row.get("replayed") else "live"] += 1
            if not row.get("replayed"):
                total["input"] += row.get("input_tokens") or 0
                total["output"] += row.get("output_tokens") or 0
                if row.get("cost_usd") is None:
                    total["unknown"] += 1
            total["spent"] += row.get("cost_usd") or 0.0
            total["saved"] += row.get("saved_usd") or 0.0
    lines = []
    for title, table in groups.items():
        lines.append(title)
        lines.append(f"  {'name':<58}{'paid':>7}{'replayed':>10}{'in tok':>13}{'out tok':>11}{'spent':>11}{'saved':>11}")
        ordered = sorted(table.items(), key=lambda item: -item[1]["spent"])
        for name, total in ordered[:40]:
            note = " *" if total["unknown"] else ""
            lines.append(f"  {name[-57:]:<58}{total['live']:>7}{total['replayed']:>10}{total['input']:>13,}"
                         f"{total['output']:>11,}{total['spent']:>11.4f}{total['saved']:>11.4f}{note}")
        if len(ordered) > 40:
            lines.append(f"  ... and {len(ordered) - 40} more")
        lines.append("")
    spent = sum(row.get("cost_usd") or 0.0 for row in rows)
    saved = sum(row.get("saved_usd") or 0.0 for row in rows)
    paid = sum(not row.get("replayed") for row in rows)
    lines.append(f"Total: {paid} paid requests, about ${spent:.2f} at the course prices; "
                 f"{len(rows) - paid} replayed from the cache, saving about ${saved:.2f}.")
    if any(row.get("cost_usd") is None and not row.get("replayed") for row in rows):
        lines.append("* Some requests used a model without a price in course.json; their cost is not counted.")
    if cap_usd is not None:
        lines.append(f"Cap ({BUDGET_VARIABLE}): ${cap_usd:.2f}; remaining about ${max(cap_usd - spent, 0):.2f}.")
    else:
        lines.append(f"No personal cap. Set {BUDGET_VARIABLE} to stop before a paid request at that total.")
    lines.append("These are estimates from receipts, not an invoice; check your provider's usage page.")
    return "\n".join(lines)


# Portions adapted from Stanford CS329Z Assignment 1 (https://github.com/cs329z/assignment1-harness):
#
# MIT License
#
# Copyright (c) 2026 cs329z
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
