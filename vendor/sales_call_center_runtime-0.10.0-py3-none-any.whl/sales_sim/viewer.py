"""Self-contained, read-only HTML report for one recorded campaign, and an index of runs.

The report reads top to bottom: what the run earned and why in one sentence,
where the accounts ended up, how each day's contact time was used, then each
account's conversation and, for tool builders, the agent's log of tool calls.
Raw logs stay in the run folder and are linked at the bottom.

Evidence is always escaped before it enters HTML; no server or external assets
are needed. The inline scripts only switch views, filter the list and show tooltips.
"""

import html
import json
import re
from pathlib import Path, PurePosixPath
from urllib.parse import quote, unquote, urlsplit


EXCHANGES = {"talk_to_customer", "present_quote"}
DETAIL_LIMIT = 5000          # characters of one call's input or output shown on the page

# Account outcomes, in the order the bar and the filters show them.
STATES = (
    ("bought", "Bought"),
    ("talking", "Still talking"),
    ("declined", "Declined"),
    ("opted-out", "Opted out"),
    ("not-contacted", "Never contacted"),
)


STYLE = """
:root{color-scheme:light;--page:#f6f6f3;--card:#fff;--ink:#0b0b0b;--ink2:#52514e;--muted:#898781;
--line:#e6e5df;--ring:rgba(11,11,11,.10);--blue:#2a78d6;--blue-dark:#1c5cab;--blue-wash:#eaf2fc;--wash:#f3f3ef;
--good:#0ca30c;--good-text:#006300;--warn:#fab219;--warn-text:#7a5200;--serious:#ec835a;--bad:#d03b3b;--talk:#b9b7ae}
*{box-sizing:border-box}
html{background:var(--page)}
body{margin:0;background:var(--page);color:var(--ink);font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif;-webkit-font-smoothing:antialiased}
main{max-width:1180px;margin:0 auto;padding:32px 28px 64px}
h1,h2,h3,p{margin:0}
h1{font-size:24px;line-height:1.25;font-weight:650;letter-spacing:-.3px;overflow-wrap:anywhere}
h2{font-size:15px;font-weight:600}
a{color:var(--blue-dark)}
button{font:inherit;color:inherit}
code,pre,.mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
.meta{color:var(--ink2);font-size:13px;margin-top:4px}
.top{display:flex;justify-content:space-between;align-items:flex-end;gap:24px;flex-wrap:wrap}
.hero{text-align:right}
.hero span{display:block;font-size:13px;color:var(--ink2)}
.hero strong{display:block;font-size:44px;line-height:1.1;font-weight:650;letter-spacing:-1px}
.hero small{display:block;font-size:12px;color:var(--muted);margin-top:4px}
.summary{margin:20px 0 0;font-size:16px;line-height:1.6;max-width:880px;color:var(--ink)}
.summary b{font-weight:650}.linkish{display:inline;border:0;background:none;padding:0;font:inherit;color:var(--bad);cursor:pointer;text-align:left;text-decoration:underline;text-decoration-color:rgba(208,59,59,.35);text-underline-offset:3px}.linkish:hover{text-decoration-color:var(--bad)}
.banner{margin:20px 0 0;padding:12px 16px;border-radius:10px;background:#fdeeee;border:1px solid #f2c4c4;font-size:14px}
.banner.note{background:#fff8e6;border-color:#f1dca4}
.banner ul{margin:6px 0 0;padding-left:18px}.banner summary{cursor:pointer;font-size:13px;color:var(--ink2);margin-top:6px}.banner pre{margin-top:6px;background:rgba(255,255,255,.6)}
.card{background:var(--card);border:1px solid var(--ring);border-radius:14px;padding:20px 22px}
.grid2{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.25fr);gap:16px;margin-top:24px}
.card h2{margin-bottom:4px}.card .sub{font-size:13px;color:var(--ink2);margin-bottom:16px}
.seg{display:flex;gap:2px;height:28px;margin:4px 0 14px}
.part{border:0;padding:0 8px;border-radius:4px;cursor:pointer;color:#fff;font-size:13px;font-weight:600;text-align:left;min-width:6px;white-space:nowrap;overflow:hidden}
.part:hover,.part:focus-visible{filter:brightness(1.08);outline:none;box-shadow:0 0 0 2px var(--card),0 0 0 4px var(--ink2)}
.legend{display:flex;flex-wrap:wrap;gap:6px 16px;margin:0;padding:0;list-style:none}
.legend button{display:inline-flex;align-items:center;gap:7px;border:0;background:none;padding:2px 0;cursor:pointer;font-size:13px;color:var(--ink2)}
.legend button:hover{color:var(--ink)}
.legend b{color:var(--ink);font-weight:600}
.stats{display:flex;gap:28px;margin-top:22px;padding-top:16px;border-top:1px solid var(--line);flex-wrap:wrap}
.stats div{font-size:12px;color:var(--ink2)}.stats strong{display:block;font-size:20px;font-weight:650;color:var(--ink)}
.sw{display:inline-block;width:10px;height:10px;border-radius:3px}
.bought{background:var(--good)}.talking{background:var(--talk)}.declined{background:var(--serious)}
.opted-out{background:var(--bad)}.not-contacted{background:var(--warn)}
.part.not-contacted,.part.talking{color:var(--ink)}
.chart{display:grid;grid-template-columns:44px minmax(0,1fr);row-gap:6px}
.yaxis{position:relative;height:150px;font-size:11px;color:var(--muted)}
.yaxis span{position:absolute;right:8px;transform:translateY(50%)}
.plot{position:relative;height:150px}
.gl{position:absolute;left:0;right:0;height:1px;background:var(--line)}
.gl.base{background:#c3c2b7}
.cols{position:absolute;inset:0;display:flex}
.col{position:relative;flex:1;display:flex;align-items:flex-end;justify-content:center;border:0;background:none;padding:0;cursor:pointer;border-radius:4px}
.col:hover,.col:focus-visible{background:rgba(42,120,214,.06);outline:none}
.col i{display:block;width:min(24px,64%);background:var(--blue);border-radius:4px 4px 0 0}
.col:hover i,.col:focus-visible i{background:var(--blue-dark)}
.col.change::before{content:"";position:absolute;left:0;top:-4px;bottom:0;width:1px;background:var(--ink2)}
.col.change::after{content:"new prices";position:absolute;left:4px;top:-6px;font-size:11px;color:var(--ink2);white-space:nowrap}
.xaxis{display:flex;grid-column:2;font-size:11px;color:var(--muted)}
.xaxis span{flex:1;text-align:center;font-variant-numeric:tabular-nums}
.tip{position:fixed;z-index:10;pointer-events:none;background:var(--ink);color:#fff;font-size:12px;line-height:1.45;padding:8px 10px;border-radius:8px;max-width:260px;white-space:pre-line}
.checks{margin-top:16px}.checks ul{list-style:none;margin:8px 0 0;padding:0}
.checks li{font-size:14px;padding:6px 0;border-top:1px solid var(--line)}
.checks li:first-child{border-top:0}
.pass{color:var(--good-text);font-weight:600}.fail{color:var(--bad);font-weight:600}.review{color:var(--warn-text);font-weight:600}
.tabs{display:flex;gap:4px;margin:32px 0 12px;border-bottom:1px solid var(--line)}
.tab{border:0;background:none;padding:10px 14px;font-size:15px;font-weight:600;color:var(--ink2);cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-1px}
.tab[aria-selected=true]{color:var(--ink);border-bottom-color:var(--ink)}
.tab small{font-weight:500;color:var(--muted);margin-left:4px}
.split{display:grid;grid-template-columns:320px minmax(0,1fr);padding:0;overflow:hidden;min-height:560px}
.list{border-right:1px solid var(--line);display:flex;flex-direction:column;min-height:0}
.filters{display:flex;flex-wrap:wrap;gap:6px;padding:14px 14px 10px;border-bottom:1px solid var(--line)}
.chip{border:1px solid var(--line);background:var(--card);border-radius:999px;padding:3px 10px;font-size:12px;cursor:pointer;color:var(--ink2)}
.chip:hover{border-color:var(--muted)}
.chip[aria-pressed=true]{background:var(--ink);border-color:var(--ink);color:#fff}
.accts{overflow:auto;max-height:720px}
.acct{display:grid;grid-template-columns:12px minmax(0,1fr);gap:10px;width:100%;text-align:left;border:0;border-bottom:1px solid var(--line);background:none;padding:10px 14px;cursor:pointer}
.acct:hover{background:var(--wash)}
.acct[aria-selected=true]{background:var(--blue-wash)}
.acct .sw{margin-top:5px}
.acct-name{display:block;font-size:14px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.acct-sub{display:block;font-size:12px;color:var(--ink2)}
.flag{color:var(--bad);font-weight:600}
.convo{padding:22px 26px;min-width:0}
.convo-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;padding-bottom:14px;border-bottom:1px solid var(--line)}
.convo-head h3{font-size:18px;font-weight:650}
.convo-head .meta{margin-top:2px}
.pill{display:inline-block;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:600;white-space:nowrap;background:var(--wash);color:var(--ink2)}
.pill.bought{background:#e3f4e3;color:var(--good-text)}.pill.declined{background:#fcebe3;color:#8a3a17}
.pill.opted-out{background:#fbe4e4;color:#8f1f1f}.pill.not-contacted{background:#fff2cc;color:var(--warn-text)}
.timeline{display:flex;flex-direction:column;gap:8px;padding-top:6px}
.dayrule{display:flex;align-items:center;gap:10px;font-size:12px;font-weight:600;color:var(--muted);margin:14px 0 2px}
.dayrule::before,.dayrule::after{content:"";flex:1;height:1px;background:var(--line)}
.bubble{max-width:78%;padding:10px 14px;border-radius:14px;white-space:pre-wrap;overflow-wrap:anywhere;font-size:14px;line-height:1.55}
.bubble small{display:block;font-size:11px;font-weight:600;color:var(--muted);margin-bottom:2px}
.bubble.seller{align-self:flex-end;background:var(--blue-wash);border-bottom-right-radius:4px}
.bubble.customer{align-self:flex-start;background:var(--wash);border-bottom-left-radius:4px}
.bubble.failed{align-self:flex-end;background:#fdeeee;border-bottom-right-radius:4px}
.bubble.failed small{color:var(--bad)}
.event{align-self:center;font-size:12px;color:var(--ink2);text-align:center;max-width:90%;overflow-wrap:anywhere}
.event.offer{color:var(--ink);font-weight:600}
.event.good{color:var(--good-text);font-weight:600}.event.bad{color:var(--bad);font-weight:600}
.empty{color:var(--muted);font-size:14px;padding:24px 0}
.log{padding:0}
.loghead{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;padding:14px 18px;border-bottom:1px solid var(--line)}
.days{display:flex;flex-wrap:wrap;gap:4px;align-items:center}
.days>span{font-size:13px;color:var(--ink2);margin-right:4px}
.daybtn{position:relative;min-width:34px;border:1px solid var(--line);background:var(--card);border-radius:8px;padding:4px 8px;font-size:13px;cursor:pointer;font-variant-numeric:tabular-nums}
.daybtn:hover{border-color:var(--muted)}
.daybtn[aria-pressed=true]{background:var(--ink);border-color:var(--ink);color:#fff}
.daybtn.has-err::after{content:"";position:absolute;top:-3px;right:-3px;width:8px;height:8px;border-radius:50%;background:var(--bad);border:2px solid var(--card)}
.toggle{display:inline-flex;gap:6px;align-items:center;font-size:13px;color:var(--ink2);cursor:pointer}
.daylog{padding:6px 18px 18px}
.daymeta{font-size:13px;color:var(--ink2);padding:10px 0}
details.call{border-top:1px solid var(--line)}
details.call>summary{list-style:none;cursor:pointer;padding:9px 4px;display:block}
details.call>summary::-webkit-details-marker{display:none}
details.call>summary:hover{background:var(--wash)}
.fn{font-size:13px;font-weight:600}
.args{font-size:12px;color:var(--ink2)}
.line1{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.res{font-size:13px;color:var(--ink2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:1px}
.call.err .res{color:var(--bad)}
.call.err .fn::before{content:"✕ ";color:var(--bad)}
.body{padding:2px 4px 14px}
.body h4{font-size:12px;font-weight:600;color:var(--ink2);margin:10px 0 4px}
pre{white-space:pre-wrap;overflow-wrap:anywhere;background:var(--wash);padding:10px 12px;border-radius:8px;font-size:12px;line-height:1.5;margin:0;max-height:380px;overflow:auto}
.ran{font-size:12px;color:var(--ink2)}
.ended{margin-top:12px;padding:10px 14px;border-radius:10px;background:var(--wash);font-size:13px;white-space:pre-wrap;overflow-wrap:anywhere}
.ended b{font-weight:600}
.errors-only .call:not(.err),.errors-only .daylog:not(.has-err),.errors-only .ended,.errors-only .daymeta .hide-err{display:none}
.errors-only .daylog.has-err{display:block!important}
footer{margin-top:28px;font-size:12px;color:var(--muted)}
footer a{color:var(--ink2)}
[hidden]{display:none!important}
.flash{animation:flash 1.6s ease-out}
@keyframes flash{from{box-shadow:0 0 0 3px var(--blue)}to{box-shadow:0 0 0 3px transparent}}
:focus-visible{outline:2px solid var(--blue);outline-offset:2px}
body.index-page main{max-width:none;padding:0}
.ix-top{display:flex;align-items:baseline;gap:12px;padding:14px 22px;background:var(--card);border-bottom:1px solid var(--ring)}
.ix-top h1{font-size:18px}
.run-layout{display:grid;grid-template-columns:260px minmax(0,1fr);height:calc(100vh - 53px)}
.run-sidebar{background:var(--card);border-right:1px solid var(--ring);overflow:auto;padding:10px 10px 24px}
.group{padding:14px 10px 6px;font-size:13px;font-weight:650;display:flex;justify-content:space-between;gap:8px;align-items:baseline}
.group small{display:block;font-size:11px;font-weight:500;color:var(--muted)}
.group .mean{font-size:12px;font-weight:500;color:var(--ink2);white-space:nowrap}
.attempt-row{margin:0}
.run-select{display:flex;justify-content:space-between;gap:8px;width:100%;border:0;background:none;padding:8px 10px;border-radius:8px;text-align:left;font-size:14px;cursor:pointer}
.run-select:hover{background:var(--wash)}
.attempt-row.selected .run-select{background:var(--blue-wash);font-weight:600}
.run-outcome{font-variant-numeric:tabular-nums}
.run-error{font-size:12px;color:var(--bad);padding:0 10px 6px;margin:0}
.run-file{display:none}
.run-content{display:flex;flex-direction:column;min-width:0}
.run-toolbar{display:flex;gap:12px;align-items:center;padding:8px 18px;font-size:13px;color:var(--ink2);border-bottom:1px solid var(--line);background:var(--page)}
.run-toolbar a{margin-left:auto}
.run-frame{flex:1;width:100%;border:0;background:var(--page)}
@media(max-width:860px){main{padding:22px 16px 48px}
.hero{text-align:left}.hero strong{font-size:36px}
.grid2{grid-template-columns:1fr}
.split{grid-template-columns:1fr}
.list{border-right:0;border-bottom:1px solid var(--line)}
.accts{max-height:300px}
.convo{padding:18px 16px}.bubble{max-width:92%}
.run-layout{grid-template-columns:1fr;height:auto}
.run-sidebar{max-height:240px;border-right:0;border-bottom:1px solid var(--ring)}
.run-content{height:88vh}}
"""

SCRIPT = """
(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const tabs = $$('.tab');
  function view(name) {
    tabs.forEach(tab => tab.setAttribute('aria-selected', String(tab.dataset.view === name)));
    $$('[data-panel]').forEach(panel => { panel.hidden = panel.dataset.panel !== name; });
  }
  tabs.forEach(tab => tab.addEventListener('click', () => view(tab.dataset.view)));

  const rows = $$('.acct');
  const chips = $$('.chip');
  function pick(id) {
    rows.forEach(row => row.setAttribute('aria-selected', String(row.dataset.account === id)));
    $$('.convo').forEach(item => { item.hidden = item.id !== 'account-' + id; });
  }
  function filter(name) {
    chips.forEach(chip => chip.setAttribute('aria-pressed', String(chip.dataset.filter === name)));
    let first = null;
    rows.forEach(row => {
      row.hidden = name !== 'all' && !row.dataset.tags.split(' ').includes(name);
      if (!row.hidden && !first) first = row;
    });
    const none = $('#no-accounts');
    if (none) none.hidden = Boolean(first);
    const selected = rows.find(row => row.getAttribute('aria-selected') === 'true' && !row.hidden);
    if (!selected && first) pick(first.dataset.account);
  }
  rows.forEach(row => row.addEventListener('click', () => {
    pick(row.dataset.account);
    if (window.matchMedia('(max-width: 860px)').matches) $('#account-' + CSS.escape(row.dataset.account)).scrollIntoView();
  }));
  chips.forEach(chip => chip.addEventListener('click', () => filter(chip.dataset.filter)));
  $$('[data-show]').forEach(button => button.addEventListener('click', () => {
    view('accounts'); filter(button.dataset.show); $('#views').scrollIntoView({behavior: 'smooth'});
  }));

  const dayButtons = $$('.daybtn');
  const log = $('#log');
  const errorsOnly = $('#errors-only');
  function day(number) {
    dayButtons.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.day === number)));
    $$('.daylog').forEach(section => { section.hidden = section.dataset.day !== number; });
  }
  dayButtons.forEach(button => button.addEventListener('click', () => { errors(false); day(button.dataset.day); }));
  function errors(on) {
    if (!log) return;
    if (errorsOnly) errorsOnly.checked = on;
    log.classList.toggle('errors-only', on);
    if (on) {
      $$('.daylog.has-err details.call.err').forEach(call => { call.open = true; });
      dayButtons.forEach(button => button.setAttribute('aria-pressed', 'false'));
    } else if (!dayButtons.some(button => button.getAttribute('aria-pressed') === 'true') && dayButtons.length) {
      day(dayButtons[0].dataset.day);
    }
  }
  if (errorsOnly) errorsOnly.addEventListener('change', () => errors(errorsOnly.checked));
  $$('.col').forEach(col => col.addEventListener('click', () => {
    view('log'); errors(false); day(col.dataset.day); $('#views').scrollIntoView({behavior: 'smooth'});
  }));
  $$('[data-errors]').forEach(button => button.addEventListener('click', () => {
    view('log'); errors(true); $('#views').scrollIntoView({behavior: 'smooth'});
  }));

  const tip = $('#tip');
  function showTip(event) {
    const target = event.currentTarget;
    tip.textContent = target.dataset.tip;
    tip.hidden = false;
    const box = target.getBoundingClientRect();
    const left = Math.min(window.innerWidth - tip.offsetWidth - 8, Math.max(8, box.left + box.width / 2 - tip.offsetWidth / 2));
    tip.style.left = left + 'px';
    tip.style.top = Math.max(8, box.top - tip.offsetHeight - 8) + 'px';
  }
  $$('[data-tip]').forEach(item => {
    item.addEventListener('pointerenter', showTip); item.addEventListener('focus', showTip);
    item.addEventListener('pointerleave', () => { tip.hidden = true; });
    item.addEventListener('blur', () => { tip.hidden = true; });
  });

  function reveal(id) {
    const target = document.getElementById(id);
    if (!target) return;
    const panel = target.closest('[data-panel]');
    if (panel) view(panel.dataset.panel);
    const section = target.closest('.daylog');
    if (section) { errors(false); day(section.dataset.day); }
    const convo = target.closest('.convo');
    if (convo) { filter('all'); pick(convo.id.replace('account-', '')); }
    for (let node = target; node; node = node.parentElement) if (node.tagName === 'DETAILS') node.open = true;
    const shown = target.offsetParent ? target : target.closest('details') || target;
    shown.scrollIntoView({block: 'center'});
    shown.classList.add('flash');
    setTimeout(() => shown.classList.remove('flash'), 1700);
  }
  $$('a.jump').forEach(link => link.addEventListener('click', event => {
    event.preventDefault(); reveal(link.getAttribute('href').slice(1));
  }));
  window.addEventListener('hashchange', () => reveal(location.hash.slice(1)));

  view('accounts');
  filter('all');
  const busy = rows.find(row => !row.dataset.tags.includes('not-contacted')) || rows[0];
  if (busy) pick(busy.dataset.account);
  if (dayButtons.length) day(dayButtons[0].dataset.day);
  if (location.hash) reveal(location.hash.slice(1));
})();
"""

INDEX_SCRIPT = """
(() => {
  const buttons = [...document.querySelectorAll('.run-select')];
  const frame = document.getElementById('run-frame');
  const open = document.getElementById('open-run');
  function select(button) {
    const template = document.getElementById(button.dataset.document);
    if (!template) return;
    frame.srcdoc = template.content.querySelector('textarea').value;
    frame.title = button.dataset.label;
    document.getElementById('selected-run').textContent = button.dataset.label;
    open.href = button.dataset.path;
    open.hidden = !button.dataset.path;
    buttons.forEach(item => {
      item.setAttribute('aria-pressed', String(item === button));
      item.closest('.attempt-row').classList.toggle('selected', item === button);
    });
  }
  buttons.forEach(button => button.addEventListener('click', () => select(button)));
  if (buttons.length) select(buttons[0]);
})();
"""


# ----------------------------------------------------------------------------- small helpers

def _escape(value):
    return html.escape(str(value), quote=True)


def _mapping(value):
    return value if isinstance(value, dict) else {}


def _label(value):
    return str(value).replace("_", " ").capitalize()


def _money(value):
    return f"${value / 100:,.2f}" if isinstance(value, (int, float)) and not isinstance(value, bool) else "Unknown"


def _int(value):
    return value if isinstance(value, int) and not isinstance(value, bool) else None


def _short(text, limit):
    text = " ".join(str(text).split())
    return text if len(text) <= limit else text[:limit - 1] + "…"


def _safe_path(value):
    """Permit only links to relative files inside the output directory."""
    if not isinstance(value, str) or not value:
        return None
    decoded = unquote(value)
    try:
        parsed = urlsplit(decoded)
    except ValueError:
        return None
    path = PurePosixPath(decoded)
    if (parsed.scheme or parsed.netloc or parsed.query or parsed.fragment
            or path.is_absolute() or ".." in path.parts or "\\" in decoded
            or any(ord(character) < 32 for character in decoded)):
        return None
    return quote(decoded, safe="/._-")


def _link(path, title):
    safe = _safe_path(path)
    return f'<a href="{_escape(safe)}">{_escape(title)}</a>' if safe else _escape(title)


def _pretty(value):
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2)
    if len(text) > DETAIL_LIMIT:
        text = text[:DETAIL_LIMIT] + f"\n… {len(text) - DETAIL_LIMIT:,} more characters in the saved log"
    return f"<pre>{_escape(text)}</pre>"


def _read_artifact(directory, filename, warnings):
    path = directory / filename
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        warnings.append(f"{filename} could not be read ({type(error).__name__}).")
        return None


def _read_custom_trace(directory, warnings):
    """Read complete JSONL receipts even when another line was truncated."""
    filename = "custom_tools.jsonl"
    path = directory / filename
    if not path.is_file():
        return [], False
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError) as error:
        warnings.append(f"{filename} could not be read ({type(error).__name__}).")
        return [], True
    records = []
    for line, text in enumerate(lines, 1):
        if not text.strip():
            continue
        try:
            record = json.loads(text)
        except json.JSONDecodeError:
            warnings.append(f"{filename} line {line} is not valid JSON; other steps remain visible.")
            continue
        if (not isinstance(record, dict) or not isinstance(record.get("name"), str)
                or not isinstance(record.get("result"), dict)
                or type(record["result"].get("ok")) is not bool):
            warnings.append(f"{filename} line {line} is not a complete tool-call record.")
            continue
        records.append((line, record))
    return records, True


# ----------------------------------------------------------------------------- reading the run

def _customer_maps(dataset, trace):
    """Customer names, and which customer owns each quote or record ID (from explicit fields only)."""
    names, owners = {}, {}
    scenario = _mapping(_mapping(dataset).get("scenario"))
    for customer in scenario.get("customers", []) if isinstance(scenario.get("customers"), list) else []:
        customer = _mapping(customer)
        if isinstance(customer.get("id"), str):
            names[customer["id"]] = str(customer.get("business") or customer.get("name") or customer["id"])

    def visit(value):
        if isinstance(value, list):
            for child in value:
                visit(child)
        elif isinstance(value, dict):
            customer_id = value.get("customer_id") or _mapping(value.get("quote")).get("customer_id")
            if isinstance(customer_id, str) and isinstance(value.get("id"), str):
                owners[value["id"]] = customer_id
            for child in value.values():
                if isinstance(child, (dict, list)):
                    visit(child)

    visit(dataset)
    for item in trace:
        visit(item.get("result"))
    return names, owners


def _customer_id(item, owners):
    arguments = _mapping(item.get("arguments"))
    data = _mapping(_mapping(item.get("result")).get("data"))
    for value in (arguments.get("customer_id"), data.get("customer_id"),
                  _mapping(data.get("reply")).get("customer_id"),
                  _mapping(_mapping(data.get("order")).get("quote")).get("customer_id")):
        if isinstance(value, str) and value:
            return value
    for field in ("quote_id", "order_id", "record_id"):
        value = arguments.get(field)
        if isinstance(value, str) and value in owners:
            return owners[value]
    return ""


def _is_exchange(item):
    """A message that reached a customer: not a failed, replayed or already-accepted request."""
    result = _mapping(item.get("result"))
    return (item.get("name") in EXCHANGES and result.get("ok") is True and not item.get("replayed")
            and not _mapping(result.get("data")).get("already_accepted"))


def _day_messages(history):
    """What the model wrote, by campaign day, from the saved history (the day note opens each day)."""
    said, day = {}, None
    for entry in history if isinstance(history, list) else []:
        entry = _mapping(entry)
        content = entry.get("content")
        if entry.get("role") == "user" and isinstance(content, str):
            match = re.match(r"\s*Day (\d+) of \d+", content)
            if match:
                day = int(match.group(1))
            continue
        if entry.get("role") == "assistant" and day is not None:
            if isinstance(content, list):
                content = "\n".join(str(_mapping(part).get("text", "")) for part in content).strip()
            if isinstance(content, str) and content.strip():
                said.setdefault(day, []).append(content.strip())
    return said


def _analyze(evidence, custom_records, history):
    """Everything the page shows, computed from the recorded business actions."""
    trace = [_mapping(item) for item in evidence.get("trace") or []]
    dataset = _mapping(evidence.get("public_dataset"))
    scenario = _mapping(dataset.get("scenario"))
    config = _mapping(scenario.get("config"))
    names, owners = _customer_maps(dataset, trace)
    products = {
        product.get("id"): product.get("name") or product.get("id")
        for product in (scenario.get("products") if isinstance(scenario.get("products"), list) else [])
        if isinstance(product, dict)
    }
    budget = _int(config.get("contact_minutes_per_day"))
    per_message = _int(config.get("minutes_per_exchange"))
    accounts = {customer_id: _account(customer_id, name) for customer_id, name in names.items()}
    days, quotes, callbacks = {}, {}, []
    current, valid_days, policy = 1, None, None

    def day_of(number):
        return days.setdefault(number, {"day": number, "exchanges": 0, "accounts": set(), "new": 0,
                                         "offers": 0, "orders": 0, "steps": [], "errors": 0, "said": [],
                                         "new_pricing": False})

    for line, item in enumerate(trace, 1):
        current = _int(item.get("day")) or current
        day = day_of(current)
        name = item.get("name")
        result = _mapping(item.get("result"))
        data = _mapping(result.get("data"))
        customer_id = _customer_id(item, owners)
        account = None
        # A refused call with an ID the campaign doesn't know (a made-up ID) is not an account.
        if customer_id and (customer_id in accounts or result.get("ok")):
            account = accounts.setdefault(customer_id, _account(customer_id, names.get(customer_id, customer_id)))
        if name in {"get_status", "advance_day"} and result.get("ok"):
            budget = budget or _int(data.get("minutes_remaining_today"))
            per_message = per_message or _int(data.get("minutes_per_exchange"))
        terms = _mapping(data.get("current_pricing_policy"))
        if terms:
            valid_days = _int(terms.get("quote_valid_days"))
            if name == "advance_day" and policy and terms.get("id") != policy:
                day_of(_int(data.get("day")) or current + 1)["new_pricing"] = True
            policy = terms.get("id") or policy
        if name == "create_quote" and result.get("ok") and isinstance(data.get("id"), str):
            quotes[data["id"]] = data
        if name == "schedule_callback" and result.get("ok") and account is not None:
            target = _int(data.get("day")) or _int(_mapping(item.get("arguments")).get("day"))
            for booked in callbacks:
                if booked["customer"] == customer_id and booked["status"] == "pending":
                    booked["status"] = "missed" if booked["day"] <= current < (target or 0) else "moved"
            booked = {"customer": customer_id, "day": target, "status": "pending",
                      "reason": str(data.get("reason") or _mapping(item.get("arguments")).get("reason") or "")}
            callbacks.append(booked)
            account["callbacks"].append(booked)
            account["events"].append({"day": current, "kind": "callback", "line": line, "callback": booked})
        elif name == "save_note" and result.get("ok") and account is not None:
            text = data.get("text") or _mapping(item.get("arguments")).get("text") or ""
            account["events"].append({"day": current, "kind": "note", "line": line, "text": str(text)})
        elif name in EXCHANGES and account is not None:
            arguments = _mapping(item.get("arguments"))
            if not _is_exchange(item):
                if result.get("ok") is False:
                    error = _mapping(result.get("error"))
                    account["events"].append({"day": current, "kind": "failed", "line": line,
                                              "message": arguments.get("message"),
                                              "error": error.get("message") or error.get("code") or "Rejected."})
                continue
            quote_data = quotes.get(arguments.get("quote_id")) if name == "present_quote" else None
            if quote_data is not None and quote_data.get("issued_day") is None:
                # Issued with its first presentation; presenting it again keeps the same expiry.
                quote_data["issued_day"] = current
                quote_data["expires_day"] = current + valid_days if valid_days is not None else None
            reply = data.get("reply")
            reply_text = reply.get("text") if isinstance(reply, dict) else reply if isinstance(reply, str) else None
            decision = data.get("decision") or _mapping(reply).get("decision")
            order = _mapping(data.get("order"))
            account["events"].append({"day": current, "kind": "exchange", "line": line,
                                      "message": arguments.get("message"), "reply": reply_text,
                                      "decision": decision, "offer": quote_data, "order": order or None})
            first = not account["contact_days"]
            account["exchanges"] += 1
            account["contact_days"].add(current)
            if decision:
                account["decision"], account["decision_day"] = decision, current
            day["exchanges"] += 1
            day["accounts"].add(customer_id)
            day["new"] += first
            if quote_data:
                day["offers"] += 1
                account["offers"].append({"day": current, **quote_data})
            if order:
                day["orders"] += 1
                account["order"] = _mapping(order.get("quote")) or quote_data or {}
                account["order_day"] = current
            for booked in callbacks:
                if booked["customer"] == customer_id and booked["status"] == "pending" and (booked["day"] or 0) <= current:
                    booked["status"] = "kept"
            if decision in {"accept", "opt_out"}:
                for booked in callbacks:
                    if booked["customer"] == customer_id and booked["status"] == "pending":
                        booked["status"] = "canceled"
        if name == "advance_day" and result.get("ok"):
            if _int(data.get("day")) and not data.get("finished"):
                day_of(_int(data["day"]))                    # the day it opened, even if nothing happened
            for booked in callbacks:
                if booked["status"] == "pending" and (booked["day"] or 0) <= current:
                    booked["status"] = "missed"

    steps = _steps(trace, custom_records)
    last = current
    for step in steps:
        day = day_of(step["day"] or 1)
        day["steps"].append(step)
        day["errors"] += step["error"]
    for number, messages in _day_messages(history).items():
        if number in days or number <= last:
            day_of(number)["said"] = messages
    for account in accounts.values():
        account["tags"] = _tags(account)
    step_of_line = {}
    for step in steps:
        if not step["harness"]:
            for line in step["ops"] or [step["number"]]:
                step_of_line[line] = step
    return {"accounts": list(accounts.values()), "days": [days[key] for key in sorted(days)],
            "step_of_line": step_of_line,
            "budget": budget, "per_message": per_message or 0, "products": products,
            "steps": len([step for step in steps if not step["harness"]]),
            "errors": sum(step["error"] for step in steps)}


def _account(customer_id, name):
    return {"id": customer_id, "name": name, "events": [], "exchanges": 0, "contact_days": set(),
            "offers": [], "order": None, "order_day": None, "decision": None, "decision_day": None,
            "callbacks": []}


def _tags(account):
    tags = [_state(account)]
    if any(item["status"] == "missed" for item in account["callbacks"]):
        tags.append("missed-callback")
    return tags


def _steps(trace, custom_records):
    """The agent's steps: its own tool calls when they were logged, else the recorded actions.

    Each business action keeps its anchor (tool-N) inside the step that caused it, so
    links from checks still land. Harness actions (the day's opening status and its end)
    are anchors only.
    """
    lines_by_request = {}
    for line, item in enumerate(trace, 1):
        if isinstance(item.get("request_id"), str):
            lines_by_request.setdefault(item["request_id"], []).append(line)
    steps, covered, previous_day, previous_position = [], set(), None, 0.0
    for log_line, record in custom_records:
        ids = record.get("business_request_ids")
        lines = [line for request_id in (ids if isinstance(ids, list) else [])
                 if isinstance(request_id, str) for line in lines_by_request.get(request_id, [])]
        covered.update(lines)
        position = min(lines) if lines else previous_position + 0.001
        day = _int(trace[lines[0] - 1].get("day")) if lines else previous_day
        steps.append({"id": f"step-{log_line}", "number": log_line, "position": position, "day": day,
                      "record": record, "ops": lines, "harness": False,
                      "error": _mapping(record.get("result")).get("ok") is False})
        previous_day, previous_position = day if day is not None else previous_day, position
    for line, item in enumerate(trace, 1):
        if line in covered:
            continue
        harness = str(item.get("request_id", "")).startswith("harness:")
        steps.append({"id": f"tool-{line}", "number": line, "position": line, "day": _int(item.get("day")),
                      "record": item, "ops": [], "harness": harness,
                      "error": not harness and _mapping(item.get("result")).get("ok") is False})
    steps.sort(key=lambda step: step["position"])
    day = 1
    for step in steps:
        day = step["day"] = step["day"] or day
    return steps


# ----------------------------------------------------------------------------- rendering a run

def _plural(count, word, plural=None):
    return f"{count} {word if count == 1 else plural or word + 's'}"


def _call(record):
    parts = []
    for key, value in _mapping(record.get("arguments")).items():
        if isinstance(value, str):
            shown = '"' + _short(value, 40) + '"'
        elif isinstance(value, (dict, list)):
            shown = "{…}" if isinstance(value, dict) else "[…]"
        else:
            shown = json.dumps(value)
        parts.append(f"{key}={shown}")
    return str(record.get("name", "?")), "(" + ", ".join(parts) + ")"


def _outcome(record):
    result = _mapping(record.get("result"))
    if result.get("ok") is False:
        error = _mapping(result.get("error"))
        return "Error: " + str(error.get("message") or error.get("code") or "request rejected")
    if record.get("replayed"):
        return "Replayed from an earlier attempt; nothing new happened"
    data = result.get("data")
    if isinstance(data, dict):
        if data.get("already_accepted"):
            return "Already accepted; no message sent"
        reply = data.get("reply")
        text = reply.get("text") if isinstance(reply, dict) else reply if isinstance(reply, str) else None
        if text is not None:
            decision = data.get("decision") or _mapping(reply).get("decision")
            return f"Customer: {text}" + (f"  [{decision}]" if decision and decision != "continue" else "")
    if isinstance(data, list):
        return _plural(len(data), "item")
    if data is None:
        return "No result"
    return json.dumps(data, ensure_ascii=False) if not isinstance(data, str) else data


def _ran(step, trace):
    """The business operations a tool call ran, counted, with an anchor for each."""
    counts = {}
    for line in step["ops"]:
        name = str(trace[line - 1].get("name", "?"))
        counts[name] = counts.get(name, 0) + 1
    text = ", ".join(name + (f" ×{count}" if count > 1 else "") for name, count in counts.items())
    anchors = "".join(f'<span id="tool-{line}"></span>' for line in step["ops"])
    if list(counts.items()) == [(step["record"].get("name"), 1)]:
        return anchors                                      # a thin tool: the operation is the call itself
    return f'<h4>Operations it ran</h4><p class="ran mono">{_escape(text)}</p>{anchors}'


def _call_html(step, trace):
    if step["harness"]:
        return f'<span id="{_escape(step["id"])}"></span>'
    record = step["record"]
    result = _mapping(record.get("result"))
    name, arguments = _call(record)
    failed = result.get("ok") is False
    body = ['<div class="body">']
    if _mapping(record.get("arguments")):
        body.append("<h4>Input</h4>" + _pretty(record.get("arguments")))
    body.append("<h4>" + ("Error" if failed else "Output") + "</h4>"
                + _pretty(result.get("error") if failed else result.get("data")))
    if step["ops"]:
        body.append(_ran(step, trace))
    body.append("</div>")
    return (f'<details class="call{" err" if step["error"] else ""}" id="{_escape(step["id"])}">'
            f'<summary><div class="line1"><code class="fn">{_escape(name)}</code> '
            f'<span class="args mono">{_escape(arguments)}</span></div>'
            f'<div class="res">{_escape(_short(_outcome(record), 240))}</div></summary>'
            + "".join(body) + "</details>")


def _day_facts(day, analysis):
    budget, per_message = analysis["budget"], analysis["per_message"]
    used = day["exchanges"] * per_message
    calls = [step for step in day["steps"] if not step["harness"]]
    time = f"{used} of {budget} minutes" if budget else _plural(day["exchanges"], "message")
    accounts = _plural(len(day["accounts"]), "account") + (f' ({day["new"]} new)' if day["new"] else "")
    return used, calls, [time, accounts, _plural(day["offers"], "offer"), _plural(day["orders"], "order"),
                         _plural(len(calls), "tool call") + (f', {day["errors"]} failed' if day["errors"] else "")]


def _log(analysis, trace):
    buttons, sections = [], []
    for day in analysis["days"]:
        _, calls, facts = _day_facts(day, analysis)
        number = day["day"]
        error = " has-err" if day["errors"] else ""
        buttons.append(f'<button class="daybtn{error}" type="button" data-day="{number}" aria-pressed="false"'
                       f' title="Day {number}{" · has tool errors" if error else ""}">{number}</button>')
        content = "".join(_call_html(step, trace) for step in day["steps"])
        if not calls:
            content += '<p class="empty">No tool calls this day.</p>'
        content += "".join(f'<p class="ended"><b>Agent ended the day:</b> {_escape(text)}</p>' for text in day["said"][-1:])
        pricing = " · new prices from today" if day["new_pricing"] else ""
        sections.append(f'<section class="daylog{error}" id="day-{number}" data-day="{number}">'
                        f'<p class="daymeta">Day {number}{pricing} · {_escape(" · ".join(facts))}</p>{content}</section>')
    toggle = ('<label class="toggle"><input type="checkbox" id="errors-only"> Show only failed calls, all days</label>'
              if analysis["errors"] else "")
    if not analysis["days"]:
        sections.append('<p class="empty daylog">No actions were recorded.</p>')
    return (f'<section class="card log" id="log" data-panel="log" hidden><div class="loghead">'
            f'<div class="days"><span>Day</span>{"".join(buttons)}</div>{toggle}</div>{"".join(sections)}</section>')


def _state(account):
    if account["order"] is not None:
        return "bought"
    if account["decision"] == "opt_out":
        return "opted-out"
    if not account["exchanges"]:
        return "not-contacted"
    if account["decision"] == "decline":
        return "declined"
    return "talking"


def _offer_text(offer, products):
    product = products.get(offer.get("product_id")) or offer.get("product_id") or "?"
    return f'{product} at {_money(offer.get("monthly_price_cents"))}/mo'


def _account_line(account, products):
    state = _state(account)
    last = max(account["contact_days"]) if account["contact_days"] else None
    if state == "bought":
        text = f'Bought {_offer_text(account["order"], products)} on day {account["order_day"]}'
    elif state == "opted-out":
        text = f'Opted out on day {account["decision_day"]}'
    elif state == "declined":
        offer = f' {_offer_text(account["offers"][-1], products)}' if account["offers"] else ""
        text = f'Declined{offer} on day {account["decision_day"]}'
    elif state == "talking":
        text = f'{_plural(account["exchanges"], "message")}, last on day {last}'
        if account["offers"]:
            text += f' · offered {_offer_text(account["offers"][-1], products)}'
    else:
        text = "Never contacted"
    missed = [item["day"] for item in account["callbacks"] if item["status"] == "missed"]
    flag = (f' · <span class="flag">missed callback (day {", ".join(str(day) for day in missed)})</span>'
            if missed else "")
    return _escape(text) + flag


def _thread(account, products):
    words = {"kept": "kept", "missed": "missed", "pending": "still pending", "moved": "moved to a later day",
             "canceled": "no longer needed"}
    parts, shown_day = [], None
    for event in account["events"]:
        if event["day"] != shown_day:
            shown_day = event["day"]
            parts.append(f'<p class="dayrule">Day {_escape(shown_day)}</p>')
        if event["kind"] == "exchange":
            if event["offer"]:
                expires = event["offer"].get("expires_day")
                parts.append(f'<p class="event offer">Offer: {_escape(_offer_text(event["offer"], products))}'
                             + (f', valid through day {_escape(expires)}' if expires is not None else "") + '</p>')
            parts.append(f'<div class="bubble seller"><small>Agent</small>{_escape(event["message"] or "")}</div>')
            if event["reply"] is not None:
                parts.append(f'<div class="bubble customer"><small>Customer</small>{_escape(event["reply"])}</div>')
            decision = event["decision"]
            if event["order"]:
                parts.append('<p class="event good">Accepted: order placed</p>')
            elif decision == "decline":
                parts.append('<p class="event bad">Declined the offer</p>')
            elif decision == "opt_out":
                parts.append('<p class="event bad">Opted out: no more contact</p>')
            elif decision == "end_call":
                parts.append('<p class="event">Ended the conversation for today</p>')
        elif event["kind"] == "failed":
            parts.append(f'<div class="bubble failed"><small>Not sent: {_escape(event["error"])}</small>'
                         f'{_escape(event["message"] or "")}</div>')
        elif event["kind"] == "callback":
            item = event["callback"]
            style = " bad" if item["status"] == "missed" else ""
            parts.append(f'<p class="event{style}">Callback booked for day {_escape(item["day"])} '
                         f'({words.get(item["status"], item["status"])}): {_escape(item["reason"])}</p>')
        elif event["kind"] == "note":
            parts.append(f'<p class="event">Note saved: {_escape(event["text"])}</p>')
    return "".join(parts) or '<p class="empty">The agent never contacted this account.</p>'


def _accounts(analysis):
    products, accounts = analysis["products"], analysis["accounts"]
    counts = {state: sum(state in account["tags"] for account in accounts) for state, _ in STATES}
    missed = sum("missed-callback" in account["tags"] for account in accounts)
    chips = [f'<button class="chip" type="button" data-filter="all" aria-pressed="true">All {len(accounts)}</button>']
    chips += [f'<button class="chip" type="button" data-filter="{state}" aria-pressed="false">{label} {counts[state]}</button>'
              for state, label in STATES if counts[state]]
    if missed:
        chips.append(f'<button class="chip" type="button" data-filter="missed-callback" aria-pressed="false">'
                     f'Missed a callback {missed}</button>')
    labels = dict(STATES)
    rows, threads = [], []
    for account in accounts:
        state = _state(account)
        rows.append(f'<button class="acct" type="button" data-account="{_escape(account["id"])}" '
                    f'data-tags="{_escape(" ".join(account["tags"]))}" aria-selected="false">'
                    f'<i class="sw {state}"></i><span><span class="acct-name">{_escape(account["name"])}</span>'
                    f'<span class="acct-sub">{_account_line(account, products)}</span></span></button>')
        facts = [account["id"], _plural(account["exchanges"], "message"), _plural(len(account["offers"]), "offer")]
        threads.append(f'<article class="convo" id="account-{_escape(account["id"])}" hidden>'
                       f'<div class="convo-head"><div><h3>{_escape(account["name"])}</h3>'
                       f'<p class="meta">{_escape(" · ".join(facts))}</p></div>'
                       f'<span class="pill {state}">{labels[state]}</span></div>'
                       f'<div class="timeline">{_thread(account, products)}</div></article>')
    if not accounts:
        threads.append('<p class="empty convo">No accounts were recorded.</p>')
    return (f'<section class="card split" data-panel="accounts"><div class="list">'
            f'<div class="filters">{"".join(chips)}</div><div class="accts">{"".join(rows)}'
            f'<p class="empty" id="no-accounts" hidden>No accounts match.</p></div></div>'
            f'<div>{"".join(threads)}</div></section>')


def _outcome_bar(analysis):
    accounts = analysis["accounts"]
    total = len(accounts)
    counts = [(state, label, sum(_state(account) == state for account in accounts)) for state, label in STATES]
    parts = "".join(
        f'<button class="part {state}" type="button" style="flex:{count}" data-show="{state}" '
        f'data-tip="{label}: {count} of {total} accounts" aria-label="{label}: {count} of {total} accounts">'
        f'{count if count / max(total, 1) >= 0.06 else ""}</button>'
        for state, label, count in counts if count)
    legend = "".join(
        f'<li><button type="button" data-show="{state}"><i class="sw {state}"></i>{label} <b>{count}</b></button></li>'
        for state, label, count in counts if count)
    offers = sum(len(account["offers"]) for account in accounts)
    accepted = sum(account["order"] is not None for account in accounts)
    booked = sum(len(account["callbacks"]) for account in accounts)
    missed = sum(item["status"] == "missed" for account in accounts for item in account["callbacks"])
    stats = (f'<div><strong>{offers}</strong>offers presented</div>'
             f'<div><strong>{accepted}</strong>accepted</div>'
             f'<div><strong>{booked}</strong>callbacks booked</div>'
             f'<div><strong>{missed}</strong>callbacks missed</div>')
    return (f'<section class="card"><h2>Where the {_plural(total, "account")} ended up</h2>'
            '<p class="sub">Click a part to see those accounts.</p>'
            f'<div class="seg">{parts}</div><ul class="legend">{legend}</ul><div class="stats">{stats}</div></section>')


def _time_chart(analysis):
    days, budget, per_message = analysis["days"], analysis["budget"], analysis["per_message"]
    top = budget or max([day["exchanges"] for day in days] + [1])
    columns, labels = [], []
    for day in days:
        used, calls, facts = _day_facts(day, analysis)
        value = used if budget else day["exchanges"]
        height = 0 if not top else min(100, 100 * value / top)
        tip = f'Day {day["day"]}' + (" · new prices" if day["new_pricing"] else "") + "\n" + "\n".join(facts[:1] + [" · ".join(facts[1:4]), facts[4]])
        columns.append(f'<button class="col{" change" if day["new_pricing"] else ""}" type="button" '
                       f'data-day="{day["day"]}" data-tip="{_escape(tip)}" aria-label="{_escape(tip)}">'
                       f'<i style="height:{height:.1f}%"></i></button>')
        labels.append(f'<span>{day["day"]}</span>')
    axis = (f'<span style="bottom:100%">{top}</span><span style="bottom:50%">{top / 2:g}</span>'
            '<span style="bottom:0">0</span>')
    title = "Contact time used each day" if budget else "Messages sent each day"
    sub = (f"Minutes used out of {budget} a day; every message uses {per_message}. Click a day to see what the agent did."
           if budget else "Click a day to see what the agent did.")
    return (f'<section class="card"><h2>{title}</h2><p class="sub">{_escape(sub)}</p>'
            f'<div class="chart"><div class="yaxis">{axis}</div><div class="plot">'
            '<div class="gl" style="top:0"></div><div class="gl" style="top:50%"></div><div class="gl base" style="bottom:0"></div>'
            f'<div class="cols">{"".join(columns)}</div></div><div class="xaxis">{"".join(labels)}</div></div></section>')


def _summary(result, analysis, total_days):
    accounts = analysis["accounts"]
    total = len(accounts)
    bought = sum(_state(account) == "bought" for account in accounts)
    silent = sum(_state(account) == "not-contacted" for account in accounts)
    metrics = _mapping(result.get("metrics"))
    sentences = [f"Sold to <b>{bought} of {total}</b> accounts."]
    if silent:
        sentences.append(f'<button class="linkish" type="button" data-show="not-contacted"><b>{silent}</b> '
                         f'{"was" if silent == 1 else "were"} never contacted.</button>')
    if analysis["budget"] and analysis["days"]:
        days = total_days or len(analysis["days"])
        available = analysis["budget"] * days
        used = sum(day["exchanges"] for day in analysis["days"]) * analysis["per_message"]
        sentences.append(f"The agent used <b>{used} of {available}</b> contact minutes "
                         f"({round(100 * used / available) if available else 0}%).")
    booked = sum(len(account["callbacks"]) for account in accounts)
    missed = metrics.get("missed_callbacks")
    if not isinstance(missed, int):
        missed = sum(item["status"] == "missed" for account in accounts for item in account["callbacks"])
    if missed:
        sentences.append(f'<button class="linkish" type="button" data-show="missed-callback">It missed <b>{missed}</b> '
                         f'of the {_plural(booked, "callback")} it booked.</button>')
    if analysis["errors"]:
        sentences.append(f'<button class="linkish" type="button" data-errors="on">'
                         f'<b>{_plural(analysis["errors"], "tool call")}</b> failed.</button>')
    return f'<p class="summary">{" ".join(sentences)}</p>'


def _hero(result):
    metrics = _mapping(result.get("metrics"))
    profit = metrics.get("profit_cents")
    breakdown = ""
    if isinstance(profit, int):
        breakdown = (f'revenue {_money(metrics.get("retained_revenue_cents"))} − service '
                     f'{_money(metrics.get("service_cost_cents"))} − contact {_money(metrics.get("contact_cost_cents"))}')
        if metrics.get("refunded_revenue_cents"):
            breakdown += f' (refunds took {_money(metrics.get("refunded_revenue_cents"))})'
    if not isinstance(profit, int):
        return '<div class="hero"><span>Profit</span><strong>—</strong><small>not settled: the run did not finish</small></div>'
    return (f'<div class="hero"><span>Profit</span><strong>{_money(profit)}</strong>'
            + (f"<small>{_escape(breakdown)}</small>" if breakdown else "") + "</div>")


def _checks(checks, step_of_line, trace_count):
    # Completion is already in the header and the failure notice.
    shown = [_mapping(check) for check in checks if _mapping(check).get("name") != "campaign_completed"]
    if not shown:
        return ""
    marks = {"pass": ("pass", "✓ Pass"), "fail": ("fail", "✕ Fail"), "manual_review": ("review", "Review")}
    items = []
    for check in shown:
        style, mark = marks.get(check.get("status"), ("review", _label(check.get("status", "unknown"))))
        lines = [line for line in check.get("tool_lines", [])
                 if isinstance(line, int) and not isinstance(line, bool) and 1 <= line <= trace_count]
        targets = {}
        for line in lines:
            step = step_of_line.get(line)
            if step:
                targets.setdefault(step["id"], f'{step["record"].get("name", "call")}, day {step["day"]}')
            else:
                targets.setdefault(f"tool-{line}", f"action {line}")
        links = " · ".join(f'<a class="jump trace-link" href="#{_escape(target)}">{_escape(text)}</a>'
                           for target, text in targets.items())
        items.append(f'<li><span class="{style}">{mark}</span> <b>{_escape(_label(check.get("name", "Check")))}</b>: '
                     f'{_escape(check.get("explanation", ""))}' + (f" — {links}" if links else "") + "</li>")
    return f'<section class="card checks"><h2>Checks</h2><ul>{"".join(items)}</ul></section>'


def _failure(result, tool_failure=None):
    status = result.get("status", "unknown")
    if status == "completed" and not result.get("error") and not tool_failure:
        return ""
    reason = {"api_error": "because of an API error", "max_steps": "at the step limit",
              "interrupted": "because it was interrupted",
              "budget_exhausted": "at the spending limit"}.get(str(result.get("agent_stop_reason")))
    error = str(result.get("error") or "This run did not finish its campaign.")
    text = _short(error, 160)
    full = f'<details><summary>Full error</summary>{_pretty(error)}</details>' if len(error) > 160 else ""
    extra = ("<p>A tool request failed; it did not change the campaign.</p>" + _pretty(tool_failure)) if tool_failure else ""
    return (f'<aside class="banner"><b>This run {_escape(_label(status).lower())}'
            + (f" {reason}" if reason else "") + f'.</b> {_escape(text)}{full}{extra}</aside>')


def _warnings(messages):
    if not messages:
        return ""
    messages = list(dict.fromkeys(str(item) for item in messages))
    return ('<aside class="banner note"><b>Some saved files could not be read, so parts of this page may be missing.</b><ul>'
            + "".join(f"<li>{_escape(message)}</li>" for message in messages) + "</ul></aside>")


def _document(title, body, *, interactive=False, index=False):
    return (
        '<!doctype html><html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        f'<title>{_escape(title)}</title><style>{STYLE}</style></head><body class="{"index-page" if index else "run-page"}"><main>'
        + body + "</main>" + (f"<script>{INDEX_SCRIPT if index else SCRIPT}</script>" if interactive else "")
        + "</body></html>"
    )


def write_viewer(output: Path, evidence: dict):
    """Write one campaign's report; missing optional files leave the rest readable."""
    output = Path(output)
    result = _mapping(evidence.get("result"))
    case = _mapping(evidence.get("case"))
    trace = [_mapping(item) for item in evidence.get("trace") or []]
    warnings = list(evidence.get("warnings") or [])
    artifact_directory = output
    trace_path = evidence.get("trace_path", "tools.jsonl")
    safe_trace = _safe_path(trace_path)
    # Legacy practice output keeps the trace and history under runs/<attempt>/.
    if safe_trace and not (output / "seller_history.json").exists():
        candidate = (output / unquote(safe_trace)).parent
        if candidate.resolve().is_relative_to(output.resolve()):
            artifact_directory = candidate
    history = _read_artifact(artifact_directory, "seller_history.json", warnings)
    custom_trace, _ = _read_custom_trace(artifact_directory, warnings)
    analysis = _analyze({**evidence, "trace": trace}, custom_trace, history)
    title = str(case.get("id") or result.get("case_id") or "Campaign")
    repeat = result.get("repeat")
    heading = _label(title) + (f" · run {repeat}" if repeat not in (None, "") else "")
    config = _mapping(_mapping(_mapping(evidence.get("public_dataset")).get("scenario")).get("config"))
    total_days = _int(config.get("days"))
    last_day = analysis["days"][-1]["day"] if analysis["days"] else None
    facts = [_label(result.get("status") or "status unknown")]
    if last_day:
        facts.append(f"day {last_day}" + (f" of {total_days}" if total_days else ""))
    facts.append(_plural(len(analysis["accounts"]), "account"))
    if result.get("seller_model"):
        facts.append(str(result["seller_model"]))
    cost = result.get("seller_cost_usd")
    if isinstance(cost, (int, float)):
        facts.append(f"agent API cost ${cost:,.2f}")
    files = [_link((artifact_directory / name).relative_to(output).as_posix(), name)
             for name in ("transcript.md", "custom_tools.jsonl", "seller_history.json")
             if (artifact_directory / name).is_file()]
    files += [_link(trace_path, "tools.jsonl"), _link("evidence.json", "evidence.json")]
    calls = _plural(analysis["steps"], "tool call") + (f', {analysis["errors"]} failed' if analysis["errors"] else "")
    tabs = ('<nav class="tabs" id="views">'
            f'<button class="tab" type="button" data-view="accounts" aria-selected="true">Accounts '
            f'<small>{len(analysis["accounts"])}</small></button>'
            f'<button class="tab" type="button" data-view="log" aria-selected="false">Agent log '
            f'<small>{calls}</small></button></nav>')
    body = (
        f'<header class="top"><div><h1>{_escape(heading)}</h1><p class="meta">{_escape(" · ".join(facts))}</p></div>'
        + _hero(result) + '</header>'
        + _failure(result, evidence.get("tool_failure")) + _warnings(warnings)
        + _summary(result, analysis, total_days)
        + f'<div class="grid2">{_outcome_bar(analysis)}{_time_chart(analysis)}</div>'
        + _checks(evidence.get("checks") or [], analysis["step_of_line"], len(trace))
        + tabs + _accounts(analysis) + _log(analysis, trace)
        + '<footer>Saved logs in this folder: ' + " · ".join(files) + "</footer>"
        + '<div class="tip" id="tip" role="tooltip" hidden></div>'
    )
    (output / "inspect.html").write_text(_document(heading, body, interactive=True), encoding="utf-8")



# ----------------------------------------------------------------------------- index of runs

def _embedded_run(output, path):
    """Load only generated pages inside this output tree, including symlink checks."""
    safe = _safe_path(path)
    if not safe:
        return None
    candidate = output / unquote(safe)
    try:
        candidate.resolve().relative_to(output.resolve())
        source = candidate.read_text(encoding="utf-8")
    except (OSError, UnicodeError, ValueError):
        return None
    # A base URL keeps the run's file links working when it is embedded in its index.
    directory = PurePosixPath(safe).parent.as_posix()
    base = f'<base href="{_escape(directory)}/" target="_blank">'
    return source.replace('<head>', '<head>' + base, 1)


def write_index(output: Path, attempts: list[dict], *, title="Runs"):
    """One portable page: the runs on the left, the selected run's report on the right."""
    output = Path(output)
    completed = sum(_mapping(item.get("result")).get("status") == "completed" for item in attempts)
    groups = {}
    for index, attempt in enumerate(attempts):
        group, run = str(attempt.get("group") or ""), None
        # A ladder saves one folder per run (rung/run-2/...): list those runs under their rung.
        match = re.fullmatch(r"(.+)/(run-\d+)", group)
        if match:
            group, run = match.group(1), match.group(2).replace("-", " ")
        groups.setdefault(group, []).append((index, attempt, run))
    rows, documents = [], []
    for group, members in groups.items():
        profits = [_mapping(_mapping(attempt.get("result")).get("metrics")).get("profit_cents") for _, attempt, _ in members]
        profits = [value for value in profits if isinstance(value, (int, float)) and not isinstance(value, bool)]
        mean = f'<span class="mean">mean {_money(sum(profits) / len(profits))}</span>' if len(profits) > 1 else ""
        if group or mean:
            parent, _, leaf = group.rpartition("/")
            rows.append(f'<p class="group"><span>{f"<small>{_escape(parent)}</small>" if parent else ""}'
                        f'{_escape(leaf)}</span>{mean}</p>')
        for index, attempt, run in members:
            result = _mapping(attempt.get("result"))
            metrics = _mapping(result.get("metrics"))
            path = _safe_path(attempt.get("path"))
            name = str(attempt.get("name") or result.get("case_id") or f"Run {index + 1}")
            case_id = result.get("case_id")
            if case_id and (name == case_id or name.startswith(f"{case_id}__")):
                name = _label(case_id) + (f' · {run}' if run else
                                          f' · run {result["repeat"]}' if result.get("repeat") is not None else '')
            label = f"{group} · {name}" if group else name
            source = _embedded_run(output, attempt.get("path"))
            if source is None:
                source = _document(name, '<h1>Viewer unavailable</h1><p class="meta">The saved run page could not be read. '
                                         'Run the same command again to rebuild it: an unchanged run replays for free.</p>')
            documents.append(f'<template class="run-page" id="run-document-{index}"><textarea>{_escape(source)}</textarea></template>')
            stop = result.get("agent_stop_reason")
            reason = {"api_error": "API error", "max_steps": "Step limit reached",
                      "interrupted": "Interrupted", "budget_exhausted": "Budget reached"}.get(str(stop))
            failed = result.get("status") != "completed"
            warning = ((reason or _label(str(stop or result.get("status") or "unknown")))[:100]) if failed else ""
            profit = metrics.get("profit_cents")
            rows.append(
                '<article class="attempt-row">'
                f'<button class="run-select" type="button" data-document="run-document-{index}" '
                f'data-label="{_escape(label)}" data-path="{_escape(path or "")}" aria-pressed="false">'
                f'<span class="run-name">{_escape(name)}</span>'
                f'<span class="run-outcome">{_money(profit) if isinstance(profit, (int, float)) else "—"}</span></button>'
                + (f'<p class="run-error">Failed: {_escape(warning)}</p>' if warning else '')
                + (f'<a class="run-file" href="{_escape(path)}" target="_blank" rel="noopener">Open run file</a>' if path else '')
                + '</article>'
            )
    body = (
        f'<header class="ix-top"><h1>{_escape(title)}</h1>'
        f'<p class="meta">{_plural(len(attempts), "run")} · {completed} completed</p></header>'
        '<div class="run-layout"><nav class="run-sidebar" aria-label="Runs">' + ''.join(rows)
        + ('<p class="empty">No recorded runs.</p>' if not attempts else '')
        + '</nav><section class="run-content" aria-label="Selected run">'
        '<div class="run-toolbar"><span id="selected-run">Select a run</span>'
        '<a id="open-run" href="#" target="_blank" rel="noopener" hidden>Open in its own tab</a></div>'
        '<iframe class="run-frame" id="run-frame" title="Selected run" sandbox="allow-scripts allow-downloads allow-popups"></iframe>'
        '</section></div>' + ''.join(documents)
        + '<noscript><p class="empty">Open each run folder\'s inspect.html directly.</p></noscript>'
    )
    (output / "inspect.html").write_text(_document(title, body, interactive=True, index=True), encoding="utf-8")
