"""Everything run_agent (agent.py) works with, in one file.

    tool      turns a typed, documented function into a tool the model can call
    Toolbox   runs the model's tool calls; every failure comes back to the model as text
    Ctx       what a tool can use: the business operations and ctx.state
    World     the campaign as the agent sees it: the calendar, the daily note, the score
    instructions  the developer message: SYSTEM_PROMPT, exactly as the student wrote it
    Model     one model call per turn, with a call budget
    Seller    runs run_agent for the local runner and the staff evaluator

Students edit prompt.py and tools.py and read agent.py; this file is optional reading.
Business rules live in environment.py and are enforced underneath everything here.
"""

import inspect
import json
import types
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal, Union, get_args, get_origin, get_type_hints

from .agent import run_agent
from .api_client import ensure_instrumented
from .errors import ToolError
from .execution import BillingUncertain, BudgetExceeded

MAX_TURNS_PER_DAY = 100
REASONING_EFFORTS = ("none", "low", "medium", "high", "xhigh")


class EnvironmentFailure(Exception):
    """The simulator or the environment failed: not the model's fault, not the tool's. The run stops."""


# Raised through a tool call: the run cannot continue spending, but the campaign can still settle.
SPENDING_STOPS = (BudgetExceeded, BillingUncertain)


# --------------------------------------------------------------------------- tools

_JSON = {str: "string", int: "integer", float: "number", bool: "boolean", type(None): "null"}


def _schema(annotation):
    if annotation in _JSON:
        return {"type": _JSON[annotation]}
    origin, args = get_origin(annotation), get_args(annotation)
    if origin is list and len(args) == 1:
        return {"type": "array", "items": _schema(args[0])}
    if origin is Literal and args:
        if len({type(arg) for arg in args}) != 1 or type(args[0]) not in _JSON:
            raise TypeError("Literal choices must share one basic type.")
        return {"type": _JSON[type(args[0])], "enum": list(args)}
    if origin in (Union, types.UnionType):
        return {"anyOf": [_schema(arg) for arg in args]}
    raise TypeError(f"Unsupported argument type {annotation!r}. "
                    "Use str, int, float, bool, list[...], Literal[...] or X | None.")


def tool(function):
    """Make a function callable by the model.

    The function's name, docstring and typed arguments are exactly what the model
    sees. The first argument is ctx (given by the harness); the model supplies the
    others, and must supply all of them.
    """
    if not inspect.isfunction(function) or inspect.iscoroutinefunction(function):
        raise TypeError("@tool needs an ordinary function.")
    if is_tool(function):            # decorating again: leave the original (maybe a supplied tool) untouched
        function = _copy(function)
    names = list(inspect.signature(function).parameters)
    if not names or names[0] != "ctx":
        raise TypeError(f"{function.__name__}: the first argument must be ctx.")
    if not inspect.getdoc(function):
        raise ValueError(f"{function.__name__}: write a docstring telling the model when to use it.")
    for parameter in list(inspect.signature(function).parameters.values())[1:]:
        if parameter.kind not in (parameter.POSITIONAL_OR_KEYWORD, parameter.KEYWORD_ONLY):
            raise TypeError(f"{function.__name__}: tool arguments cannot be *args or **kwargs.")
    hints = get_type_hints(function)
    missing = [name for name in names[1:] if name not in hints]
    if missing:
        raise TypeError(f"{function.__name__}: give these arguments a type: {', '.join(missing)}.")
    properties = {name: _schema(hints[name]) for name in names[1:]}
    function.tool_schema = {
        "type": "function",
        "name": function.__name__,
        "description": inspect.getdoc(function),
        "strict": True,
        "parameters": {"type": "object", "properties": properties,
                       "required": list(properties), "additionalProperties": False},
    }
    return function


def is_tool(value):
    return inspect.isfunction(value) and isinstance(getattr(value, "tool_schema", None), dict)


def _copy(function):
    duplicate = types.FunctionType(function.__code__, function.__globals__, function.__name__,
                                   function.__defaults__, function.__closure__)
    duplicate.__doc__, duplicate.__qualname__ = function.__doc__, function.__qualname__
    duplicate.__module__, duplicate.__kwdefaults__ = function.__module__, function.__kwdefaults__
    duplicate.__annotations__ = dict(function.__annotations__)
    return duplicate


def _matches(value, schema):
    if "anyOf" in schema:
        return any(_matches(value, option) for option in schema["anyOf"])
    kind = schema["type"]
    ok = {"string": isinstance(value, str),
          "integer": type(value) is int,
          "number": type(value) in (int, float),
          "boolean": type(value) is bool,
          "null": value is None,
          "array": isinstance(value, list)}[kind]
    if ok and kind == "array":
        ok = all(_matches(item, schema["items"]) for item in value)
    return ok and value in schema.get("enum", [value])


def _plain_json(value, what):
    """Return value as JSON text, refusing anything that would not come back unchanged."""
    text = json.dumps(value, ensure_ascii=False, allow_nan=False)
    if json.loads(text) != value:
        raise TypeError(f"{what} must hold plain JSON values: string keys, lists rather than tuples.")
    return text


class Toolbox:
    """The tools the model may call, and the code that runs them."""

    def __init__(self, functions, *, on_record=None):
        self.functions = {}
        for function in functions:
            if not is_tool(function):
                raise TypeError(f"{function!r} is not decorated with @tool.")
            if function.__name__ in self.functions:
                raise ValueError(f"Two tools are named {function.__name__}.")
            self.functions[function.__name__] = function
        if not self.functions:
            raise ValueError("The toolbox is empty: define at least one @tool.")
        self.on_record = on_record

    def schemas(self):
        return [function.tool_schema for function in self.functions.values()]

    def run(self, name, arguments, world, call_id=None):
        """Run one tool call and return the JSON text the model will read next.

        If the call fails, ctx.state goes back to what it was. Business operations
        the tool had already performed stay done: they are real, they are in the
        trace, and the error tells the model about them.
        """
        call_id = call_id or f"tool:{sum(e['kind'] == 'tool' for e in world.events) + 1}"
        event = world.record("tool", name=name, arguments=arguments, call_id=call_id, operations=[])
        ctx, function, error = Ctx(world, call_id, event["operations"]), self.functions.get(name), None
        state_before = json.dumps(world.state)
        try:
            if function is None:
                raise ToolError("unknown_tool", f"There is no tool named {name!r}.")
            try:
                arguments = event["arguments"] = json.loads(arguments or "{}")
            except (TypeError, json.JSONDecodeError):
                raise ToolError("invalid_arguments", "Arguments must be a JSON object.") from None
            expected = function.tool_schema["parameters"]["properties"]
            if not isinstance(arguments, dict) or set(arguments) != set(expected):
                raise ToolError("invalid_arguments", f"{name} takes exactly: {', '.join(expected) or 'no arguments'}.")
            for key, schema in expected.items():
                if not _matches(arguments[key], schema):
                    raise ToolError("invalid_arguments", f"{key!r} does not match its declared type.")
            output = json.dumps(function(ctx, **arguments), ensure_ascii=False, allow_nan=False)
            _plain_json(world.state, "ctx.state")
        except (EnvironmentFailure, *SPENDING_STOPS) as stop:   # not a tool problem: the run stops here
            event.update(output=None, error="run_stopped")
            self._record(event, {"ok": False, "error": {"code": "run_stopped", "message": str(stop)}})
            raise
        except ToolError as refusal:                    # a rule said no: the model can act on it
            error = {"code": refusal.code, "message": str(refusal)}
        except Exception as bug:                        # a bug in the tool: report it, keep going
            error = {"code": "tool_crashed", "message": _describe(bug, function)}
        if error:
            world.state.clear()
            world.state.update(json.loads(state_before))
            done = [{"operation": op["name"], "id": op["result"]["data"].get("id")}
                    for op in event["operations"] if op["name"] in World.CHANGES and op["result"]["ok"]
                    and isinstance(op["result"]["data"], dict)]
            if done:                                    # so the model does not repeat them
                error["done_before_error"] = done
            if ctx.contact is not None:                 # never hide a customer's reply
                error["customer_reply"] = ctx.contact
            output = json.dumps({"error": error}, ensure_ascii=False)
        event.update(output=output, error=error and error["code"])
        self._record(event, {"ok": False, "error": error} if error else {"ok": True, "data": json.loads(output)})
        return output

    def _record(self, event, result):
        if self.on_record is not None:
            self.on_record({"name": event["name"], "arguments": event["arguments"], "request_id": event["call_id"],
                            "result": result, "replayed": False,
                            "business_request_ids": [op["request_id"] for op in event["operations"]]})


def _describe(error, function):
    """Name the exception and the line of the tool's own file where it happened."""
    source = function.__code__.co_filename if function else None
    lines = [frame.lineno for frame in inspect.trace() if frame.filename == source]
    where = f" ({Path(source).name} line {lines[-1]})" if lines else ""
    return f"{type(error).__name__}: {error}{where}"


class Ctx:
    """What a tool may use: the business operations and ctx.state.

    ctx.read_customer(customer_id="acorn")   returns the data, or raises the business error
    ctx.call("read_customer", customer_id=…) returns {"ok": True, "data": …} or {"ok": False, "error": …}
    ctx.state                                a dict that lives for the whole run (plain JSON values)

    After a tool talks to a customer it must return, so the model reads the reply
    before anything else happens. Breaking that rule, calling an operation that does
    not exist, or passing it arguments of the wrong type are bugs in the tool: they
    count as crashes, and the model is told what happened.
    """

    def __init__(self, world, call_id="tool", log=None):
        self._world, self._call_id = world, call_id
        self._log = log if log is not None else []
        self.contact = None

    @property
    def state(self):
        return self._world.state

    @state.setter
    def state(self, value):
        if not isinstance(value, dict):
            raise TypeError("ctx.state must be a dict.")
        value = dict(value)              # it may be the same dict: copy before clearing
        self._world.state.clear()
        self._world.state.update(value)

    def call(self, name, **arguments):
        if self.contact is not None:
            raise RuntimeError(f"ctx.{name} after contacting a customer: a tool must return the reply first.")
        if name not in World.OPERATIONS:
            raise ValueError(f"{name!r} is not a business operation; see World.OPERATIONS.")
        try:                            # the same rule locally and on the staff service
            plain = json.loads(json.dumps(arguments, allow_nan=False)) == arguments
        except (TypeError, ValueError) as error:
            raise TypeError(f"ctx.{name} arguments must be plain JSON values: {error}") from None
        if not plain:
            raise TypeError(f"ctx.{name} arguments must be plain JSON values: lists, not tuples; string keys.")
        request_id = f"{self._call_id}:{len(self._log) + 1}"
        try:
            receipt = self._world.call(name, arguments, request_id)
        except SPENDING_STOPS:
            raise
        except Exception as failure:
            raise EnvironmentFailure(f"{name} failed inside the environment: {failure}") from failure
        self._log.append({"name": name, "arguments": arguments, "request_id": request_id, "result": receipt})
        if not receipt["ok"] and receipt["error"]["code"] == "invalid_arguments":
            raise TypeError(f"ctx.{name}: {receipt['error']['message']}")   # the tool's bug, not the model's
        if name in World.CONTACTS and receipt["ok"] and "reply" in receipt["data"]:
            self.contact = receipt["data"]
        return receipt

    def __getattr__(self, name):
        if name.startswith("_") or name not in World.OPERATIONS:
            raise AttributeError(f"ctx has no operation {name!r}; see World.OPERATIONS.")

        def operation(**arguments):
            receipt = self.call(name, **arguments)
            if not receipt["ok"]:
                raise ToolError(receipt["error"]["code"], receipt["error"]["message"])
            return receipt["data"]
        return operation


# --------------------------------------------------------------------------- world

class World:
    """The campaign as the agent sees it, through the business operations.

    It works the same over the local environment and the staff service: the client
    is anything with call(name, arguments, request_id=...). The harness's own calls
    (the daily note, the calendar) carry request IDs that start with "harness:".
    """

    # Every business operation except advance_day: the harness owns the calendar.
    OPERATIONS = ("get_status", "list_customers", "read_customer", "read_customer_history",
                  "search_customer_history", "read_record", "get_catalog", "list_documents",
                  "read_document", "talk_to_customer", "save_note", "create_quote",
                  "present_quote", "schedule_callback")
    CONTACTS = ("talk_to_customer", "present_quote")
    CHANGES = ("talk_to_customer", "save_note", "create_quote", "present_quote", "schedule_callback")

    def __init__(self, client):
        self.client = client
        self.state = {}            # ctx.state for the tools of this run
        self.events = []           # tool calls and day ends, in order
        self.cut_off = False
        self._reads = 0
        self.status = self._read("get_status")

    @property
    def finished(self):
        return self.status["finished"]

    @property
    def day(self):
        return self.status["day"]

    def call(self, name, arguments, request_id=None):
        return self.client.call(name, arguments, request_id=request_id)

    def _read(self, name):
        self._reads += 1
        try:
            receipt = self.call(name, {}, f"harness:{name}:{self._reads}")
        except SPENDING_STOPS:
            raise
        except Exception as failure:
            raise EnvironmentFailure(f"{name} failed inside the environment: {failure}") from failure
        if not receipt["ok"]:
            raise EnvironmentFailure(f"{name} was refused: {receipt['error']}")
        return receipt["data"]

    def record(self, kind, **details):
        event = {"kind": kind, "day": self.day, **details}
        self.events.append(event)
        return event

    def end_day(self, note="", cut_off=False):
        self.record("end_of_day", note=note, cut_off=cut_off)
        self.cut_off = cut_off
        self.status = self._read("advance_day")

    def outcome(self):
        return self.status.get("outcome")

    def morning_note(self):
        """The user message that opens each day: the calendar facts, not instructions."""
        status = self.status
        note = (f"Day {status['day']} of {status['campaign_days']} ({status['date']}). "
                f"You have {status['minutes_remaining_today']} contact minutes today; each message to a "
                f"customer uses {status['minutes_per_exchange']} minutes and costs "
                f"${status['cost_per_exchange_cents'] / 100:.2f}. "
                "Reply without calling a tool when you are done for the day.")
        if self.cut_off:
            note = "Your previous day ended because it reached the turn limit. " + note
        return note


def instructions(world, prompt):
    """The developer message run_agent receives: SYSTEM_PROMPT and nothing else.

    The student writes the whole prompt, including what the task is and how it is
    scored. The harness adds only the daily note (morning_note), a user message
    with the day, the contact time left and what a message costs.
    """
    return prompt


# --------------------------------------------------------------------------- model

@dataclass
class ToolCall:
    id: str
    name: str
    arguments: str


@dataclass
class Reply:
    items: list                      # everything the model produced this turn; it stays in the conversation
    tool_calls: list                 # the tools it asked for, in order
    text: str = ""                   # its message, if it wrote one
    usage: dict = field(default_factory=dict)


class Model:
    """One Responses API call per turn.

    When a call limit or the execution budget is reached the model falls silent:
    each remaining day ends at once and the campaign still settles.
    """

    def __init__(self, client, name, *, max_calls=600, reasoning_effort=None):
        if reasoning_effort is not None and reasoning_effort not in REASONING_EFFORTS:
            raise ValueError(f"reasoning_effort must be one of {', '.join(REASONING_EFFORTS)}.")
        self.client, self.name, self.max_calls = client, name, max_calls
        self.reasoning_effort = reasoning_effort    # None: the model's own default
        self.usage = []                # one row per call: what the context window costs
        self.stopped = None            # why the model fell silent, if it did
        self.billing_uncertain = False
        self.cut_short = 0             # replies that ran out of output tokens (each ends that day)
        self.last_input = []           # the conversation as of the latest call

    def __call__(self, messages, tools):
        self.last_input = messages
        if not self.stopped and len(self.usage) >= self.max_calls:
            self.stopped = f"step limit: {self.max_calls} model calls"
        if self.stopped:
            return Reply([], [])
        try:
            settings = {"reasoning": {"effort": self.reasoning_effort}} if self.reasoning_effort else {}
            response = self.client.responses.create(
                model=self.name, input=list(messages), tools=tools, parallel_tool_calls=False,
                store=False, include=["reasoning.encrypted_content"], truncation="disabled", **settings)
        except SPENDING_STOPS as stop:
            self.stopped = f"{type(stop).__name__}: {stop}"
            self.billing_uncertain = isinstance(stop, BillingUncertain)
            return Reply([], [])
        usage = getattr(response, "usage", None)
        details = getattr(usage, "input_tokens_details", None)
        self.usage.append({"input_tokens": getattr(usage, "input_tokens", None),
                           "cached_input_tokens": getattr(details, "cached_tokens", None),
                           "output_tokens": getattr(usage, "output_tokens", None)})
        reason = getattr(getattr(response, "incomplete_details", None), "reason", None)
        if response.status == "incomplete" and reason == "max_output_tokens":
            self.cut_short += 1        # a long reasoning step was cut off: end the day, keep the run
            return Reply([], [], "", self.usage[-1])
        if response.status != "completed":
            raise RuntimeError(f"Model response {response.status}: {response.incomplete_details or response.error}")
        items = [item.model_dump(exclude_none=True) for item in response.output]
        calls = [ToolCall(item["call_id"], item["name"], item["arguments"])
                 for item in items if item.get("type") == "function_call"]
        if not calls and not any(item.get("type") == "message" for item in items):
            items = []                 # reasoning with nothing after it is not sent back
        return Reply(items, calls, response.output_text or "", self.usage[-1])


# --------------------------------------------------------------------------- seller

class Seller:
    """Run run_agent for the local runner and the staff evaluator.

    Both call run(max_steps) and read history, tool_state and usage afterwards.
    max_steps caps model calls; beyond it the model falls silent and the campaign
    still settles.
    """

    def __init__(self, tools, llm, *, model, prompt, toolbox, max_turns_per_day=MAX_TURNS_PER_DAY,
                 reasoning_effort=None):
        if not isinstance(model, str) or not model.strip():
            raise ValueError("Pass an explicit OpenAI model name.")
        if not isinstance(prompt, str) or not prompt.strip():
            raise ValueError("SYSTEM_PROMPT must be a nonempty string.")
        if type(max_turns_per_day) is not int or max_turns_per_day < 1:
            raise ValueError("max_turns_per_day must be a positive integer.")
        self.tools, self.prompt, self.toolbox = tools, prompt, toolbox
        self.llm = ensure_instrumented(llm, role="seller")
        self.model = Model(self.llm, model, reasoning_effort=reasoning_effort)
        self.max_turns_per_day = max_turns_per_day
        self.world, self.history, self.result = None, [], None

    @property
    def usage(self):
        return self.llm.usage

    @property
    def tool_state(self):
        return self.world.state if self.world else {}

    def run(self, max_steps):
        if type(max_steps) is not int or max_steps < 1:
            raise ValueError("max_steps must be a positive integer.")
        if self.result is not None:
            return self.result
        self.model.max_calls = max_steps
        status, error = None, None
        try:
            self.world = World(self.tools)
            prompt = instructions(self.world, self.prompt)
            _, self.history = run_agent(self.model, prompt, self.toolbox, self.world, self.max_turns_per_day)
        except SPENDING_STOPS as stop:             # a customer call could not be afforded
            self.model.stopped = self.model.stopped or f"{type(stop).__name__}: {stop}"
            self.model.billing_uncertain |= isinstance(stop, BillingUncertain)
            self._finish_calendar()
        except EnvironmentFailure as failure:
            status, error = "tool_error", str(failure)
        except Exception as failure:  # noqa: BLE001 -- API boundary: keep the evidence, settle if possible
            status, error = "api_error", f"{type(failure).__name__}: {failure}"
            self._finish_calendar()
        if not self.history:
            self.history = self.model.last_input
        if status is None:
            status = ("billing_uncertain" if self.model.billing_uncertain
                      else "budget_spent" if self.model.stopped else "settled")
            error = self.model.stopped if self.model.billing_uncertain else None
        notes = [event.get("note", "") for event in (self.world.events if self.world else [])
                 if event["kind"] == "end_of_day"]
        self.result = {"status": status, "summary": next((n for n in reversed(notes) if n), ""),
                       "steps": len(self.model.usage), "error": error,
                       "model_stopped": self.model.stopped,
                       "replies_cut_short": getattr(self.model, "cut_short", 0),
                       "days_cut_off": sum(1 for e in (self.world.events if self.world else [])
                                           if e.get("cut_off"))}
        return self.result

    def _finish_calendar(self):
        """Advance the remaining days without the model, so the campaign settles."""
        if self.world is None:
            return
        try:
            while not self.world.finished:
                self.world.end_day(f"(the model stopped: {self.model.stopped or 'run error'})")
        except Exception:  # noqa: BLE001 -- the run already failed; keep its first error
            pass
