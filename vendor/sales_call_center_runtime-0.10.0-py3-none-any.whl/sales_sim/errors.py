"""Errors an agent can act on, separate from simulator or API failures."""


class ToolError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
