"""Which cases to run: suite files, their customer factories, and seller entry points."""

import importlib
import importlib.util
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .crm import load_dataset

# The campaign of the required three-way comparison, relative to the starter folder.
FORMAL_SUITE = "development/full_campaign/suite.json"


@dataclass(frozen=True)
class EvaluationCase:
    id: str
    dataset_path: Path
    customer_factory: str
    customer_config_path: Path
    customer_model: str | None = None


def _identifier(value: Any) -> str:
    if (
        not isinstance(value, str)
        or re.fullmatch(r"[a-z0-9][a-z0-9_-]*", value) is None
    ):
        raise ValueError(
            "Evaluation IDs must use lowercase letters, digits, underscores, or hyphens."
        )
    if "__" in value:
        raise ValueError("Double underscores are reserved for evaluation run names.")
    return value


def load_suite(
    path: Path, *, customer_model: str | None = None, case_ids: list[str] | None = None
) -> list[EvaluationCase]:
    path = Path(path).resolve()
    manifest = json.loads(path.read_text(encoding="utf-8"))
    if (
        not isinstance(manifest, dict)
        or type(manifest.get("schema_version")) is not int
        or manifest["schema_version"] != 1
    ):
        raise ValueError("Only evaluation suite version 1 is supported.")
    if set(manifest) - {"schema_version", "description", "cases"}:
        raise ValueError("Unknown evaluation suite fields.")
    if not isinstance(manifest.get("cases"), list) or not manifest["cases"]:
        raise ValueError("An evaluation suite needs at least one case.")
    available = [
        _identifier(item.get("id")) if isinstance(item, dict) else _identifier(None)
        for item in manifest["cases"]
    ]
    if len(set(available)) != len(available):
        raise ValueError("Evaluation case IDs must be unique.")
    selected = set(available)
    if case_ids is not None:
        if not isinstance(case_ids, list) or not case_ids:
            raise ValueError("Case selection must be a nonempty list of IDs.")
        selected = {_identifier(case_id) for case_id in case_ids}
        if len(selected) != len(case_ids):
            raise ValueError("Selected case IDs must be unique.")
        missing = selected - set(available)
        if missing:
            raise ValueError(
                f"Unknown selected case IDs: {', '.join(sorted(missing))}."
            )
    cases = []
    for item in manifest["cases"]:
        required = {"id", "dataset", "customer_factory", "customer_config"}
        if (
            not isinstance(item, dict)
            or not required <= set(item)
            or set(item) - required - {"customer_model"}
        ):
            raise ValueError("Invalid evaluation case fields.")
        if any(
            not isinstance(item[name], str) or not item[name].strip()
            for name in required
        ):
            raise ValueError("Evaluation case fields must be nonempty strings.")
        if item["id"] not in selected:
            continue
        model = (
            customer_model if customer_model is not None else item.get("customer_model")
        )
        if model is not None and (not isinstance(model, str) or not model.strip()):
            raise ValueError("Customer model must be a nonempty string when supplied.")
        dataset_path = (path.parent / item["dataset"]).resolve()
        customer_path = (path.parent / item["customer_config"]).resolve()
        factory = item["customer_factory"]
        module, separator, name = factory.rpartition(":")
        if not separator or not module or not name.isidentifier():
            raise ValueError("Invalid customer factory.")
        if module.endswith(".py"):
            module = str((path.parent / module).resolve())
            if not Path(module).is_file():
                raise ValueError("Customer factory file does not exist.")
            factory = f"{module}:{name}"
        load_dataset(dataset_path)
        if not isinstance(json.loads(customer_path.read_text(encoding="utf-8")), dict):
            raise ValueError("Customer configuration must be a JSON object.")  # noqa: TRY004 -- suite validation errors share one public exception
        cases.append(
            EvaluationCase(
                _identifier(item["id"]), dataset_path, factory, customer_path, model
            )
        )
    if len({case.id for case in cases}) != len(cases):
        raise ValueError("Evaluation case IDs must be unique.")
    return cases


def load_agent(entrypoint: str):
    """Load a trusted local submission from module:factory or file.py:factory."""
    module_name, separator, attribute = entrypoint.rpartition(":")
    if not separator or not module_name or not attribute.isidentifier():
        raise ValueError("Agent entrypoint must be module:factory or file.py:factory.")
    if module_name.endswith(".py"):
        path = Path(module_name).resolve()
        # Match running a Python script: explicitly packaged neighboring helpers
        # remain importable during both module loading and the later agent run.
        if str(path.parent) not in sys.path:
            sys.path.insert(0, str(path.parent))
        specification = importlib.util.spec_from_file_location(
            "submitted_sales_agent", path
        )
        if specification is None or specification.loader is None:
            raise ValueError("Could not load the seller module.")
        module = importlib.util.module_from_spec(specification)
        # Dataclass declarations consult their module while classes are created.
        sys.modules[specification.name] = module
        specification.loader.exec_module(module)
    else:
        module = importlib.import_module(module_name)
    factory = getattr(module, attribute)
    if not callable(factory):
        raise TypeError("Seller entrypoint must be callable.")
    return factory
