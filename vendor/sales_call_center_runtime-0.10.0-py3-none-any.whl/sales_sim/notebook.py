"""Notebook helpers: read a case, see what the model reads, try tools, run a case.

The notebook is a driver, not another place to build the agent. Tool checks run
your saved tools.py exactly as a run does (the same Toolbox and World) on a fresh
copy of a campaign, with no model and no API key: a practice case, whose scripted
customer answers for free, or the 40-account campaign ("full_campaign"), where
reading is free and a message to a customer stops with an error, because its
customers are simulated by a paid model. Paid runs use the ordinary local runner
and save the same files as `python run.py run`.
"""

import json
import os
from contextlib import redirect_stdout
from html import escape
from io import StringIO
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import quote

from . import baseline, local
from .crm import load_dataset
from .errors import ToolError
from .environment import SalesEnvironment
from .harness import Toolbox, World
from .practice import build_customers, case_catalog
from .student_setup import course_settings, model_input, model_settings
from .student_submission import load_tools
from .suites import FORMAL_SUITE, load_suite
from .tools import LocalToolClient

PRACTICE_SUITE = "practice/suite.json"
CAMPAIGN = "full_campaign"           # the 40-account campaign: free to read, paid to talk to


class _NoMessages:
    """The 40-account campaign's customers, offline: they cannot be messaged here."""

    def respond(self, turn):
        raise ToolError("paid_customer", "Customers of the 40-account campaign are simulated by a paid "
                                         "model. Try messages and quotes on a practice case instead.")

    def settle(self, order):
        raise ToolError("paid_customer", "No order can exist in an offline copy of the 40-account campaign.")


def list_cases(root="."):
    """The five practice cases, without their customers' private settings."""
    return [{"id": item["id"], "description": item["description"]}
            for item in case_catalog(Path(root).resolve() / "practice")]


def _case(case, root):
    if case == CAMPAIGN:
        return load_suite(root / FORMAL_SUITE, case_ids=[case])[0]
    selected = load_suite(root / PRACTICE_SUITE, case_ids=[case])[0]
    if selected.customer_factory != "sales_sim.practice:build_customers" or selected.customer_model:
        raise ValueError("Tool checks need a supplied practice case or the 40-account campaign.")
    return selected


def show_case(case="requirements_update", root=".", *, display=False):
    """Return the brief and the public company records; no private simulator data."""
    root = Path(root).resolve()
    selected = _case(case, root)
    brief = next(item for item in list_cases(root) if item["id"] == case)
    result = {"case": brief, "public_dataset": load_dataset(selected.dataset_path).to_dict()}
    if display:
        dataset = result["public_dataset"]
        records = [*dataset["crm"].get("profiles", []), *dataset["crm"].get("records", [])]
        evidence = "".join(_details(
            f'{record.get("date", "")} · {record.get("kind", "Record")} · {record.get("id", "")}',
            _value_html(record.get("data", {})) + f'<p class="muted">{_text(record.get("source", ""))}</p>',
            opened=record.get("kind") != "profile") for record in records)
        content = (f'<h3>{_text(brief["id"])}</h3><p>{_text(brief["description"])}</p>' + evidence
                   + _details("Products and company policy", _value_html(dataset["scenario"])))
        if not _display_html(_card(content)):
            print(f'{brief["id"]}: {brief["description"]}')
            for record in dataset["crm"].get("records", []):
                print(f'  {record.get("date", "")} · {record.get("id", "")}')
    return result


# --------------------------------------------------------------------------- what the model reads

def _approx_tokens(text):
    return max(1, len(text) // 4)          # a rough rule of thumb: about four characters per token


def show_prompt(case=None, root=".", *, variant="tools", display=True):
    """Everything the model reads before its first turn, and what it costs.

    The developer message is your SYSTEM_PROMPT, exactly as written; then comes
    the first morning note. The tool definitions
    are sent with every model call. case picks a practice case; by default this
    shows the formal campaign. Offline: no API key, no customer.
    """
    root = Path(root).resolve()
    result = model_input(root, variant=variant, case=case)
    schemas = json.dumps(result["tools"], ensure_ascii=False)
    result["approx_tokens"] = {"developer": _approx_tokens(result["developer"]),
                               "user": _approx_tokens(result["user"]), "tools": _approx_tokens(schemas)}
    if display:
        sizes = result["approx_tokens"]
        tools = "".join(
            f'<div class="item"><strong>{_text(item["name"])}</strong>'
            f'({_text(", ".join(item["parameters"]["properties"]))})'
            f'<p>{_text(item["description"])}</p></div>' for item in result["tools"])
        content = (f'<h3>What the model reads · {_text(result["case_id"])} · {_text(variant)}</h3>'
                   f'<p class="muted">About {sum(sizes.values()):,} tokens before the first reply '
                   f'(rough estimate: characters ÷ 4). The {len(result["tools"])} tool definitions, '
                   f'about {sizes["tools"]:,} tokens, are sent again with every model call.</p>'
                   f'<h4>Developer message (about {sizes["developer"]:,} tokens)</h4><pre>{_text(result["developer"])}</pre>'
                   f'<h4>First user message</h4><pre>{_text(result["user"])}</pre>'
                   + _details(f'Tools ({len(result["tools"])})', tools, opened=True))
        if not _display_html(_card(content)):
            print(result["developer"], "\n\n---\n", result["user"], "\n\n--- tools:",
                  ", ".join(item["name"] for item in result["tools"]))
    return result


# --------------------------------------------------------------------------- tool checks

def _calls(calls):
    """Accept (name, arguments) pairs, {"name", "arguments"} dicts, or "end_day"; check all first."""
    if not isinstance(calls, (list, tuple)) or not calls:
        raise ValueError("Pass a nonempty list of calls, such as [('read_customer', {'customer_id': 'nimbus'})].")
    checked = []
    for call in calls:
        if call == "end_day":
            call = ("end_day", {})
        if isinstance(call, dict) and set(call) <= {"name", "arguments"}:
            call = (call.get("name"), call.get("arguments"))
        if not (isinstance(call, (list, tuple)) and len(call) == 2 and isinstance(call[0], str)):
            raise ValueError(f"Not a tool call: {call!r}. Use (name, arguments) or 'end_day'.")
        arguments = {} if call[1] is None else call[1]
        json.dumps(arguments)              # the model's arguments are JSON; so are these
        checked.append((call[0], arguments))
    return checked


def _toolbox(root, tools, variant):
    if tools is not None:                  # functions defined in the notebook, before you save them
        return Toolbox(tools)
    if variant == "tools":
        return Toolbox(load_tools((root / "tools.py").read_text(encoding="utf-8"), root))
    return Toolbox(baseline.TOOLS)


def try_tools(calls, *, case="requirements_update", root=".", tools=None, variant="tools"):
    """Run tool calls in one fresh copy of a campaign, exactly as a run would execute them.

    case is a practice case (its scripted customer answers for free) or "full_campaign",
    the 40-account campaign: reading is free, and a message to a customer returns an
    error, because its customers are simulated by a paid model.

    Each call's "output" is the text the model would read next: the tool's return
    value as JSON, or {"error": ...}. "operations" lists the business operations
    the tool performed. The calls share one campaign and one ctx.state. Write
    "end_day" between calls to end the day the way the harness does; after the
    last day the campaign settles and "outcome" holds the profit.

    By default the tools come from your saved tools.py (reloaded every time). Pass
    tools=[my_tool, ...] to try functions defined in the notebook, or
    variant="baseline" for the supplied toolbox.
    """
    root = Path(root).resolve()
    calls = _calls(calls)
    selected = _case(case, root)
    dataset = load_dataset(selected.dataset_path)
    toolbox = _toolbox(root, tools, variant)
    if case == CAMPAIGN:
        customers = _NoMessages()
    else:
        config = json.loads(selected.customer_config_path.read_text(encoding="utf-8"))
        customers = build_customers(config, dataset.scenario)
    world = World(LocalToolClient(SalesEnvironment(dataset.scenario, customers, dataset.crm)))
    steps = []
    for number, (name, arguments) in enumerate(calls, 1):
        if name == "end_day":
            if world.finished:
                raise ValueError("The campaign has already settled; there is no day to end.")
            world.end_day("(ended by try_tools)")
            steps.append({"name": "end_day", "day": world.day, "finished": world.finished})
            continue
        event = len(world.events)
        output = toolbox.run(name, json.dumps(arguments), world, f"try:{number}")
        steps.append({"name": name, "arguments": arguments, "output": output, "result": json.loads(output),
                      "error": world.events[event]["error"], "operations": world.events[event]["operations"],
                      "approx_tokens": _approx_tokens(output)})
    return {"kind": "tool_test", "case_id": case, "calls": steps, "state": world.state,
            "day": world.day, "finished": world.finished, "outcome": world.outcome()}


def try_tool(name, arguments=None, *, case="requirements_update", root=".", tools=None, variant="tools"):
    """Run one tool call in a fresh copy of a campaign (see try_tools). result["output"] is what
    the model would read."""
    if name == "end_day":
        raise ValueError("end_day is not a tool; use try_tools([..., 'end_day', ...]) to end a day.")
    checked = try_tools([(name, arguments)], case=case, root=root, tools=tools, variant=variant)
    return {**checked, "output": checked["calls"][0]["output"], "result": checked["calls"][0]["result"],
            "error": checked["calls"][0]["error"]}


# --------------------------------------------------------------------------- paid runs

def _output(root, output, label):
    if output is None:
        from .experiments import default_output
        return default_output(root, label)
    path = Path(output)
    return path.resolve() if path.is_absolute() else (root / path).resolve()


def run_case(case="requirements_update", *, variant="tools", model=None, root=".", output=None, reference=False):
    """Run one fresh practice case with the ordinary local runner and save it under outputs/.

    The seller uses the course model (or an explicit override) and the limits in
    course.json; practice customers are deterministic and call no API.
    reference=True runs the fixed offline demonstration instead: no model at all.
    """
    root = Path(root).resolve()
    directory = _output(root, output, "reference" if reference else variant)
    arguments = SimpleNamespace(
        agent="reference" if reference else None, name=None, variant=variant,
        model=None if reference else model_settings(root, model=model)["model"],
        customer_model=None, case=case, suite=None, repeats=1, output=directory,
        **course_settings(root)["limits"],
    )
    # The returned result and the saved viewer carry the diagnostics.
    with redirect_stdout(StringIO()):
        exit_code = local.run(arguments, root)
        local.inspect_output(directory)
    attempts = [json.loads(path.read_text(encoding="utf-8"))
                for path in sorted((directory / "runs").glob("*/result.json"))]
    return {"kind": "run", "output": str(directory), "viewer": str(directory / "inspect.html"),
            "exit_code": exit_code, "attempts": attempts}


# --------------------------------------------------------------------------- display

# Scoped styles keep these previews readable in both Jupyter themes. All record
# content is escaped before it enters the page.
CARD_STYLE = """
.sales-preview {color:#21322e;background:#fff;border:1px solid #dfe5e1;border-radius:12px;
  padding:22px 24px;margin:12px 0;font:14px/1.55 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;}
.sales-preview h3 {font-size:20px;line-height:1.25;margin:0 0 8px;color:#142c24;}
.sales-preview h4 {margin:16px 0 6px;}
.sales-preview p {margin:8px 0;white-space:pre-wrap;overflow-wrap:anywhere;}
.sales-preview .muted {color:#68756f;font-size:12px;}
.sales-preview .badge {display:inline-block;padding:3px 9px;border-radius:20px;background:#edf4ef;font-size:12px;}
.sales-preview .badge.error {background:#fcf4ef;color:#8a3b25;}
.sales-preview dl {display:grid;grid-template-columns:minmax(100px,170px) minmax(0,1fr);gap:6px 16px;margin:8px 0;}
.sales-preview dt {color:#68756f;overflow-wrap:anywhere;}
.sales-preview dd {margin:0;white-space:pre-wrap;overflow-wrap:anywhere;}
.sales-preview details {border-top:1px solid #e7ebe8;padding:10px 0;margin:4px 0;}
.sales-preview summary {cursor:pointer;color:#334f43;font-weight:600;}
.sales-preview pre {font:12px/1.5 ui-monospace,monospace;white-space:pre-wrap;overflow-wrap:anywhere;
  background:#f5f7f5;padding:12px;max-height:420px;overflow:auto;}
.sales-preview .item {padding:9px 0;border-bottom:1px solid #edf0ed;}
.sales-preview a {color:#27684b;text-decoration:underline;text-underline-offset:3px;}
.sales-preview ul {padding-left:20px;}
@media(max-width:560px) {.sales-preview {padding:16px;} .sales-preview dl {grid-template-columns:1fr;gap:2px;}}
"""


def _text(value):
    return escape(str(value), quote=True)


def _details(label, body, *, opened=False):
    return f'<details{" open" if opened else ""}><summary>{_text(label)}</summary>{body}</details>'


def _value_html(value, depth=0):
    """Render JSON as fields; large nested values remain one click away."""
    if isinstance(value, dict):
        if not value:
            return '<span class="muted">Empty</span>'
        rows = []
        for key, item in value.items():
            rendered = _value_html(item, depth + 1)
            if isinstance(item, (dict, list)) and item and depth > 0:
                rendered = _details(f'{len(item)} {"fields" if isinstance(item, dict) else "items"}', rendered)
            rows.append(f'<dt>{_text(str(key).replace("_", " "))}</dt><dd>{rendered}</dd>')
        return "<dl>" + "".join(rows) + "</dl>"
    if isinstance(value, list):
        if not value:
            return '<span class="muted">None</span>'
        if all(not isinstance(item, (dict, list)) for item in value):
            return "<ul>" + "".join(f"<li>{_value_html(item, depth + 1)}</li>" for item in value) + "</ul>"
        return "".join(f'<div class="item">{_value_html(item, depth + 1)}</div>' for item in value)
    if value is None:
        return '<span class="muted">Not recorded</span>'
    if isinstance(value, bool):
        return "Yes" if value else "No"
    return _text(value)


def _card(body):
    return f'<style>{CARD_STYLE}</style><section class="sales-preview">{body}</section>'


def _signature(name, arguments):
    return f'{name}({", ".join(f"{key}={value!r}" for key, value in arguments.items())})'


def _tool_card(result):
    body = (f'<h3>Tool check · {_text(result["case_id"])}</h3>'
            f'<p class="muted">Day {_text(result["day"])}'
            f'{" · campaign settled" if result["finished"] else ""} · '
            "each output below is exactly what the model would read next.</p>")
    for number, step in enumerate(result["calls"], 1):
        if step["name"] == "end_day":
            body += f'<div class="item"><strong>{number}. end of day</strong> → day {_text(step["day"])}</div>'
            continue
        badge = (f'<span class="badge error">{_text(step["error"])}</span>' if step["error"]
                 else '<span class="badge">ok</span>')
        operations = "".join(
            f'<li><code>{_text(_signature(op["name"], op["arguments"]))}</code>'
            f'{"" if op["result"]["ok"] else " → " + _text(op["result"]["error"]["code"])}</li>'
            for op in step["operations"])
        body += (f'<div class="item"><strong>{number}. {_text(_signature(step["name"], step["arguments"]))}</strong> {badge}'
                 f'<p class="muted">Output: about {step["approx_tokens"]:,} tokens</p>'
                 f'<pre>{_text(json.dumps(step["result"], indent=2, ensure_ascii=False))}</pre>'
                 + (_details(f'Business operations underneath ({len(step["operations"])})', f"<ul>{operations}</ul>")
                    if step["operations"] else '<p class="muted">No business operations.</p>')
                 + "</div>")
    if result["state"]:
        body += _details("ctx.state after these calls", _value_html(result["state"]))
    if result["outcome"]:
        body += _details("Settlement", _value_html(result["outcome"]), opened=True)
    return _card(body)


def _display_html(content):
    try:
        from IPython import get_ipython
        from IPython.display import HTML, display
    except ImportError:
        return False
    if get_ipython() is None:
        return False
    display(HTML(content))
    return True


def _relative_link(target, label):
    # Notebook-relative URLs; the embedded viewer itself is self-contained.
    relative = os.path.relpath(target, Path.cwd()).replace(os.sep, "/")
    return f'<a href="{_text(quote(relative, safe="/._-"))}" target="_blank" rel="noopener">{_text(label)}</a>'


def _money(cents):
    return "unknown" if cents is None else f"${cents / 100:,.2f}"


def _attempt_line(attempt):
    metrics = attempt.get("metrics", {})
    cost = attempt.get("seller_cost_usd")
    usage = attempt.get("seller_usage", {})
    return (f'{attempt["case_id"]}: {attempt["status"]} · profit {_money(metrics.get("profit_cents"))} · '
            f'{usage.get("responses", 0)} model calls · '
            f'seller API cost {"unknown" if cost is None else f"${cost:,.4f}"}')


def show_result(result):
    """Display a tool check, or a saved run: its numbers, its token chart, and the viewer."""
    if result["kind"] == "tool_test":
        if _display_html(_tool_card(result)):
            return
        for number, step in enumerate(result["calls"], 1):
            if step["name"] == "end_day":
                print(f"{number}. end of day → day {step['day']}")
                continue
            print(f"{number}. {_signature(step['name'], step['arguments'])} → {step['error'] or 'ok'}")
            print("   " + step["output"][:2000])
        if result["outcome"]:
            print("Settlement:", json.dumps(result["outcome"]))
        return
    target = Path(result["viewer"])
    run_pages = sorted(target.parent.glob("runs/*/inspect.html"))
    content = ""
    for attempt, page in zip(result["attempts"], run_pages):
        folder = page.parent
        links = [_relative_link(page, "Open viewer ↗")]
        if (folder / "transcript.md").is_file():
            links.append(_relative_link(folder / "transcript.md", "transcript.md"))
        chart = (folder / "window.svg").read_text(encoding="utf-8") if (folder / "window.svg").is_file() else ""
        content += f'<p><strong>{_text(_attempt_line(attempt))}</strong><br>{" · ".join(links)}</p>{chart}'
    if len(run_pages) == 1:
        # One practice run: embed its page directly. A base URL keeps its file links working.
        page = run_pages[0].read_text(encoding="utf-8")
        directory = os.path.relpath(run_pages[0].parent, Path.cwd()).replace(os.sep, "/")
        page = page.replace("<head>", f'<head><base href="{_text(quote(directory, safe="/._-") + "/")}">', 1)
        content += ('<iframe title="Sales run viewer" sandbox="allow-scripts allow-downloads allow-popups" '
                    'style="width:100%;height:760px;border:1px solid #dfe5e1;border-radius:12px;background:white" '
                    f'srcdoc="{_text(page)}"></iframe>')
    if _display_html(_card(content) if content else _card("<h3>Run saved</h3>")):
        return
    for attempt in result["attempts"]:
        print(_attempt_line(attempt))
        if attempt.get("error"):
            print(f'  {attempt["error"]}')
    print(f"Viewer: {target}")
