"""Business rules and state. This module makes no model or network calls itself.

The injected customer simulator owns customer behavior. The environment owns
time, documents, valid offers, transactions, and the public record of events.
"""

import json
from collections import Counter
from copy import deepcopy
from dataclasses import asdict, replace
from datetime import date, timedelta
from typing import Any

from .crm import CRMRecord, CRMStore
from .errors import ToolError
from .interfaces import CustomerSimulator
from .models import (
    CustomerReply,
    CustomerTurn,
    Document,
    Message,
    Order,
    Quote,
    Scenario,
    Settlement,
)
from .search import excerpt, search_match, searchable_text


# The pricing rule as the company states it. The catalog lists list prices, service
# costs and the policy, not each product's legal range: computing it is the seller's job.
PRICING_RULE = (
    "A quote's monthly price is a whole number of cents, at most the product's list price "
    "and at least the list price less the maximum discount (rounded up to the next cent), "
    "and never below the product's monthly service cost."
)


class SalesEnvironment:
    CONTRACT_VERSION = 3

    def __init__(
        self,
        scenario: Scenario,
        customers: CustomerSimulator,
        crm: CRMStore | None = None,
    ):
        self._validate_scenario(scenario)
        self.scenario = scenario
        self._simulator = customers
        self._customers = {item.id: item for item in scenario.customers}
        self._products = {item.id: item for item in scenario.products}
        self._documents = self._build_documents()
        self._crm = CRMStore.from_dict(crm.to_dict()) if crm is not None else CRMStore()
        if {item.id for item in self._crm.all_records()} & self._documents.keys():
            raise ValueError("CRM record IDs conflict with document IDs.")
        for record in self._crm.all_records():
            if record.customer_id not in self._customers:
                raise ValueError("CRM records must belong to a scenario customer.")
            if record.id.startswith(("run:", "crm:")):
                raise ValueError(
                    "Initial CRM record IDs cannot use reserved run: or crm: prefixes."
                )
            if record.date > scenario.start_date:
                raise ValueError(
                    "Initial CRM records cannot be dated after campaign start."
                )
        self.day = 1
        self.minutes_used_today = 0
        self.finished = False
        self.messages: list[Message] = []
        self._quotes: dict[str, Quote] = {}
        self._orders: dict[str, Order] = {}
        self._settlements: dict[str, Settlement] = {}
        self._notes: list[dict[str, Any]] = []
        self._callbacks: list[dict[str, Any]] = []
        self._opted_out: set[str] = set()
        self._call_ended_on: dict[str, int] = {}
        self._exchange_count = 0

    # Read-only tools return fresh JSON data, never references to mutable state.

    def get_status(self) -> dict[str, Any]:
        config = self.scenario.config
        result = {
            "environment_version": self.CONTRACT_VERSION,
            "day": self.day,
            "date": self._calendar_date(self.day),
            "campaign_days": config.days,
            "finished": self.finished,
            "minutes_remaining_today": config.contact_minutes_per_day
            - self.minutes_used_today,
            "minutes_per_exchange": config.minutes_per_exchange,
            "cost_per_exchange_cents": config.cost_per_exchange_cents,
            "current_pricing_policy": asdict(self._current_policy()),
            "contact_cost_cents": self._exchange_count * config.cost_per_exchange_cents,
            "booked_revenue_cents": sum(
                order.quote.monthly_price_cents for order in self._orders.values()
            ),
            "orders": len(self._orders),
        }
        if self.finished:
            result["outcome"] = self.outcome()
        return result

    def list_customers(self) -> list[dict[str, Any]]:
        return [
            {
                **asdict(customer),
                "status": self._customer_status(customer.id),
                "contact": self._contact_state(customer.id),
            }
            for customer in self._customers.values()
        ]

    def read_customer(
        self, customer_id: str, include_history: bool = False
    ) -> dict[str, Any]:
        """Read operational state; full records remain available on demand."""
        customer = self._customer(customer_id)
        profile = self._crm.profile(customer_id)
        records = self._customer_records(customer_id)
        history = [item for item in self.messages if item.customer_id == customer_id]
        notes = [item for item in self._notes if item["customer_id"] == customer_id]
        callbacks = [
            self._callback_record(item)
            for item in self._callbacks
            if item["customer_id"] == customer_id
        ]
        result = {
            "customer": asdict(customer),
            "profile_id": f"crm:{profile.id}" if profile else None,
            "record_counts": dict(Counter(item.kind for item in records)),
            "status": self._customer_status(customer_id),
            "contact": self._contact_state(customer_id),
            "last_message": self._message_record(history[-1]) if history else None,
            "latest_note": self._copy_note(notes[-1]) if notes else None,
            "pending_callbacks": [
                item for item in callbacks if item["status"] == "pending"
            ],
            "quotes": [
                self._quote_record(quote)
                for quote in self._quotes.values()
                if quote.customer_id == customer_id
            ],
            "orders": [
                self._order_record(order)
                for order in self._orders.values()
                if order.quote.customer_id == customer_id
            ],
        }
        if include_history:
            result.update(
                profile=self.read_record(f"crm:{profile.id}") if profile else None,
                record_index=[self._record_metadata(record) for record in records],
                history=[self._message_record(item) for item in history],
                notes=[self._copy_note(item) for item in notes],
                callbacks=callbacks,
            )
        return result

    def read_customer_history(self, customer_id: str) -> dict[str, Any]:
        """Explicit full view for callers that need every conversation and note."""
        return self.read_customer(customer_id, include_history=True)

    def get_catalog(self) -> dict[str, Any]:
        """Return the products as the company lists them and today's pricing policy.

        Legal prices are not precomputed: the policy states the rule.
        """
        policy = self._current_policy()
        return {
            "day": self.day,
            "current_pricing_policy": {
                **asdict(policy),
                "rule": PRICING_RULE,
                "source_id": f"policy:{policy.id}",
            },
            "products": [
                {
                    **asdict(product),
                    "features": list(product.features),
                    "integrations": list(product.integrations),
                    "source_id": f"product:{product.id}",
                }
                for product in self._products.values()
            ],
        }

    def search_customer_history(
        self, customer_id: str, query: str, kind: str = "all"
    ) -> list[dict[str, Any]]:
        """Search all company records; empty query browses without a result cap."""
        self._customer(customer_id)
        if kind not in {
            "all",
            "profile",
            "sale",
            "refund",
            "cancellation",
            "interaction",
            "note",
            "quote",
            "callback",
        }:
            raise ToolError("invalid_kind", "Unknown customer record kind.")
        if not isinstance(query, str):
            raise ToolError("invalid_query", "Search query must be a string.")
        results = []
        for record in self._customer_records(customer_id):
            if kind != "all" and record.kind != kind:
                continue
            content = searchable_text(record.data)
            rank = search_match(
                query, identifier=record.id, title=record.kind, text=content
            )
            if rank is None:
                continue
            preview, partial = excerpt(content, query)
            results.append(
                (
                    rank,
                    {
                        **self._record_metadata(record),
                        "excerpt": preview,
                        "excerpt_is_partial": partial,
                    },
                )
            )
        return [item for _, item in sorted(results, key=lambda entry: entry[0])]

    def read_record(self, record_id: str) -> dict[str, Any]:
        """Return the complete source, including authorship and references."""
        canonical = self._resolve_reference(record_id, allow_documents=False)
        record = next(item for item in self._all_records() if item.id == canonical)
        return record.to_dict()

    def list_documents(self) -> list[dict[str, Any]]:
        """IDs and titles of the documents available today; read_document has the text."""
        return [
            {
                "id": document.id,
                "title": document.title,
                "available_day": document.available_day,
            }
            for document in self._documents.values()
            if document.available_day <= self.day
        ]

    def read_document(self, document_id: str) -> dict[str, Any]:
        document = self._documents.get(document_id)
        if document is None or document.available_day > self.day:
            raise ToolError("not_found", "No available document has this ID.")
        return asdict(document)

    # Mutation tools validate before changing state or contacting a customer.

    def talk_to_customer(self, customer_id: str, message: str) -> dict[str, Any]:
        return self._exchange(customer_id, message)

    def save_note(
        self, customer_id: str, text: str, source_ids: list[str]
    ) -> dict[str, Any]:
        self._require_active()
        self._customer(customer_id)
        self._require_text(text, "Note")
        if not isinstance(source_ids, list) or any(
            not isinstance(s, str) for s in source_ids
        ):
            raise ToolError("invalid_source", "Source IDs must be a list of strings.")
        canonical_sources = []
        allowed = {item.id for item in self._customer_records(customer_id)}
        allowed.update(
            item.id
            for item in self._documents.values()
            if item.available_day <= self.day
        )
        for source in source_ids:
            try:
                canonical = self._resolve_reference(source)
            except ToolError as error:
                if error.code == "ambiguous_reference":
                    raise
                raise ToolError("invalid_source", str(error)) from error
            if canonical not in allowed:
                raise ToolError(
                    "invalid_source", "A source belongs to another customer."
                )
            canonical_sources.append(canonical)
        note = {
            "id": f"N{len(self._notes) + 1:04d}",
            "day": self.day,
            "customer_id": customer_id,
            "text": text,
            "source_ids": canonical_sources,
            "author": "sales_agent",
        }
        self._notes.append(note)
        return self._copy_note(note)

    def create_quote(
        self, customer_id: str, product_id: str, monthly_price_cents: int
    ) -> dict[str, Any]:
        self._require_active()
        self._require_prospect(customer_id)
        product = self._products.get(product_id)
        if product is None:
            raise ToolError("not_found", "Unknown product ID.")
        if type(monthly_price_cents) is not int:
            raise ToolError("invalid_price", "Use an integer number of cents.")
        policy = self._current_policy()
        # Integer ceiling prevents a fractional cent from exceeding the discount.
        minimum_price = self._minimum_price(product, policy)
        if not minimum_price <= monthly_price_cents <= product.monthly_price_cents:
            raise ToolError(
                "invalid_price",
                "This price is outside today's legal range for this product. "
                "See the pricing rule in get_catalog.",
            )
        quote = Quote(
            id=f"Q{len(self._quotes) + 1:04d}",
            customer_id=customer_id,
            product_id=product_id,
            monthly_price_cents=monthly_price_cents,
            monthly_service_cost_cents=product.monthly_service_cost_cents,
            created_day=self.day,
            expires_day=self.day + policy.quote_valid_days,
            pricing_policy_id=policy.id,
        )
        self._quotes[quote.id] = quote
        return self._quote_record(quote)

    def present_quote(self, quote_id: str, message: str) -> dict[str, Any]:
        canonical = self._resolve_reference(quote_id, allow_documents=False)
        quote = self._quotes.get(canonical.removeprefix("run:quote:"))
        if quote is None:
            raise ToolError(
                "invalid_reference",
                "Present a runtime quote ID returned by create_quote.",
            )
        # Repeating an accepted offer never charges again or creates another order.
        existing = next(
            (order for order in self._orders.values() if order.quote.id == quote.id),
            None,
        )
        if existing is not None:
            return {"already_accepted": True, "order": self._order_record(existing)}
        self._require_active()
        if quote.issued_day is None:
            policy = self._current_policy()
            product = self._products[quote.product_id]
            if (
                not self._minimum_price(product, policy)
                <= quote.monthly_price_cents
                <= product.monthly_price_cents
            ):
                raise ToolError(
                    "stale_draft",
                    "This draft was never issued and its price is no longer legal. "
                    "Use get_catalog and create a new quote under today's policy.",
                )
            # Commit issuance with the exchange only after the simulator succeeds.
            quote = replace(
                quote,
                issued_day=self.day,
                pricing_policy_id=policy.id,
                expires_day=self.day + policy.quote_valid_days,
            )
        elif self.day > quote.expires_day:
            raise ToolError(
                "expired_quote",
                "This quote has expired. Create a new quote under the current policy.",
            )
        return self._exchange(quote.customer_id, message, offer=quote)

    def schedule_callback(
        self, customer_id: str, day: int, reason: str
    ) -> dict[str, Any]:
        self._require_active()
        self._require_prospect(customer_id)
        self._require_text(reason, "Callback reason")
        if type(day) is not int or not self.day <= day <= self.scenario.config.days:
            raise ToolError(
                "invalid_day", "Choose today or a later day within the campaign."
            )
        for item in self._callbacks:
            if item["customer_id"] == customer_id and item["status"] == "pending":
                item["status"] = (
                    "missed" if item["day"] <= self.day < day else "rescheduled"
                )
                item["updated_day"] = self.day
        callback = {
            "id": f"CB{len(self._callbacks) + 1:04d}",
            "customer_id": customer_id,
            "created_day": self.day,
            "day": day,
            "reason": reason,
            "status": "pending",
            "updated_day": self.day,
            "contacted_day": None,
            "contact_record_id": None,
        }
        self._callbacks.append(callback)
        return self._callback_record(callback)

    def advance_day(self) -> dict[str, Any]:
        """End a business day, preserving every conversation and note."""
        self._require_active()
        if self.day == self.scenario.config.days:
            # Gather outcomes before marking the campaign finished. Successful
            # settlements survive retries if another simulator call fails.
            for order in self._orders.values():
                if order.id not in self._settlements:
                    result = self._simulator.settle(order)
                    if (
                        not isinstance(result, Settlement)
                        or type(result.retained) is not bool
                        or not isinstance(result.reason, str)
                    ):
                        raise RuntimeError(
                            "Customer simulator returned an invalid settlement."
                        )
                    self._settlements[order.id] = result
            self.finished = True
        for callback in self._callbacks:
            if callback["status"] == "pending" and callback["day"] <= self.day:
                callback["status"] = "missed"
                callback["updated_day"] = self.day
        if not self.finished:
            self.day += 1
            self.minutes_used_today = 0
        return self.get_status()

    def outcome(self) -> dict[str, int]:
        """One month of realized contribution, available after final settlement.

        A canceled sale receives a full refund. Its service cost was still
        incurred. API usage is reported by the agent, outside business profit.
        """
        if not self.finished:
            raise ToolError(
                "not_finished",
                "The 30-day outcomes are available after the campaign ends.",
            )
        booked_revenue = sum(
            order.quote.monthly_price_cents for order in self._orders.values()
        )
        retained_revenue = sum(
            order.quote.monthly_price_cents
            for order in self._orders.values()
            if self._settlements[order.id].retained
        )
        service_cost = sum(
            order.quote.monthly_service_cost_cents for order in self._orders.values()
        )
        contact_cost = (
            self._exchange_count * self.scenario.config.cost_per_exchange_cents
        )
        return {
            "accepted_orders": len(self._orders),
            "retained_orders": sum(
                result.retained for result in self._settlements.values()
            ),
            "booked_revenue_cents": booked_revenue,
            "refunded_revenue_cents": booked_revenue - retained_revenue,
            "retained_revenue_cents": retained_revenue,
            "service_cost_cents": service_cost,
            "contact_cost_cents": contact_cost,
            "profit_cents": retained_revenue - service_cost - contact_cost,
            "missed_callbacks": sum(
                item["status"] == "missed" for item in self._callbacks
            ),
        }

    def export_customer_records(self) -> list[dict[str, Any]]:
        """Export this run's records, excluding the unchanged initial dataset.

        Envelopes are built from the ledger instead of maintained as a second
        writable copy. A quote, sale, or callback therefore has one source of
        truth, including after a checkpoint is restored.
        """
        records = []

        def add(kind, item_id, customer_id, day, data, source_ids=()):
            records.append(
                CRMRecord(
                    id=f"run:{kind}:{item_id}",
                    customer_id=customer_id,
                    kind=kind,
                    date=self._calendar_date(day),
                    source="sales_agent" if kind == "note" else "sales_environment",
                    source_ids=tuple(source_ids),
                    data=data,
                ).to_dict()
            )

        for message in self.messages:
            sources = (f"run:quote:{message.quote_id}",) if message.quote_id else ()
            add(
                "interaction",
                message.id,
                message.customer_id,
                message.day,
                {
                    "channel": "call",
                    "messages": [{"role": message.role, "text": message.text}],
                    "id": f"run:interaction:{message.id}",
                    "day": message.day,
                    "quote_id": f"run:quote:{message.quote_id}"
                    if message.quote_id
                    else None,
                    "decision": message.decision,
                },
                sources,
            )
        for quote in self._quotes.values():
            add(
                "quote",
                quote.id,
                quote.customer_id,
                quote.created_day,
                self._quote_record(quote),
                (f"policy:{quote.pricing_policy_id}",),
            )
        for order in self._orders.values():
            add(
                "sale",
                order.id,
                order.quote.customer_id,
                order.accepted_day,
                {
                    "product_id": order.quote.product_id,
                    "monthly_price_cents": order.quote.monthly_price_cents,
                    **self._order_record(order),
                },
                (f"run:quote:{order.quote.id}",),
            )
        for note in self._notes:
            add(
                "note",
                note["id"],
                note["customer_id"],
                note["day"],
                {**self._copy_note(note), "authoritative": False},
                note["source_ids"],
            )
        for callback in self._callbacks:
            add(
                "callback",
                callback["id"],
                callback["customer_id"],
                callback["created_day"],
                self._callback_record(callback),
            )
        return sorted(records, key=lambda item: (item["date"], item["id"]))

    def export_state(self) -> dict[str, Any]:
        """Return a complete JSON checkpoint of the mutable environment state.

        Scenario, initial CRM data, simulator state, and seller context belong
        to the run checkpoint and are stored by the runner separately.
        """
        return deepcopy(
            {
                "version": self.CONTRACT_VERSION,
                "day": self.day,
                "minutes_used_today": self.minutes_used_today,
                "finished": self.finished,
                "messages": [asdict(item) for item in self.messages],
                "quotes": [asdict(item) for item in self._quotes.values()],
                "orders": [asdict(item) for item in self._orders.values()],
                "settlements": {
                    key: asdict(value) for key, value in self._settlements.items()
                },
                "notes": self._notes,
                "callbacks": self._callbacks,
                "opted_out": sorted(self._opted_out),
                "call_ended_on": self._call_ended_on,
                "exchange_count": self._exchange_count,
                "runtime_records": self.export_customer_records(),
            }
        )

    def restore_state(self, state: dict[str, Any]) -> None:
        """Validate a checkpoint before replacing this environment's state."""
        candidate = SalesEnvironment(self.scenario, self._simulator, self._crm)
        try:
            candidate._load_state(deepcopy(state))
        except (KeyError, TypeError, ValueError, AttributeError) as error:
            raise ValueError(f"Invalid environment checkpoint: {error}") from error
        # Only business state changes; the configured simulator remains in place.
        for attribute in (
            "day",
            "minutes_used_today",
            "finished",
            "messages",
            "_quotes",
            "_orders",
            "_settlements",
            "_notes",
            "_callbacks",
            "_opted_out",
            "_call_ended_on",
            "_exchange_count",
        ):
            setattr(self, attribute, getattr(candidate, attribute))

    def _load_state(self, state: dict[str, Any]) -> None:
        """Decode the small explicit checkpoint format; never execute file data."""
        if (
            not isinstance(state, dict)
            or type(state.get("version")) is not int
            or state["version"] != self.CONTRACT_VERSION
        ):
            raise ValueError(
                "Unsupported environment state version; version 2 requires a new run. "
                "Resume older experiments with their frozen source version."
            )
        required = {
            "version",
            "day",
            "minutes_used_today",
            "finished",
            "messages",
            "quotes",
            "orders",
            "settlements",
            "notes",
            "callbacks",
            "opted_out",
            "call_ended_on",
            "exchange_count",
            "runtime_records",
        }
        if set(state) != required:
            raise ValueError("Checkpoint fields do not match version 2.")
        json.dumps(state, allow_nan=False)
        self.day = state["day"]
        self.minutes_used_today = state["minutes_used_today"]
        self.finished = state["finished"]
        self._exchange_count = state["exchange_count"]
        self.messages = [Message(**item) for item in state["messages"]]
        quotes = [Quote(**item) for item in state["quotes"]]
        orders = [
            Order(item["id"], Quote(**item["quote"]), item["accepted_day"])
            for item in state["orders"]
        ]
        self._quotes = {item.id: item for item in quotes}
        self._orders = {item.id: item for item in orders}
        self._settlements = {
            key: Settlement(**value) for key, value in state["settlements"].items()
        }
        self._notes = state["notes"]
        self._callbacks = state["callbacks"]
        self._opted_out = set(state["opted_out"])
        self._call_ended_on = state["call_ended_on"]
        self._validate_restored_state()
        if len(quotes) != len(self._quotes) or len(orders) != len(self._orders):
            raise ValueError("Duplicate quote or order IDs.")
        if self.export_customer_records() != state["runtime_records"]:
            raise ValueError("Runtime CRM records do not match the business ledger.")

    def _validate_restored_state(self) -> None:
        config = self.scenario.config

        def require(condition, message):
            if not condition:
                raise ValueError(message)

        def valid_day(value):
            return type(value) is int and 1 <= value <= self.day

        def valid_ids(items, prefix):
            require(
                [item.id if hasattr(item, "id") else item["id"] for item in items]
                == [f"{prefix}{number:04d}" for number in range(1, len(items) + 1)],
                f"Invalid or duplicate {prefix} IDs.",
            )

        require(type(self.day) is int and 1 <= self.day <= config.days, "Invalid day.")
        require(type(self.finished) is bool, "Invalid finished flag.")
        require(
            not self.finished or self.day == config.days, "Campaign finished early."
        )
        require(
            type(self.minutes_used_today) is int
            and 0 <= self.minutes_used_today <= config.contact_minutes_per_day,
            "Invalid contact minutes.",
        )
        require(
            type(self._exchange_count) is int and self._exchange_count >= 0,
            "Invalid exchange count.",
        )
        require(
            len(self.messages) == 2 * self._exchange_count, "Exchange count mismatch."
        )
        valid_ids(self.messages, "M")
        valid_ids(list(self._quotes.values()), "Q")
        valid_ids(list(self._orders.values()), "O")
        valid_ids(self._notes, "N")
        valid_ids(self._callbacks, "CB")
        for position, message in enumerate(self.messages):
            require(message.customer_id in self._customers, "Unknown message customer.")
            require(valid_day(message.day), "Invalid message day.")
            require(
                message.role == ("salesperson" if position % 2 == 0 else "customer"),
                "Invalid message role sequence.",
            )
            require(
                message.decision
                in {"continue", "accept", "decline", "end_call", "opt_out"}
                if message.role == "customer"
                else message.decision is None,
                "Invalid message decision.",
            )
            require(
                isinstance(message.text, str) and bool(message.text.strip()),
                "Empty message text.",
            )
            require(
                message.quote_id is None
                or (
                    message.quote_id in self._quotes
                    and self._quotes[message.quote_id].customer_id
                    == message.customer_id
                ),
                "Invalid message quote reference.",
            )
            if position % 2:
                previous = self.messages[position - 1]
                require(
                    (previous.customer_id, previous.day, previous.quote_id)
                    == (message.customer_id, message.day, message.quote_id),
                    "Messages do not form a customer exchange.",
                )
        today_exchanges = sum(item.day == self.day for item in self.messages) // 2
        require(
            self.minutes_used_today == today_exchanges * config.minutes_per_exchange,
            "Contact minutes do not match today's exchanges.",
        )
        for quote in self._quotes.values():
            require(quote.customer_id in self._customers, "Unknown quote customer.")
            require(quote.product_id in self._products, "Unknown quote product.")
            require(valid_day(quote.created_day), "Invalid quote day.")
            policies = {item.id: item for item in self.scenario.pricing_policies}
            require(
                quote.pricing_policy_id in policies, "Unknown quote pricing policy."
            )
            policy = policies[quote.pricing_policy_id]
            product = self._products[quote.product_id]
            presentation_days = [
                item.day
                for item in self.messages
                if item.quote_id == quote.id and item.role == "salesperson"
            ]
            require(
                quote.issued_day is None
                if not presentation_days
                else (
                    valid_day(quote.issued_day)
                    and quote.created_day <= quote.issued_day == min(presentation_days)
                ),
                "Quote issuance does not match presentation history.",
            )
            pricing_day = quote.issued_day or quote.created_day
            active_policy = max(
                (
                    item
                    for item in policies.values()
                    if item.effective_day <= pricing_day
                ),
                key=lambda item: item.effective_day,
            )
            require(policy == active_policy, "Quote uses a policy that was not active.")
            minimum_price = max(
                product.monthly_service_cost_cents,
                (product.monthly_price_cents * (100 - policy.max_discount_percent) + 99)
                // 100,
            )
            require(
                type(quote.monthly_price_cents) is int
                and minimum_price
                <= quote.monthly_price_cents
                <= product.monthly_price_cents,
                "Invalid quote price.",
            )
            require(
                quote.monthly_service_cost_cents == product.monthly_service_cost_cents,
                "Invalid quote cost.",
            )
            require(
                quote.expires_day == pricing_day + policy.quote_valid_days,
                "Invalid quote expiration.",
            )
        purchased = set()
        for order in self._orders.values():
            require(
                self._quotes.get(order.quote.id) == order.quote, "Order quote mismatch."
            )
            require(
                valid_day(order.accepted_day)
                and order.quote.issued_day is not None
                and order.quote.issued_day
                <= order.accepted_day
                <= order.quote.expires_day,
                "Invalid order acceptance day.",
            )
            require(
                order.quote.customer_id not in purchased, "Duplicate customer order."
            )
            purchased.add(order.quote.customer_id)
        accepted_messages = [
            item for item in self.messages if item.decision == "accept"
        ]
        require(
            len(accepted_messages) == len(self._orders)
            and {(item.quote_id, item.day) for item in accepted_messages}
            == {(item.quote.id, item.accepted_day) for item in self._orders.values()},
            "Accepted decisions do not match orders.",
        )
        require(
            set(self._settlements).issubset(self._orders), "Unknown settlement order."
        )
        require(
            not self.finished or set(self._settlements) == set(self._orders),
            "Finished campaign has unsettled orders.",
        )
        for settlement in self._settlements.values():
            require(
                type(settlement.retained) is bool
                and isinstance(settlement.reason, str),
                "Invalid settlement.",
            )
        require(
            self._opted_out.issubset(self._customers), "Unknown opted-out customer."
        )
        require(
            self._opted_out
            == {
                item.customer_id for item in self.messages if item.decision == "opt_out"
            },
            "Opt-out state does not match decisions.",
        )
        require(
            self._call_ended_on
            == {
                item.customer_id: item.day
                for item in self.messages
                if item.decision in {"end_call", "opt_out"}
            },
            "Ended-call state does not match decisions.",
        )
        for customer_id, day in self._call_ended_on.items():
            require(
                customer_id in self._customers and valid_day(day), "Invalid ended call."
            )
        for note in self._notes:
            require(
                note["customer_id"] in self._customers and valid_day(note["day"]),
                "Invalid note customer or day.",
            )
            require(
                note["author"] == "sales_agent"
                and isinstance(note["text"], str)
                and bool(note["text"].strip())
                and isinstance(note["source_ids"], list)
                and all(isinstance(item, str) for item in note["source_ids"]),
                "Invalid agent note.",
            )
            available_sources = {
                f"crm:{record.id}"
                for record in self._crm.records_for(note["customer_id"])
            }
            available_sources.update(
                item.id
                for item in self._documents.values()
                if item.available_day <= note["day"]
            )
            for kind, items, get_customer, get_day in (
                (
                    "interaction",
                    self.messages,
                    lambda item: item.customer_id,
                    lambda item: item.day,
                ),
                (
                    "quote",
                    self._quotes.values(),
                    lambda item: item.customer_id,
                    lambda item: item.created_day,
                ),
                (
                    "sale",
                    self._orders.values(),
                    lambda item: item.quote.customer_id,
                    lambda item: item.accepted_day,
                ),
            ):
                for item in items:
                    if (
                        get_customer(item) == note["customer_id"]
                        and get_day(item) <= note["day"]
                    ):
                        available_sources.add(f"run:{kind}:{item.id}")
            available_sources.update(
                f"run:note:{item['id']}"
                for item in self._notes
                if item["customer_id"] == note["customer_id"]
                and item["day"] <= note["day"]
            )
            available_sources.update(
                f"run:callback:{item['id']}"
                for item in self._callbacks
                if item["customer_id"] == note["customer_id"]
                and item["created_day"] <= note["day"]
            )
            require(
                set(note["source_ids"]).issubset(available_sources),
                "Unknown note source.",
            )
        for callback in self._callbacks:
            require(
                callback["customer_id"] in self._customers, "Unknown callback customer."
            )
            require(
                valid_day(callback["created_day"])
                and type(callback["day"]) is int
                and callback["created_day"] <= callback["day"] <= config.days,
                "Invalid callback date.",
            )
            require(
                callback["status"]
                in {"pending", "rescheduled", "completed", "canceled", "missed"}
                and isinstance(callback["reason"], str)
                and bool(callback["reason"].strip()),
                "Invalid callback.",
            )
            require(
                valid_day(callback["updated_day"])
                and callback["created_day"] <= callback["updated_day"],
                "Invalid callback update day.",
            )
            if callback["status"] == "completed":
                require(
                    type(callback["contacted_day"]) is int
                    and callback["day"]
                    == callback["contacted_day"]
                    == callback["updated_day"],
                    "Callback completion dates do not agree.",
                )
                contacts = [
                    item
                    for item in self.messages
                    if (
                        f"run:interaction:{item.id}" == callback["contact_record_id"]
                        and item.customer_id == callback["customer_id"]
                        and item.role == "customer"
                        and item.day == callback["contacted_day"]
                        and item.day == callback["day"]
                    )
                ]
                require(bool(contacts), "Callback contact does not match history.")
            else:
                require(
                    callback["contacted_day"] is None
                    and callback["contact_record_id"] is None,
                    "Uncontacted callback has contact evidence.",
                )
            if callback["status"] == "pending":
                require(
                    not self.finished
                    and callback["day"] >= self.day
                    and self._customer_status(callback["customer_id"]) == "prospect",
                    "Pending callback is overdue or cannot be contacted.",
                )
            if callback["status"] == "missed":
                require(
                    callback["updated_day"] >= callback["day"],
                    "Callback missed before due day.",
                )
            if callback["status"] == "canceled":
                require(
                    self._customer_status(callback["customer_id"]) != "prospect",
                    "Callback canceled without purchase or opt-out.",
                )

    # Internal helpers keep the public tool methods short.

    def _calendar_date(self, day: int) -> str:
        return (
            date.fromisoformat(self.scenario.start_date) + timedelta(days=day - 1)
        ).isoformat()

    def _all_records(self) -> tuple[CRMRecord, ...]:
        runtime = tuple(
            CRMRecord.from_dict(item) for item in self.export_customer_records()
        )
        return tuple(
            sorted(
                (*self._initial_records(), *runtime),
                key=lambda item: (item.date, item.id),
            )
        )

    def _initial_records(self) -> tuple[CRMRecord, ...]:
        """Namespace source records without changing the supplied dataset."""
        record_ids = {item.id for item in self._crm.all_records()}
        records = []
        for item in self._crm.all_records():
            data = deepcopy(item.data)
            if item.kind in {"refund", "cancellation"} and "sale_id" in data:
                data["sale_id"] = f"crm:{data['sale_id']}"
            records.append(
                replace(
                    item,
                    id=f"crm:{item.id}",
                    data=data,
                    source_ids=tuple(
                        f"crm:{s}" if s in record_ids else s for s in item.source_ids
                    ),
                )
            )
        return tuple(records)

    def _resolve_reference(
        self, reference: str, *, allow_documents: bool = True
    ) -> str:
        """Accept canonical references and unambiguous legacy aliases."""
        if not isinstance(reference, str) or not reference:
            raise ToolError(
                "not_found", "Use an ID returned by a search or tool receipt."
            )
        candidates = {
            item.id
            for item in self._all_records()
            if item.id == reference
            or item.id == f"crm:{reference}"
            or (item.id.startswith("run:") and item.id.rsplit(":", 1)[-1] == reference)
        }
        if (
            allow_documents
            and reference in self._documents
            and self._documents[reference].available_day <= self.day
        ):
            candidates.add(reference)
        if len(candidates) > 1:
            raise ToolError(
                "ambiguous_reference",
                "Use a canonical ID: " + ", ".join(sorted(candidates)),
            )
        if not candidates:
            raise ToolError(
                "not_found",
                "Unknown or unavailable reference. Use an ID returned by read_customer_history, "
                "search_customer_history or list_documents.",
            )
        return next(iter(candidates))

    def _customer_records(self, customer_id: str) -> tuple[CRMRecord, ...]:
        return tuple(
            item for item in self._all_records() if item.customer_id == customer_id
        )

    @staticmethod
    def _record_metadata(record: CRMRecord) -> dict[str, Any]:
        return {
            "id": record.id,
            "customer_id": record.customer_id,
            "kind": record.kind,
            "date": record.date,
            "source": record.source,
            "source_ids": list(record.source_ids),
        }

    def _exchange(
        self, customer_id: str, message: str, offer: Quote | None = None
    ) -> dict[str, Any]:
        self._require_active()
        customer = self._require_prospect(customer_id)
        self._require_text(message, "Message")
        if self._call_ended_on.get(customer_id) == self.day:
            raise ToolError(
                "call_ended",
                "This customer ended today's conversation. Try a later day.",
            )
        config = self.scenario.config
        if (
            self.minutes_used_today + config.minutes_per_exchange
            > config.contact_minutes_per_day
        ):
            raise ToolError(
                "day_full", "Today's contact time is used. Advance the business day."
            )
        history = tuple(
            item for item in self.messages if item.customer_id == customer_id
        )
        presented_ids = {item.quote_id for item in history if item.quote_id is not None}
        turn = CustomerTurn(
            customer=customer,
            day=self.day,
            history=history,
            salesperson_message=message,
            offer=offer,
            product=self._products[offer.product_id] if offer else None,
            presented_quotes=tuple(
                quote for quote in self._quotes.values() if quote.id in presented_ids
            ),
            prior_records=tuple(
                record.to_dict()
                for record in self._crm.records_for(customer_id)
                if record.kind in {"sale", "refund", "cancellation", "interaction"}
            ),
        )
        reply = self._simulator.respond(turn)
        if (
            not isinstance(reply, CustomerReply)
            or not isinstance(reply.text, str)
            or not reply.text.strip()
        ):
            raise RuntimeError("Customer simulator returned an invalid reply.")
        if reply.decision not in {
            "continue",
            "accept",
            "decline",
            "end_call",
            "opt_out",
        }:
            raise RuntimeError("Customer simulator returned an unknown decision.")
        if reply.decision == "accept" and offer is None:
            raise RuntimeError("A customer cannot accept without a presented quote.")

        # Commit only after a valid simulator result. Exceptions leave the
        # business ledger untouched rather than inventing customer behavior.
        salesperson = Message(
            f"M{len(self.messages) + 1:04d}",
            self.day,
            customer_id,
            "salesperson",
            message,
            offer.id if offer else None,
        )
        response = Message(
            f"M{len(self.messages) + 2:04d}",
            self.day,
            customer_id,
            "customer",
            reply.text,
            offer.id if offer else None,
            reply.decision,
        )
        if offer is not None:
            self._quotes[offer.id] = offer
        self.messages.extend((salesperson, response))
        self.minutes_used_today += config.minutes_per_exchange
        self._exchange_count += 1
        for callback in self._callbacks:
            if (
                callback["customer_id"] == customer_id
                and callback["status"] == "pending"
                and callback["day"] <= self.day
            ):
                callback["status"] = "completed"
                callback["updated_day"] = self.day
                callback["contacted_day"] = self.day
                callback["contact_record_id"] = f"run:interaction:{response.id}"
        if reply.decision in {"end_call", "opt_out"}:
            self._call_ended_on[customer_id] = self.day
        if reply.decision == "opt_out":
            self._opted_out.add(customer_id)
        result = {
            "reply": self._message_record(response),
            "decision": reply.decision,
            "order": None,
        }
        if reply.decision == "accept":
            order = Order(f"O{len(self._orders) + 1:04d}", offer, self.day)
            self._orders[order.id] = order
            result["order"] = self._order_record(order)
        if reply.decision in {"accept", "opt_out"}:
            for callback in self._callbacks:
                if (
                    callback["customer_id"] == customer_id
                    and callback["status"] == "pending"
                ):
                    callback["status"] = "canceled"
                    callback["updated_day"] = self.day
        return result

    def _customer(self, customer_id: str):
        if customer_id not in self._customers:
            raise ToolError("not_found", "Unknown customer ID.")
        return self._customers[customer_id]

    def _require_prospect(self, customer_id: str):
        customer = self._customer(customer_id)
        status = self._customer_status(customer_id)
        if status == "opted_out":
            raise ToolError("opted_out", "This customer asked not to be contacted.")
        if status == "purchased":
            raise ToolError(
                "already_purchased",
                "This customer already has an order in this campaign.",
            )
        return customer

    def _customer_status(self, customer_id: str) -> str:
        if customer_id in self._opted_out:
            return "opted_out"
        if any(
            order.quote.customer_id == customer_id for order in self._orders.values()
        ):
            return "purchased"
        return "prospect"

    def _contact_state(self, customer_id: str) -> dict[str, Any]:
        status = self._customer_status(customer_id)
        reason = None
        if self.finished:
            reason = "campaign_finished"
        elif status != "prospect":
            reason = "opted_out" if status == "opted_out" else "already_purchased"
        elif self._call_ended_on.get(customer_id) == self.day:
            reason = "call_ended"
        elif (
            self.minutes_used_today + self.scenario.config.minutes_per_exchange
            > self.scenario.config.contact_minutes_per_day
        ):
            reason = "day_full"
        last = next(
            (
                item
                for item in reversed(self.messages)
                if item.customer_id == customer_id and item.role == "customer"
            ),
            None,
        )
        available_day = (
            self.day
            if reason is None
            else (
                self.day + 1
                if reason in {"call_ended", "day_full"}
                and self.day < self.scenario.config.days
                else None
            )
        )
        return {
            "eligible": reason is None,
            "reason": reason,
            "available_day": available_day,
            "last_contact_day": last.day if last else None,
            "last_decision": last.decision if last else None,
        }

    def _require_active(self):
        if self.finished:
            raise ToolError(
                "campaign_finished",
                "The campaign is finished; records remain available to read.",
            )

    @staticmethod
    def _require_text(text: str, label: str):
        if not isinstance(text, str) or not text.strip():
            raise ToolError("empty_text", f"{label} must not be empty.")

    def _current_policy(self):
        return max(
            (
                item
                for item in self.scenario.pricing_policies
                if item.effective_day <= self.day
            ),
            key=lambda item: item.effective_day,
        )

    def _quote_record(self, quote: Quote) -> dict[str, Any]:
        accepted = any(order.quote.id == quote.id for order in self._orders.values())
        expired = not accepted and quote.issued_day is not None and self.day > quote.expires_day
        # No derived status: the record holds the days (a draft has no issued_day and
        # no expires_day; an accepted quote appears in the account's orders).
        return {
            **asdict(quote),
            "id": f"run:quote:{quote.id}",
            "expires_day": quote.expires_day if quote.issued_day is not None else None,
            "updated_day": max(
                [quote.issued_day or quote.created_day]
                + [
                    order.accepted_day
                    for order in self._orders.values()
                    if order.quote.id == quote.id
                ]
                + ([quote.expires_day + 1] if expired else [])
            ),
        }

    def _order_record(self, order: Order) -> dict[str, Any]:
        result = asdict(order)
        result["id"] = f"run:sale:{order.id}"
        result["quote"] = self._quote_record(order.quote)
        result["updated_day"] = self.day if self.finished else order.accepted_day
        # Settlement is never revealed until the whole campaign finishes.
        result["settlement"] = (
            asdict(self._settlements[order.id]) if self.finished else None
        )
        return result

    @staticmethod
    def _copy_note(note: dict[str, Any]) -> dict[str, Any]:
        return {
            **note,
            "id": f"run:note:{note['id']}",
            "source_ids": list(note["source_ids"]),
        }

    @staticmethod
    def _message_record(message: Message) -> dict[str, Any]:
        return {
            **asdict(message),
            "id": f"run:interaction:{message.id}",
            "quote_id": f"run:quote:{message.quote_id}" if message.quote_id else None,
        }

    @staticmethod
    def _callback_record(callback: dict[str, Any]) -> dict[str, Any]:
        return {
            **callback,
            "id": f"run:callback:{callback['id']}",
            "completion_basis": "contact_only",
        }

    @staticmethod
    def _minimum_price(product, policy) -> int:
        return max(
            product.monthly_service_cost_cents,
            (product.monthly_price_cents * (100 - policy.max_discount_percent) + 99)
            // 100,
        )

    def _build_documents(self) -> dict[str, Document]:
        documents = list(self.scenario.documents)
        for product in self.scenario.products:
            documents.append(
                Document(
                    f"product:{product.id}",
                    product.name,
                    f"Product ID: {product.id}. Monthly list price: {product.monthly_price_cents} cents. "
                    f"Monthly service cost: {product.monthly_service_cost_cents} cents. "
                    f"Features: {', '.join(product.features)}. Integrations: {', '.join(product.integrations)}.",
                )
            )
        for policy in self.scenario.pricing_policies:
            documents.append(
                Document(
                    f"policy:{policy.id}",
                    f"Pricing policy {policy.id}",
                    f"Effective from day {policy.effective_day}. Maximum discount: {policy.max_discount_percent}%. "
                    f"Quotes expire at the end of issue day plus {policy.quote_valid_days} days. "
                    "Issued unexpired quotes retain their original price. Drafts reserve no terms; "
                    "first presentation checks the current policy and starts validity. "
                    "One order per customer per campaign. " + PRICING_RULE,
                    available_day=policy.effective_day,
                )
            )
        if len({item.id for item in documents}) != len(documents):
            raise ValueError(
                "Document IDs must be unique, including generated product: and policy: IDs."
            )
        return {item.id: item for item in documents}

    @staticmethod
    def _validate_scenario(scenario: Scenario):
        try:
            if (
                date.fromisoformat(scenario.start_date).isoformat()
                != scenario.start_date
            ):
                raise ValueError
        except (TypeError, ValueError):
            raise ValueError(
                "Campaign start_date must be an ISO date (YYYY-MM-DD)."
            ) from None
        config = scenario.config
        for value in (
            config.days,
            config.contact_minutes_per_day,
            config.minutes_per_exchange,
        ):
            if type(value) is not int or value <= 0:
                raise ValueError(
                    "Campaign days and contact minutes must be positive integers."
                )
        if (
            type(config.cost_per_exchange_cents) is not int
            or config.cost_per_exchange_cents < 0
        ):
            raise ValueError(
                "Contact cost must be a nonnegative integer number of cents."
            )
        if config.minutes_per_exchange > config.contact_minutes_per_day:
            raise ValueError(
                "A business day must allow at least one customer exchange."
            )
        for collection in (
            scenario.customers,
            scenario.products,
            scenario.pricing_policies,
        ):
            if (
                not collection
                or len({item.id for item in collection}) != len(collection)
                or any(not item.id for item in collection)
            ):
                raise ValueError(
                    "Customers, products, and policies require unique, nonempty IDs."
                )
        if min(item.effective_day for item in scenario.pricing_policies) != 1:
            raise ValueError("A pricing policy must be effective on day 1.")
        if len({item.effective_day for item in scenario.pricing_policies}) != len(
            scenario.pricing_policies
        ):
            raise ValueError(
                "Only one pricing policy may become effective on a given day."
            )
        for policy in scenario.pricing_policies:
            if (
                type(policy.effective_day) is not int
                or policy.effective_day < 1
                or type(policy.quote_valid_days) is not int
                or policy.quote_valid_days < 0
            ):
                raise ValueError("Policy days must be valid integers.")
            if (
                type(policy.max_discount_percent) is not int
                or not 0 <= policy.max_discount_percent <= 100
            ):
                raise ValueError(
                    "Discounts must be integer percentages between 0 and 100."
                )
        for product in scenario.products:
            if (
                type(product.monthly_price_cents) is not int
                or product.monthly_price_cents <= 0
                or type(product.monthly_service_cost_cents) is not int
                or not 0
                <= product.monthly_service_cost_cents
                <= product.monthly_price_cents
            ):
                raise ValueError(
                    "Product prices and costs must be valid integer cents."
                )
        if any(
            type(item.available_day) is not int or item.available_day < 1
            for item in scenario.documents
        ):
            raise ValueError("Document availability days must be positive integers.")
        if any(item.id.startswith(("run:", "crm:")) for item in scenario.documents):
            raise ValueError("Document IDs cannot use reserved run: or crm: prefixes.")
