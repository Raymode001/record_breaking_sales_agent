"""Run the three homework variants and derive a manifest from saved evidence.

Execution stays in local.run. This module freezes the shared inputs, names the
outputs, and records which planned trials actually started, including failures.
"""

import hashlib
import json
from argparse import Namespace
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path

from . import local
from .files import _atomic_write, _json
from .student_submission import VARIANTS, load_submission
from .suites import FORMAL_SUITE

CODE_FILES = ("prompt.py", "tools.py")


def default_output(root, label, suffix=""):
    """Choose a readable timestamped path without overwriting an earlier run."""
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    parent = Path(root) / "outputs"
    candidate = parent / f"{label}-{timestamp}{suffix}"
    number = 2
    while candidate.exists():
        candidate = parent / f"{label}-{timestamp}-{number}{suffix}"
        number += 1
    return candidate


def source_hashes(sources):
    """Hash the exact UTF-8 source strings used by the fixed loader."""
    return {name: hashlib.sha256(sources[name].encode("utf-8")).hexdigest()
            for name in CODE_FILES}


def _save(path, value):
    _atomic_write(path, _json(value))


def _read(path):
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object: {path}")
    return value


def experiment_manifest(directory, *, final_variant=None):
    """Rebuild bookkeeping from immutable snapshots and all saved result rows.

    Missing or malformed results remain explicit unknowns. They never count as
    successful trials. This is a reproducibility check, not tamper-proof grading.
    """
    directory = Path(directory).resolve()
    plan = _read(directory / "experiment.json")
    if plan.get("schema_version") != 2:
        raise ValueError("Unsupported experiment schema; run a new experiment.")
    planned = plan.get("planned_attempts")
    if not isinstance(planned, list) or not planned:
        raise ValueError("The experiment has no trial plan.")
    identities = set()
    for trial in planned:
        if (not isinstance(trial, dict) or trial.get("variant") not in VARIANTS
                or not isinstance(trial.get("case_id"), str)
                or not trial["case_id"] or "/" in trial["case_id"] or "\\" in trial["case_id"]
                or type(trial.get("repeat")) is not int or trial["repeat"] < 1):
            raise ValueError("Invalid planned trial in experiment.json.")
        expected = f"{trial['variant']}/runs/{trial['case_id']}__{trial['repeat']:03d}"
        if trial.get("path") != expected or expected in identities:
            raise ValueError("A planned trial has a changed or duplicate path.")
        identities.add(expected)
    if final_variant is not None and final_variant not in VARIANTS:
        raise ValueError("Choose baseline, prompt, or tools for the final variant.")
    sources = {name: (directory / "submission" / name).read_text(encoding="utf-8")
               for name in CODE_FILES}
    hashes = source_hashes(sources)
    if hashes != plan.get("source_sha256"):
        raise ValueError("The experiment source snapshot has changed.")
    variants = {}
    attempts = []
    for variant in VARIANTS:
        run_root = directory / variant
        entry = {"path": variant, "settings": None, "batch_status": None, "errors": []}
        for name, key in (("settings.json", "settings"), ("batch_status.json", "batch_status")):
            path = run_root / name
            if path.exists():
                try:
                    entry[key] = _read(path)
                except (OSError, ValueError) as error:
                    entry["errors"].append(f"{name}: {error}")
        if entry["settings"] and entry["settings"].get("source_sha256", hashes) != hashes:
            entry["errors"].append("Run settings record different source hashes.")
        for planned in plan["planned_attempts"]:
            if planned["variant"] != variant:
                continue
            row = dict(planned)
            result_path = directory / row["path"] / "result.json"
            row.update(started=False, status="not_started", result=None)
            if result_path.exists():
                row["started"] = True
                try:
                    result = _read(result_path)
                    if result.get("case_id") != row["case_id"] or result.get("repeat") != row["repeat"]:
                        raise ValueError("Result identity does not match the planned trial.")
                    row.update(status=result.get("status", "unknown"), result=result)
                except (OSError, ValueError) as error:
                    row.update(status="unknown", error=str(error))
            attempts.append(row)
        variants[variant] = entry
    started = sum(row["started"] for row in attempts)
    completed = sum(row["status"] == "completed" for row in attempts)
    manifest = {
        **plan, "final_variant": final_variant,
        "variants": variants, "attempts": attempts,
        "planned_count": len(attempts), "started_count": started,
        "completed_count": completed,
        "not_started_count": len(attempts) - started,
    }
    return manifest


def run_experiment(arguments, root):
    """Freeze once, run each variant, and stop the batch on unresolved billing."""
    root = Path(root).resolve()
    if not arguments.model:
        raise ValueError("Choose --model for the seller.")
    if arguments.repeats < 1 or arguments.max_steps < 1:
        raise ValueError("Repeats and max steps must be positive.")
    suite = arguments.suite or root / FORMAL_SUITE
    base_args = Namespace(**vars(arguments))
    base_args.case = None
    base_args.agent = None
    base_args.suite = suite
    # Validate both edit points before the first paid request, then reuse these
    # source strings and case objects for every configuration and repetition.
    submission = load_submission(root, "tools")
    inputs = local.prepare_inputs(base_args, root)
    output = Path(arguments.output or default_output(root, "experiment")).resolve()
    output.mkdir(parents=True, exist_ok=False)
    (output / "submission").mkdir()
    for name, source in submission.sources.items():
        (output / "submission" / name).write_text(source, encoding="utf-8")
    plan = {
        "schema_version": 2,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "suite": str(Path(suite).resolve()),
        "requested_settings": {
            key: getattr(arguments, key, None)
            for key in ("model", "customer_model", "repeats", "max_steps",
                        "max_api_calls", "max_output_tokens", "max_token_units")
        } | {"reasoning_effort": getattr(arguments, "reasoning_effort", None) or local.course_reasoning(root)},
        "source_sha256": source_hashes(submission.sources),
        "case_inputs": [{"case_id": case.id, "case_fingerprint": fingerprint}
                        for case, _, _, _, _, fingerprint in inputs],
        "planned_attempts": [
            {"variant": variant, "case_id": case.id, "repeat": repeat,
             "path": f"{variant}/runs/{case.id}__{repeat:03d}"}
            for variant in VARIANTS for case, *_ in inputs
            for repeat in range(1, arguments.repeats + 1)
        ],
        "state": "running", "stop_reason": None,
    }
    _save(output / "experiment.json", plan)
    _save(output / "experiment_manifest.json", experiment_manifest(output))
    return_codes = []
    for variant in VARIANTS:
        trial_args = Namespace(**vars(base_args))
        trial_args.variant, trial_args.name = variant, variant
        trial_args.output = output / variant
        try:
            code = local.run(trial_args, root, submission=replace(submission, variant=variant), inputs=inputs)
            return_codes.append(code)
            batch = _read(trial_args.output / "batch_status.json")
            if batch.get("stopped"):
                plan.update(state="stopped", stop_reason=batch.get("reason") or "Run stopped.")
        except (Exception, KeyboardInterrupt) as error:
            return_codes.append(1)
            plan.update(state="interrupted" if isinstance(error, KeyboardInterrupt) else "stopped",
                        stop_reason=f"{type(error).__name__}: {error}")
        _save(output / "experiment.json", plan)
        _save(output / "experiment_manifest.json", experiment_manifest(output))
        if plan["state"] != "running":
            break
    if plan["state"] == "running":
        plan["state"] = "finished"
    _save(output / "experiment.json", plan)
    manifest = experiment_manifest(output)
    _save(output / "experiment_manifest.json", manifest)
    # Comparison reads saved rows only. Never launch more API calls for reports.
    existing = [output / variant for variant in VARIANTS
                if any((output / variant / "runs").glob("*/result.json"))]
    if existing:
        try:
            local.inspect_output(output)
        except (OSError, ValueError, KeyError) as error:
            plan.setdefault("inspection_errors", []).append({
                "output": str(output), "error": f"{type(error).__name__}: {error}",
            })
            return_codes.append(1)
    if existing:
        try:
            local.compare(existing, output / "comparison")
        except (OSError, ValueError, KeyError) as error:
            # Reporting must not discard the run ledger if a saved row is damaged.
            plan["comparison_error"] = f"{type(error).__name__}: {error}"
            return_codes.append(1)
    _save(output / "experiment.json", plan)
    manifest = experiment_manifest(output)
    _save(output / "experiment_manifest.json", manifest)
    print(f"Experiment: {output}")
    print(f"Started {manifest['started_count']}/{manifest['planned_count']} trials; "
          f"{manifest['completed_count']} completed.")
    if plan["stop_reason"]:
        print(f"Stopped: {plan['stop_reason']}")
    return int(plan["state"] != "finished" or any(return_codes))
