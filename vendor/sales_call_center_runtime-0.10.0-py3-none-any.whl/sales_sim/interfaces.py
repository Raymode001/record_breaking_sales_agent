"""The two extension points: a customer simulator and a seller tool client."""

from typing import Any, Protocol

from .models import CustomerReply, CustomerTurn, Order, Settlement


class CustomerSimulator(Protocol):
    """Students supply this for development; instructors replace it for grading.

    Keep private preferences inside the implementation. Replies can reveal
    facts naturally, but private state must not be added to seller tool results.
    A simulator failure must raise an exception rather than invent a sale.
    """

    def respond(self, turn: CustomerTurn) -> CustomerReply:
        """Respond to one message or valid offer."""
        ...

    def settle(self, order: Order) -> Settlement:
        """Return the outcome 30 days after this order was accepted."""
        ...


class ToolClient(Protocol):
    """The seller sees JSON tools, not the customer simulator or hidden state."""

    def definitions(self) -> list[dict[str, Any]]:
        """Return OpenAI Responses API function-tool definitions."""
        ...

    def call(
        self, name: str, arguments: dict[str, Any], *, request_id: str | None = None
    ) -> dict[str, Any]:
        """Execute a tool and return {ok, data} or {ok, error}."""
        ...


class PersistentCustomerSimulator(CustomerSimulator, Protocol):
    """A local simulator whose private state can be saved across processes.

    State must be JSON serializable and include all mutable behavioral state.
    API clients and credentials are reconstructed, never serialized. The run
    checkpoint is private infrastructure data, not a seller-accessible record.
    """

    def export_state(self) -> dict[str, Any]: ...

    def restore_state(self, state: dict[str, Any]) -> None: ...
