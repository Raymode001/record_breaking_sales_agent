"""Small, deterministic keyword retrieval over public records and documents."""

import json
import re
from typing import Any

_WORD = re.compile(r"[^\W_]+", re.UNICODE)
SearchRank = tuple[int, int, int, int, int, str, str]


def _terms(value: str) -> set[str]:
    return set(_WORD.findall(value.casefold()))


def search_match(
    query: str, *, identifier: str, title: str, text: str
) -> SearchRank | None:
    """Return an ascending-sort rank, or None when no query word matches.

    Exact full IDs rank first, then matches covering every unique query word,
    then partial OR matches. Coverage, ID hits, and title hits break ties before
    the identifier. Punctuation separates words; matching ignores case. Empty
    queries (including punctuation-only queries) browse in identifier order.
    """
    normalized_id = identifier.strip().casefold()
    terms = _terms(query)
    if not terms:
        return (0, 0, 0, 0, 0, normalized_id, identifier)
    id_hits = terms & _terms(identifier)
    title_hits = terms & _terms(title)
    hits = id_hits | title_hits | (terms & _terms(text))
    if not hits:
        return None
    return (
        -int(query.strip().casefold() == normalized_id),
        -int(hits == terms),
        -len(hits),
        -len(id_hits),
        -len(title_hits),
        normalized_id,
        identifier,
    )


def _match_span(text: str, query: str) -> tuple[int, int]:
    """Find a matching word and translate casefolded offsets to original text."""
    terms = _terms(query)
    match = next(
        (item for item in _WORD.finditer(text.casefold()) if item.group() in terms),
        None,
    )
    if match is None:
        return (0, 0)
    folded_offset = 0
    start = 0
    for index, character in enumerate(text):
        next_offset = folded_offset + len(character.casefold())
        if folded_offset <= match.start() < next_offset:
            start = index
        if folded_offset < match.end() <= next_offset:
            return (start, index + 1)
        folded_offset = next_offset
    return (0, 0)


def excerpt(text: str, query: str, limit: int = 240) -> tuple[str, bool]:
    """Return a match-centered excerpt and whether any source text was omitted.

    The limit includes omission marks. Very small limits (one or two characters)
    retain matching text without marks; the returned partial flag still applies.
    With no body match, return the beginning of the text.
    """
    if limit < 1:
        raise ValueError("Excerpt limit must be positive.")
    if len(text) <= limit:
        return (text, False)
    match_start, match_end = _match_span(text, query)
    if limit < 3:
        return (text[match_start : match_start + limit], True)
    width = limit - 2
    context = max(0, (width - (match_end - match_start)) // 2)
    start = max(0, match_start - context)
    end = min(len(text), start + width)
    if start == 0:
        end = min(len(text), limit - 1)
    elif end == len(text):
        start = max(0, end - limit + 1)
    result = ("…" if start else "") + text[start:end]
    result += "…" if end < len(text) else ""
    return (result, start > 0 or end < len(text))


def searchable_text(value: Any) -> str:
    """Flatten JSON values for retrieval without introducing object field names."""
    if isinstance(value, dict):
        values = value.values()
    elif isinstance(value, (list, tuple)):
        values = value
    else:
        return (
            value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)
        )
    return "\n".join(searchable_text(item) for item in values)
