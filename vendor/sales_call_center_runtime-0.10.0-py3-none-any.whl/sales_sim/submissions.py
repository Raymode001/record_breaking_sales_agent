"""Package the hand-in: prompt.py, tools.py and the five runs of the public campaign made with them.

Student code is never imported or executed here. This is a local hand-in helper, not a sandbox
or a hosted grading service: staff run the two files on held-out campaigns themselves.
"""

import argparse
import ast
import hashlib
import json
from argparse import Namespace
from pathlib import Path
from statistics import mean
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from .experiments import default_output, source_hashes
from .local import course_reasoning, prepare_inputs
from .student_setup import course_settings
from .suites import FORMAL_SUITE

CODE_FILES = ("prompt.py", "tools.py")
REQUIRED_RUNS = 5
# What each run contributes: its conversation log, its result, the exact model history and
# the run report (inspect.html). Private simulator inputs (inputs.json) are never copied.
RUN_FILES = ("transcript.md", "result.json", "seller_history.json", "inspect.html")
NEEDED_RUN_FILES = ("transcript.md", "result.json")
MAX_CODE_BYTES = 2 * 1024 * 1024
MAX_TOTAL_BYTES = 50 * 1024 * 1024
ENTRYPOINT = "sales_sim.student_submission:build_agent"
AGAIN = "Run python run.py final again."


def _read_code(root: Path, name: str) -> bytes:
    path = Path(root) / name
    if path.is_symlink():
        raise ValueError(f"Symlinks are not included: {name}")
    if not path.is_file():
        raise ValueError(f"Missing {name} in {root}.")
    if path.stat().st_size > MAX_CODE_BYTES:
        raise ValueError(f"{name} exceeds the 2 MiB packaging limit.")
    data = path.read_bytes()
    try:
        text = data.decode("utf-8")
        ast.parse(text, filename=name)
    except (UnicodeError, SyntaxError, ValueError) as exc:
        raise ValueError(f"Invalid Python file: {name}: {exc}") from exc
    if not text.strip():
        raise ValueError(f"{name} is empty.")
    return data


def _validate_prompt(data: bytes) -> None:
    """Check the public prompt contract without importing student Python."""
    module = ast.parse(data.decode("utf-8"), filename="prompt.py")
    assignments = []
    for node in module.body:
        if isinstance(node, ast.Assign):
            assignments.extend(node.targets)
        elif isinstance(node, ast.AnnAssign):
            assignments.append(node.target)
    if not any(
        isinstance(target, ast.Name) and target.id == "SYSTEM_PROMPT"
        for target in assignments
    ):
        raise ValueError("prompt.py must assign SYSTEM_PROMPT at module level.")


def _text(data: bytes) -> str:
    return data.decode("utf-8").replace("\r\n", "\n").replace("\r", "\n")


def _json(path: Path, what: str):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        raise ValueError(f"{what} is missing or unreadable: {path}. {AGAIN}") from None


def final_runs(root, code, runs):
    """Check a folder saved by `python run.py final` and summarize it.

    It must hold five completed runs of the public 40-account campaign, as supplied, made
    with exactly these two files and the models, reasoning effort and limits in course.json.
    Returns (manifest, {path in the ZIP: bytes}).
    """
    root, runs = Path(root), Path(runs)
    settings = _json(runs / "settings.json", "The runs' settings")
    current = source_hashes({name: _text(code[name]) for name in CODE_FILES})
    if settings.get("variant") != "tools":
        raise ValueError(f"These runs did not use your prompt and tools. {AGAIN}")
    snapshot = {}
    for name in CODE_FILES:
        try:
            snapshot[name] = (runs / "submission" / name).read_text(encoding="utf-8")
        except OSError:
            raise ValueError(f"The runs' copy of {name} is missing. {AGAIN}") from None
    if settings.get("source_sha256") != current or source_hashes(snapshot) != current:
        raise ValueError(f"prompt.py or tools.py changed since these runs. {AGAIN}")

    course = course_settings(root)
    expected = {"model": course.get("model"), "customer_model": course.get("customer_model"),
                "reasoning_effort": course_reasoning(root), "max_steps": course["limits"]["max_steps"],
                "execution_limits": {key: value for key, value in course["limits"].items() if key != "max_steps"},
                "repeats": REQUIRED_RUNS}
    used = {key: settings.get(key) for key in expected}
    if used != expected:
        changed = ", ".join(key for key in expected if used[key] != expected[key])
        raise ValueError(f"These runs used other settings than course.json and run.py final ({changed}). {AGAIN}")
    campaign = prepare_inputs(Namespace(case=None, suite=root / FORMAL_SUITE,
                                        customer_model=course.get("customer_model")), root)
    wanted = [(case.id, fingerprint) for case, *_, fingerprint in campaign]
    made = [(item.get("case_id"), item.get("fingerprint")) for item in settings.get("inputs", [])]
    if made != wanted:
        raise ValueError(f"These runs are not of the public 40-account campaign as supplied. {AGAIN}")

    folders = sorted(path for path in (runs / "runs").glob("*") if path.is_dir()) if (runs / "runs").is_dir() else []
    rows = [(folder, _json(folder / "result.json", "A run's result")) for folder in folders]
    completed = [row for _, row in rows if row.get("status") == "completed"]
    if len(rows) != REQUIRED_RUNS or len(completed) != REQUIRED_RUNS:
        raise ValueError(f"The hand-in needs {REQUIRED_RUNS} completed runs; this folder has "
                         f"{len(completed)} completed of {len(rows)}. {AGAIN}")
    files = {}
    for folder, _ in rows:
        for name in RUN_FILES:
            path = folder / name
            if path.is_file() and not path.is_symlink():
                files[f"runs/{folder.name}/{name}"] = path.read_bytes()
            elif name in NEEDED_RUN_FILES:
                raise ValueError(f"{folder.name}/{name} is missing. {AGAIN}")
    profits = [row["metrics"].get("profit_cents") for _, row in rows]
    manifest = {
        "schema_version": 1,
        "campaign": FORMAL_SUITE,
        "settings": {key: settings.get(key) for key in (*expected, "service_tier")},
        "source_sha256": current,
        "runs": [{"run": folder.name, "status": row.get("status"), "profit_cents": row["metrics"].get("profit_cents"),
                  "accepted_orders": row["metrics"].get("accepted_orders"),
                  "seller_cost_usd": row.get("seller_cost_usd"), "agent_stop_reason": row.get("agent_stop_reason")}
                 for folder, row in rows],
        "mean_profit_cents": mean(profits) if all(isinstance(value, (int, float)) for value in profits) else None,
    }
    return manifest, files


def package_submission(root, output=None, *, runs=None, code_only=False):
    """Write the hand-in ZIP: prompt.py, tools.py, runs_manifest.json and the five runs.

    With code_only, only the two files: a development check, not a hand-in.
    """
    root = Path(root).resolve()
    output = Path(output or default_output(root, "submission", ".zip")).absolute()
    if code_only == (runs is not None):
        raise ValueError("Give the folder that python run.py final saved (or --code-only for a check of the two files).")
    files = {name: _read_code(root, name) for name in CODE_FILES}
    _validate_prompt(files["prompt.py"])
    if runs is not None:
        manifest, run_files = final_runs(root, files, runs)
        files.update(run_files)
        files["runs_manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode("utf-8")
    if sum(map(len, files.values())) > MAX_TOTAL_BYTES:
        raise ValueError("The hand-in exceeds the 50 MiB packaging limit.")
    record = {
        "schema_version": 3,
        "entrypoint": ENTRYPOINT,
        "variant": "tools",
        "mode": "code_only" if code_only else "final",
        "files": [{"path": name, "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
                  for name, data in sorted(files.items())],
    }
    files["submission_manifest.json"] = (json.dumps(record, indent=2) + "\n").encode()
    output.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(output, "x", compression=ZIP_DEFLATED) as archive:
        for name, data in sorted(files.items()):
            entry = ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
            entry.compress_type = ZIP_DEFLATED
            archive.writestr(entry, data)
    return record


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runs", nargs="?", type=Path, help="The folder that python run.py final saved.")
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path)
    parser.add_argument("--code-only", action="store_true", help="Check the two files only; not a hand-in.")
    args = parser.parse_args(argv)
    args.output = args.output or default_output(args.root, "submission", ".zip")
    try:
        record = package_submission(args.root, args.output, runs=args.runs, code_only=args.code_only)
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    print(f"Packaged {len(record['files'])} files: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
