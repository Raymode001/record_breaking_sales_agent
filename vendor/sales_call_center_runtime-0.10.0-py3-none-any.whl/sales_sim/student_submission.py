"""Load a student's prompt.py and tools.py and build the seller for one variant.

    baseline  the supplied prompt and the supplied toolbox (sales_sim.baseline)
    prompt    the student's SYSTEM_PROMPT and the supplied toolbox
    tools     the student's SYSTEM_PROMPT and the student's toolbox (all of tools.py)

Sources are frozen once and executed in fresh namespaces for each trial. This is a
local development contract, not a Python sandbox.
"""

import json
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType

from . import baseline
from .harness import Seller, Toolbox, is_tool

VARIANTS = ("baseline", "prompt", "tools")


def _module(name, source, root):
    module = ModuleType(f"sales_submission_{name}")
    module.__file__ = str(Path(root) / f"{name}.py")
    exec(compile(source, module.__file__, "exec"), module.__dict__)
    return module


def load_tools(source, root):
    """Every @tool function defined or imported in tools.py, in file order.

    Registration validates names and schemas before any action occurs.
    """
    module = _module("tools", source, Path(root))
    functions = []
    for value in vars(module).values():
        if is_tool(value) and value not in functions:
            functions.append(value)
    Toolbox(functions)
    return tuple(functions)


def load_prompt(source, root):
    prompt = getattr(_module("prompt", source, Path(root)), "SYSTEM_PROMPT", None)
    if not isinstance(prompt, str) or not prompt.strip():
        raise ValueError("prompt.py must define a nonempty SYSTEM_PROMPT string.")
    return prompt


@dataclass(frozen=True)
class FrozenSubmission:
    root: Path
    variant: str
    sources: dict[str, str]

    def _configuration(self):
        if self.variant == "baseline":
            return baseline.PROMPT, baseline.TOOLS
        prompt = load_prompt(self.sources["prompt.py"], self.root)
        functions = load_tools(self.sources["tools.py"], self.root) if self.variant == "tools" else baseline.TOOLS
        return prompt, functions

    def __call__(self, tools, llm, *, model, checkpoint=None, on_record=None, reasoning_effort=None):
        prompt, functions = self._configuration()
        return Seller(tools, llm, model=model, prompt=prompt, reasoning_effort=reasoning_effort,
                      toolbox=Toolbox(functions, on_record=on_record))


def load_submission(root, variant="tools"):
    if variant not in VARIANTS:
        raise ValueError(f"Choose a variant from {', '.join(VARIANTS)}.")
    root = Path(root).resolve()
    sources = {}
    for name in ("prompt.py", "tools.py"):
        path = root / name
        # The supplied baseline remains runnable independently of student edits.
        sources[name] = path.read_text(encoding="utf-8") if path.exists() else ""
        required = variant == "tools" or (variant == "prompt" and name == "prompt.py")
        if required and not sources[name].strip():
            raise ValueError(f"Missing or empty student file: {name}")
    submission = FrozenSubmission(root, variant, sources)
    submission._configuration()
    return submission


def build_agent(tools, llm, *, model, checkpoint=None, on_record=None, reasoning_effort=None):
    """Staff entry point; run from an immutable extracted submission directory.

    A hand-in runs the team's prompt and tools at the reasoning effort of its five public
    runs (runs_manifest.json). Older hand-ins name their variant in experiment_manifest.json."""
    root = Path.cwd()
    variant = "tools"
    if (root / "runs_manifest.json").exists():
        manifest = json.loads((root / "runs_manifest.json").read_text(encoding="utf-8"))
        saved_effort = manifest.get("settings", {}).get("reasoning_effort")
    else:
        manifest = json.loads((root / "experiment_manifest.json").read_text(encoding="utf-8"))
        variant = manifest["final_variant"]
        saved_effort = manifest.get("requested_settings", {}).get("reasoning_effort")
    if reasoning_effort is None:     # the setting the team's own runs used
        reasoning_effort = saved_effort
    return load_submission(root, variant)(
        tools, llm, model=model, checkpoint=checkpoint, on_record=on_record, reasoning_effort=reasoning_effort,
    )
